(function(){
"use strict";

/* ============================================================
   SETUP
   ============================================================ */
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
function resize(){ canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
resize(); window.addEventListener('resize', resize);

const $ = (id)=>document.getElementById(id);

/* ============================================================
   CONSTANTS / DATA
   ============================================================ */
const ARENA_PAD = 70;
const MAX_PLAYER_SPEED = 360;   // hard cap so speed items/synergies can't stack into an uncontrollable blur
const MIN_ATK_CD = 0.18;        // attack-speed cap: can't fire faster than this regardless of cdMult stacking
const MIN_ABILITY_CD = 1.2;     // floor for Q/E cooldowns
const MIN_ULT_CD = 30;          // the R ultimate's cooldown never drops below this, no matter how much cdMult is stacked
function computeWorldBounds(){
  const baseW = canvas.width - ARENA_PAD*2;
  const baseH = canvas.height - ARENA_PAD*2 - 40;
  return { x: ARENA_PAD, y: ARENA_PAD+40, w: baseW*1.15, h: baseH*1.15 };
}
function arenaBounds(){
  return (game && game.world) ? game.world : computeWorldBounds();
}
// distance from (x,y) traveling at angle ang until it exits the arena bounds
function rayToBounds(x,y,ang,b){
  const dx=Math.cos(ang), dy=Math.sin(ang);
  let tMax = Infinity;
  if(dx>0.0001) tMax = Math.min(tMax, (b.x+b.w-x)/dx);
  else if(dx<-0.0001) tMax = Math.min(tMax, (b.x-x)/dx);
  if(dy>0.0001) tMax = Math.min(tMax, (b.y+b.h-y)/dy);
  else if(dy<-0.0001) tMax = Math.min(tMax, (b.y-y)/dy);
  return Math.max(0, tMax);
}

const HEROES = {
  guerrero: {
    id:'guerrero', name:'Bastión', className:'Guerrero', icon:'⚔', accent:'#ff6a3d', glow:'rgba(255,106,61,0.35)',
    hp:245, speed:250, atk:{cd:0.42, dmg:16, range:104, arc:75, kind:'melee'},
    q:{name:'Embestida', icon:'➳', cd:4.2, desc:'Dash largo con inmunidad, golpea fuerte a su paso'},
    e:{name:'Grito de Guerra', icon:'☠', cd:12, desc:'+35% daño y empuja enemigos cerca, 5s'},
    scaling:{stat:'hp', perLevel:0.035},
  },
  maga: {
    id:'maga', name:'Ignis', className:'Maga', icon:'✵', accent:'#6a8dff', glow:'rgba(106,141,255,0.35)',
    hp:56, speed:206, atk:{cd:0.38, dmg:10, range:520, projSpeed:520, radius:7, kind:'ranged'},
    q:{name:'Bola de Fuego', icon:'●', cd:5, desc:'Proyectil grande y lento que explota en área'},
    e:{name:'Parpadeo', icon:'❖', cd:8, desc:'Teletransporte corto de escape'},
    scaling:{stat:'dmg', perLevel:0.035},
  },
  picaro: {
    id:'picaro', name:'Sombra', className:'Pícaro', icon:'✦', accent:'#d24aff', glow:'rgba(210,74,255,0.35)',
    hp:80, speed:250, atk:{cd:0.28, dmg:7, range:480, projSpeed:640, radius:5, kind:'ranged'},
    q:{name:'Ráfaga de Dagas', icon:'⇶', cd:9, desc:'4 dagas en abanico'},
    e:{name:'Paso Sombrío', icon:'☾', cd:16, desc:'Invisibilidad breve + velocidad + golpe crítico'},
    scaling:{stat:'dmg', perLevel:0.03},
  },
  paladin: {
    id:'paladin', name:'Aurelio', className:'Paladín', icon:'✝', accent:'#ffcb47', glow:'rgba(255,203,71,0.35)',
    hp:190, speed:235, atk:{cd:0.5, dmg:15, range:74, arc:70, kind:'melee'},
    q:{name:'Escudo Sagrado', icon:'⛨', cd:9, desc:'Absorbe el próximo golpe de daño'},
    e:{name:'Golpe Divino', icon:'✜', cd:11, desc:'Cura y daña a enemigos cercanos'},
    locked:true, unlockAch:'threeBosses',
    scaling:{stat:'hp', perLevel:0.035},
  },
  nigromante: {
    id:'nigromante', name:'Vesper', className:'Nigromante', icon:'☠', accent:'#8bff6b', glow:'rgba(139,255,107,0.35)',
    hp:95, speed:240, atk:{cd:0.5, dmg:11, range:440, projSpeed:420, radius:6, kind:'ranged'},
    q:{name:'Estallido de Almas', icon:'☄', cd:6.5, desc:'Nova de daño alrededor tuyo'},
    e:{name:'Velo de la Muerte', icon:'✚', cd:12, desc:'Drena vida de enemigos cercanos'},
    locked:true, unlockAch:'depth6',
    scaling:{stat:'dmg', perLevel:0.035},
  },
  vidrio: {
    id:'vidrio', name:'Fractal', className:'Vidrio', icon:'◆', accent:'#e8e8f5', glow:'rgba(232,232,245,0.4)',
    hp:48, speed:260, atk:{cd:0.48, dmg:26, range:82, arc:68, kind:'melee'},
    q:{name:'Golpe Fatal', icon:'✹', cd:5, desc:'Golpe crítico garantizado en área corta'},
    e:{name:'Piel de Cristal', icon:'⬡', cd:15, desc:'Escudo que absorbe un golpe grande'},
    locked:true, unlockAch:'noHitBoss',
    scaling:{stat:'dmg', perLevel:0.045},
  },
  coloso: {
    id:'coloso', name:'Grava', className:'Coloso', icon:'⛰', accent:'#9c8a6a', glow:'rgba(156,138,106,0.35)',
    hp:300, speed:205, atk:{cd:0.55, dmg:20, range:92, arc:80, kind:'melee'},
    q:{name:'Grito Ominoso', icon:'📯', cd:10, desc:'Atrae y aturde a los enemigos cercanos'},
    e:{name:'Muro de Voluntad', icon:'⛊', cd:14, desc:'Gran escudo y más resistencia por 4s'},
    locked:true, unlockAch:'tankyRun',
    scaling:{stat:'hp', perLevel:0.045},
  },
  silvano: {
    id:'silvano', name:'Silvano', className:'Invocador', icon:'🐺', accent:'#5bbf7a', glow:'rgba(91,191,122,0.35)',
    hp:100, speed:245, atk:{cd:0.5, dmg:9, range:400, projSpeed:420, radius:6, kind:'ranged'},
    q:{name:'Lobo Espectral', icon:'🐺', cd:9, desc:'Invoca un lobo que ataca solo'},
    e:{name:'Sacrificio', icon:'✳', cd:11, desc:'Detona al lobo en una explosión'},
    locked:true, unlockAch:'itemHoarder',
    scaling:{stat:'dmg', perLevel:0.035},
  },
  dual: {
    id:'dual', name:'Ambos', className:'Dual', icon:'⚖', accent:'#5ac8d8', glow:'rgba(90,200,216,0.35)',
    hp:100, speed:255,
    atkMelee:{cd:0.4, dmg:14, range:82, arc:70, kind:'melee'},
    atkRanged:{cd:0.3, dmg:9, range:440, projSpeed:480, radius:6, kind:'ranged'},
    q:{name:'Cambio de Postura', icon:'⇄', cd:1.5, desc:'Alterna entre espada y cuchillos'},
    e:{name:'Golpe Combinado', icon:'✦', cd:8, desc:'Dash corto con daño en cualquier postura'},
    locked:true, unlockAch:'killStreak',
    scaling:[{stat:'hp', perLevel:0.02},{stat:'dmg', perLevel:0.02}],
  },
};

const ACHIEVEMENTS = [
  { id:'threeBosses', name:'Cazador de Jefes', desc:'Derrota 3 jefes en una misma run', unlocks:'paladin',
    check: g=> g.stats.bossesThisRun>=3 },
  { id:'depth6', name:'Descenso Profundo', desc:'Alcanza la etapa 6', unlocks:'nigromante',
    check: g=> g.stats.stageReached>=6 },
  { id:'noHitBoss', name:'Filo de Cristal', desc:'Derrota un jefe sin recibir daño en esa pelea', unlocks:'vidrio',
    check: g=> g.stats.noHitBoss===true },
  { id:'tankyRun', name:'Muro Viviente', desc:'Alcanza 300 de HP máxima en una run', unlocks:'coloso',
    check: g=> g.player.maxHp>=300 },
  { id:'itemHoarder', name:'Coleccionista', desc:'Consigue 6 objetos en una misma run', unlocks:'silvano',
    check: g=> g.player.items.length>=6 },
  { id:'killStreak', name:'Cazador Incansable', desc:'Elimina 150 enemigos en una misma run', unlocks:'dual',
    check: g=> g.kills>=150 },
];
const progress = { unlocked:{ guerrero:true, maga:true, picaro:true, paladin:false, nigromante:false, vidrio:false, coloso:false, silvano:false, dual:false },
  unlockedAbilities:[], essence:0, homeUpgrades:{}, bestStage:0 };

function checkAchievements(){
  if(!game) return;
  ACHIEVEMENTS.forEach(a=>{
    if(!progress.unlocked[a.unlocks] && a.check(game)){
      progress.unlocked[a.unlocks] = true;
      const hero = HEROES[a.unlocks];
      spawnToast(`🏆 Logro: ${a.name} — nuevo héroe: ${hero.name}`);
    }
  });
}

const TOWER_MAX_FLOOR = 100; // the tower has a hard top: floor 100 holds the true final boss
const ZONES = [
  { key:'cripta', name:'La Cripta Olvidada', desc:'Huesos viejos y aire quieto. Algo aquí sigue montando guardia.',
    enemyKinds:['skeleton','archer','charger'], guardianBoss:'boneGuardian',
    baseHp:210, baseSpeed:95, baseDmg:13, baseRadius:29, baseContactCd:1.0, minion:'skeleton', baseColor:'#c9bda0',
    movePool:['boneVolley','risingSpikes','boneArmor','boneTrap','summon','boneCross','boneSpiral','skullBarrage','graveSpikes','boneWhip','deathRattle','hauntingWail','cryptCollapse','boneShrapnel','graveyardShift','deathMark','skeletalSwarm','tombstoneSlam','ribcage','deathToll','skullStorm','gravebind','boneChain','cryptWhisper','deathsDoor','rattlingBones','deathKnell'], dashMove:'charge',
    regularNames:['Centinela Óseo','Guardián Polvoriento','Custodio de Cenizas','Vigía sin Rostro','Heraldo de Tumba','Espectro de Cripta','Portador de Huesos','Sombra Sepulta','Centinela del Osario'] },
  { key:'pantano', name:'El Pantano Maldito', desc:'El barro respira. Las voces bajo el agua ya saben tu nombre.',
    enemyKinds:['zombie','witch','shaman'], guardianBoss:'motherWitch',
    baseHp:250, baseSpeed:92, baseDmg:12, baseRadius:28, baseContactCd:1.0, minion:'zombie', baseColor:'#7fd98f',
    movePool:['toxicSpores','swampGrasp','witchesBlessing','hexTrail','mudSlow','bogBurst','leechSwarm','witchesCurse','numbTonic','rootSnare','quicksand','poisonBrew','witchsEye','cauldronBubble','swampSurge','willOWisp','vineLine','venomLash','shadowBrew','batSwarm','mireField','curseBind','witchsMark','spectralHex','gooBurst','plagueCloud','witchesRing'], dashMove:'blinkStrike',
    regularNames:['Bruja del Lodo','Susurro de Ciénaga','Hechicera Ahogada','Voz del Pantano','Tejedora de Niebla','Madre de Sapos','Encantadora Podrida','Sombra del Lodazal','Bruja de Raíces'] },
  { key:'fortaleza', name:'La Fortaleza Infernal', desc:'El calor sube desde abajo. Cada piso pesa más que el anterior.',
    enemyKinds:['demon','summoner','brute'], guardianBoss:'abyssLord',
    baseHp:310, baseSpeed:100, baseDmg:15, baseRadius:31, baseContactCd:0.95, minion:'demon', baseColor:'#ff8a5a',
    movePool:['cinderBurst','emberField','moltenCore','cinderRain','flameWhip','lavaSpurt','infernoRing','brimstoneRain','demonRoar','ashCloud','moltenTrap','cinderSwarm','flameSurge','infernalBond','sulfurBreath','pyreCollapse','scorchedEarth','demonEye','infernalChains','brimstoneSpiral','flameWreath','hellgate','cinderVolley','moltenWave','demonicHowl','infernalCrown','demonicBlast'], dashMove:null,
    regularNames:['Heraldo de Magma','Guardián en Llamas','Verdugo Infernal','Centinela Ardiente','Custodio del Fuego','Sombra Incandescente','Bestia de Cenizas','Portador de Brasas','Vigía del Cráter'] },
  { key:'jardin', name:'El Jardín Prismático', desc:'Pétalos de luz caen sin ruido. Algo hermoso te está observando.',
    enemyKinds:['wisp','summoner','frostSprite'], guardianBoss:'empressOfLight',
    baseHp:290, baseSpeed:128, baseDmg:11, baseRadius:27, baseContactCd:1.0, minion:'wisp', baseColor:'#ffd6f0',
    movePool:['thornVolley','bloomTrap','healingBloom','lightTwins','radiantPath','petalStorm','vineWhip','prismShard','nectarSwarm','gildedThorns','dewTrap','crystalBloom','thornCage','sunbeamLine','bloomRing','sunfireCross','radianceField','lightCascade','tangleRoots','mirrorBloom','verdantSurge','glowWisp','sunfireLance','lightPollen','witheringPetals','petalVeil','gardenGuardians'], dashMove:'prismDash',
    regularNames:['Doncella de Pétalos','Guardiana de Luz','Espíritu Floreciente','Susurro de Jardín','Custodia Radiante','Ninfa de Cristal','Bailarina de Luz','Centinela de Rocío','Doncella Prismática'] },
  { key:'espejos', name:'El Salón de Espejos', desc:'Cada reflejo se mueve un instante tarde. O un instante antes.',
    enemyKinds:['wisp','erratic','archer'], guardianBoss:'mirrorLord',
    baseHp:330, baseSpeed:110, baseDmg:14, baseRadius:28, baseContactCd:1.0, minion:'skeleton', baseColor:'#cfd6e8',
    movePool:['mirrorDecoy','glassField','illusionSwap','mirrorGaze','fracturedBurst','shatterVolley','reflectedBarrage','prismaticShards','mirageSwarm','silverStrike','mirrorMaze','shatterZone','reflectivePool','glassSpikes','doubleVision','distortionField','echoChamber','hallOfMirrors','mirrorShatter','reflectivePulse','phantomChaser','reflectedLance','hauntingReflection','disorientingGaze','shatteredFocus','silveredSkin','mirroredEcho'], dashMove:'echoDash',
    regularNames:['Eco Fracturado','Reflejo Distante','Sombra Especular','Fragmento de Espejo','Doble Silencioso','Imagen Rota','Espejo Errante','Reflejo Tardío','Eco de Cristal'] },
  { key:'gemelo', name:'El Santuario Gemelo', desc:'Todo aquí viene de a dos. Vos sos el único que llegó solo.',
    enemyKinds:['witch','summoner','charger'], guardianBoss:'twinBoss',
    baseHp:290, baseSpeed:105, baseDmg:12, baseRadius:26, baseContactCd:1.0, minion:'wisp', baseColor:'#ffb0d9',
    movePool:['boundStrike','bondPulse','twinStrike','bondedShield','spiritLink','twinVolley','soulShards','pairedBolts','spiritBurst','boundArrows','soulTether','kinshipRing','dualBloom','sharedPain','weaveTrap','pactCircle','tetherLine','soulPulse','boundSurge','spiritChaser','soulLance','kinseeker','sharedWound','soulSap','boundCurse','sharedBlessing','twinSpirits'], dashMove:'charge',
    regularNames:['Espíritu Vinculado','Alma Gemela','Sombra Compartida','Eco Fraternal','Vínculo Roto','Espíritu Doble','Presencia Gemela','Aliento Compartido','Sombra Hermana'] },
  { key:'glaciar', name:'El Glaciar Eterno', desc:'El frío no muerde: espera. Cada aliento se ve, cada paso se oye.',
    enemyKinds:['frostSprite','charger','brute'], guardianBoss:'glacierMonarch',
    baseHp:370, baseSpeed:95, baseDmg:16, baseRadius:30, baseContactCd:0.95, minion:'frostSprite', baseColor:'#9fd8ff',
    movePool:['iceLance','crystalPrison','avalanche','frostBreath','numbingChill'], dashMove:'echoDash',
    regularNames:['Centinela de Escarcha','Guardián de Hielo','Custodio Glacial','Espíritu del Frío','Vigía Congelado','Sombra de Escarcha','Portador de Nieve','Centinela Blanco','Custodia del Hielo'] },
  { key:'tormenta', name:'El Yermo Tormentoso', desc:'El cielo nunca se queda quieto. Tampoco lo que vive en él.',
    enemyKinds:['sniper','charger','swarmling'], guardianBoss:'stormLord',
    baseHp:390, baseSpeed:115, baseDmg:17, baseRadius:29, baseContactCd:0.9, minion:'sniper', baseColor:'#ffe45a',
    movePool:['thunderStrike','stormVortex','staticField','skySiege','boltRunner'], dashMove:'prismDash',
    regularNames:['Heraldo de la Tormenta','Portador del Trueno','Custodio del Rayo','Vigía Tormentoso','Espíritu del Viento','Sombra Eléctrica','Centinela del Cielo','Heraldo del Relámpago','Guardián de la Tempestad'] },
  { key:'abismo', name:'El Abismo Sin Fondo', desc:'Acá abajo, hasta el eco tarda en volver. Si es que vuelve.',
    enemyKinds:['erratic','shaman','brute'], guardianBoss:'starDevourer',
    baseHp:430, baseSpeed:100, baseDmg:18, baseRadius:30, baseContactCd:0.9, minion:'erratic', baseColor:'#8a5ad9',
    movePool:['voidTendrils','darkPulse','starlightDrain','umbraStep','collapsingStar'], dashMove:'charge',
    regularNames:['Susurro del Vacío','Sombra Insondable','Eco de la Nada','Custodio Oscuro','Presencia del Abismo','Vigía sin Luz','Espíritu Vacío','Sombra Profunda','Heraldo de la Nada'] },
  { key:'trono', name:'El Trono del Descenso', desc:'Lo que sea que gobierna esta torre te espera arriba de todo.',
    enemyKinds:['demon','sniper','brute'], guardianBoss:'trueFinal',
    baseHp:470, baseSpeed:110, baseDmg:19, baseRadius:31, baseContactCd:0.9, minion:'demon', baseColor:'#e0c9a0',
    movePool:['royalDecree','throneSlam','crownfire','finalJudgment','soulBarrage'], dashMove:'blinkStrike',
    regularNames:['Guardián del Trono','Custodio Final','Centinela del Descenso','Sombra del Trono','Vigía Postrero','Heraldo del Final','Guardián Postrero','Custodio del Umbral','Sombra Final'] },
];

// Lightens (positive percent) or darkens (negative percent) a hex color, used to give each of a
// zone's 9 regular-floor bosses a subtly distinct shade of the zone's base color.
function shadeColor(hex, percent){
  const num = parseInt(hex.replace('#',''),16);
  let r = (num>>16)+Math.round(255*percent/100);
  let g = ((num>>8)&0xff)+Math.round(255*percent/100);
  let bch = (num&0xff)+Math.round(255*percent/100);
  r = clamp(r,0,255); g = clamp(g,0,255); bch = clamp(bch,0,255);
  return '#'+(0x1000000+r*0x10000+g*0x100+bch).toString(16).slice(1);
}

// Deterministic tiny PRNG (so a given floor always generates the same boss) — used only to pick
// which subset of the zone's move pool a given regular-floor boss gets.
function seededShuffle(arr, seed){
  const out = arr.slice();
  let s = seed;
  for(let i=out.length-1;i>0;i--){
    s = (s*9301+49297)%233280;
    const j = Math.floor((s/233280)*(i+1));
    [out[i],out[j]] = [out[j],out[i]];
  }
  return out;
}

// Every attack falls into one mechanical family: a spread of projectiles ("burst"), a telegraphed
// danger zone on the floor ("ground"), a self-centered melee hit ("self"), a threat that chases you
// ("homing"), a crowd-control pull ("pull"), or a pure status effect ("debuff"). Dash moves are their
// own thing, handled separately and budgeted to exactly 10 floors.
const MOVE_CATEGORY = {
  radialBurst:'burst', radiantNova:'burst', butterflyBurst:'burst', spiralBloom:'burst', petalRing:'burst',
  twinPulse:'burst', crossFire:'burst', frostNova:'burst', stormBolt:'burst', boneShards:'burst',
  rainbowLine:'burst', phantomBarrage:'burst', mirrorSplit:'burst', witchCauldron:'burst', chainLightning:'burst', thunderdome:'burst',
  boneVolley:'burst', toxicSpores:'burst', cinderBurst:'burst', thornVolley:'burst', flameWhip:'burst',
  poisonPool:'ground', meteor:'ground', boneCage:'ground', boneWall:'ground', magmaCross:'ground',
  blazingFissure:'ground', growingMagma:'ground', iceCage:'ground', stormField:'ground', voidRift:'ground',
  fireRain:'ground', lavaGeyser:'ground', gracefulVeil:'ground', glassRain:'ground', blizzardWall:'ground',
  frozenGround:'ground', starCollapse:'ground', abyssalCollapse:'ground',
  risingSpikes:'ground', boneTrap:'ground', swampGrasp:'ground', hexTrail:'ground',
  emberField:'ground', moltenCore:'ground', cinderRain:'ground', bloomTrap:'ground', radiantPath:'ground',
  slam:'self', boneSlam:'self', fireWave:'self',
  curseMark:'homing', voidLance:'homing', lightTwins:'homing',
  boneGrab:'pull', gravityWell:'pull',
  wither:'debuff', mudSlow:'debuff',
  sisterCall:'buff', boneArmor:'buff', witchesBlessing:'buff', healingBloom:'buff',
  petalStorm:'burst', vineWhip:'burst', prismShard:'burst', nectarSwarm:'burst', gildedThorns:'burst',
  dewTrap:'ground', crystalBloom:'ground', thornCage:'ground', sunbeamLine:'ground', bloomRing:'ground',
  sunfireCross:'ground', radianceField:'ground', lightCascade:'ground', tangleRoots:'ground',
  mirrorBloom:'self', verdantSurge:'self',
  glowWisp:'homing', sunfireLance:'homing',
  lightPollen:'debuff', witheringPetals:'debuff',
  petalVeil:'buff', gardenGuardians:'summon',
  shatterVolley:'burst', reflectedBarrage:'burst', prismaticShards:'burst', mirageSwarm:'burst', silverStrike:'burst',
  mirrorMaze:'ground', shatterZone:'ground', reflectivePool:'ground', glassSpikes:'ground', doubleVision:'ground',
  distortionField:'ground', echoChamber:'ground', hallOfMirrors:'ground',
  mirrorShatter:'self', reflectivePulse:'self',
  phantomChaser:'homing', reflectedLance:'homing', hauntingReflection:'homing',
  disorientingGaze:'debuff', shatteredFocus:'debuff',
  silveredSkin:'buff', mirroredEcho:'summon',
  twinVolley:'burst', soulShards:'burst', pairedBolts:'burst', spiritBurst:'burst', boundArrows:'burst',
  soulTether:'ground', kinshipRing:'ground', dualBloom:'ground', sharedPain:'ground', weaveTrap:'ground', pactCircle:'ground', tetherLine:'ground',
  soulPulse:'self', boundSurge:'self',
  spiritChaser:'homing', soulLance:'homing', kinseeker:'homing',
  sharedWound:'debuff', soulSap:'debuff', boundCurse:'debuff',
  sharedBlessing:'buff', twinSpirits:'summon',
  eyeLaser:'burst', cursedFlameBreath:'burst', twinCharge:'self',
  mirrorDecoy:'burst', fracturedBurst:'burst', boundStrike:'burst',
  glassField:'ground', bondPulse:'ground', spiritLink:'ground',
  illusionSwap:'self', twinStrike:'self',
  mirrorGaze:'debuff',
  bondedShield:'buff',
  iceLance:'homing', boltRunner:'homing', soulBarrage:'homing',
  crystalPrison:'ground', avalanche:'ground', stormVortex:'ground', skySiege:'ground',
  voidTendrils:'ground', collapsingStar:'ground', finalJudgment:'ground', thunderStrike:'ground',
  frostBreath:'burst', darkPulse:'burst', crownfire:'burst',
  numbingChill:'debuff', staticField:'debuff', starlightDrain:'debuff', royalDecree:'debuff',
  umbraStep:'self', throneSlam:'self', graveyardShift:'self', tombstoneSlam:'self', rattlingBones:'self',
  skullBarrage:'burst', boneShrapnel:'burst', skeletalSwarm:'burst', skullStorm:'burst',
  boneCross:'ground', boneSpiral:'ground', graveSpikes:'ground', cryptCollapse:'ground',
  ribcage:'ground', deathToll:'ground', deathsDoor:'ground', deathKnell:'ground',
  boneWhip:'burst',
  deathRattle:'debuff', hauntingWail:'debuff', gravebind:'debuff',
  deathMark:'homing', boneChain:'homing',
  cryptWhisper:'buff', shadowBrew:'buff', infernalBond:'buff',
  lavaSpurt:'burst', cinderSwarm:'burst', sulfurBreath:'burst', cinderVolley:'burst', infernalCrown:'burst',
  demonEye:'homing', infernalChains:'homing',
  demonRoar:'debuff', ashCloud:'debuff', demonicHowl:'debuff',
  infernoRing:'ground', brimstoneRain:'ground', moltenTrap:'ground', flameSurge:'ground',
  pyreCollapse:'ground', scorchedEarth:'ground', brimstoneSpiral:'ground', moltenWave:'ground',
  flameWreath:'self', hellgate:'self', demonicBlast:'self',
  bogBurst:'burst', willOWisp:'burst', batSwarm:'burst', gooBurst:'burst',
  leechSwarm:'homing', witchsEye:'homing', witchsMark:'homing',
  witchesCurse:'debuff', numbTonic:'debuff', curseBind:'debuff',
  rootSnare:'ground', quicksand:'ground', poisonBrew:'ground', swampSurge:'ground',
  vineLine:'ground', mireField:'ground', plagueCloud:'ground', witchesRing:'ground',
  cauldronBubble:'self', spectralHex:'self',
  venomLash:'burst',
  summon:'summon',
};

// Picks `count` moves from `pool`, preferring one move per distinct mechanical category (so a boss's
// kit reads as e.g. "a bullet spread + a ground hazard + a chasing threat" instead of three flavors
// of the same idea). Falls back to any leftover moves if the pool doesn't span enough categories.
function pickCategoryDiverseMoves(pool, seed, count){
  const byCategory = {};
  pool.forEach(m=>{
    const cat = MOVE_CATEGORY[m] || 'burst';
    (byCategory[cat] = byCategory[cat]||[]).push(m);
  });
  const categories = seededShuffle(Object.keys(byCategory), seed);
  const picked = [];
  for(let i=0;i<categories.length && picked.length<count;i++){
    const opts = seededShuffle(byCategory[categories[i]], seed+i*17+3);
    picked.push(opts[0]);
  }
  if(picked.length<count){
    const remaining = seededShuffle(pool.filter(m=>!picked.includes(m)), seed+99);
    for(let i=0;i<remaining.length && picked.length<count;i++) picked.push(remaining[i]);
  }
  return picked;
}

// Builds the 90 unique regular-floor bosses (every floor from 1-100 except the 10 Guardian floors)
// directly into BOSS_DEFS/BOSS_ATTACKS, keyed as 'floor_<N>'. Each zone's 5th regular floor gets
// the zone's one designated dash move; the Fortaleza zone gets none at all — together with
// trueFinal (floor 100), this keeps the whole 100-floor tower at exactly 10 dash-capable bosses.
// A move is "support" (buff/debuff/summon) if it doesn't threaten the player with dodgeable damage
// on its own. Spreading these evenly (at most one per floor) keeps every floor's kit from
// accidentally clustering into 2-3 non-threatening moves, which made some floors trivial.
function isSupportMove(m){
  const cat = MOVE_CATEGORY[m];
  return cat==='buff' || cat==='debuff' || cat==='summon';
}
function partitionZoneMoves(pool, zoneIdx){
  const support = pool.filter(isSupportMove);
  const threat = pool.filter(m=>!isSupportMove(m));
  const shuffledSupport = seededShuffle(support, zoneIdx*1000+11);
  const shuffledThreat = seededShuffle(threat, zoneIdx*1000+23);
  const groups = []; for(let f=0; f<9; f++) groups.push([]);
  shuffledSupport.forEach((m,i)=>{ if(i<9) groups[i].push(m); }); // at most 1 support move per floor
  let ti=0;
  for(let f=0; f<9; f++){ while(groups[f].length<3 && ti<shuffledThreat.length){ groups[f].push(shuffledThreat[ti++]); } }
  return groups;
}
// Manual per-floor tuning knobs, layered on top of the normal formula — for individual floors
// that turned out too easy or too hard once actually played.
const FLOOR_STAT_OVERRIDES = {
  12: { hpMult:1.35, dmgMult:1.15 }, // felt too weak in playtesting
};
function generateFloorBosses(){
  ZONES.forEach((zone, zoneIdx)=>{
    for(let floorInZone=0; floorInZone<9; floorInZone++){
      const floor = zoneIdx*10 + floorInZone + 1;
      const kind = `floor_${floor}`;
      const shade = -22 + floorInZone*6; // gradient from a darker to a lighter shade across the zone
      const override = FLOOR_STAT_OVERRIDES[floor] || {};
      BOSS_DEFS[kind] = {
        name: zone.regularNames[floorInZone],
        hp: Math.round(zone.baseHp*(1+floorInZone*0.05)*(override.hpMult||1)),
        speed: zone.baseSpeed,
        dmg: Math.round(zone.baseDmg*(1+floorInZone*0.04)*(override.dmgMult||1)),
        radius: zone.baseRadius,
        color: shadeColor(zone.baseColor, shade),
        contactCd: zone.baseContactCd,
        minion: zone.minion,
        title: zone.desc,
      };
      let moves;
      if(zone.movePool.length>=27){
        // the zone has been expanded to exactly 9x3 unique moves — partition once, balancing
        // support moves evenly, so no floor ends up with more than one non-threatening move
        if(!zone._groups) zone._groups = partitionZoneMoves(zone.movePool, zoneIdx);
        moves = zone._groups[floorInZone].slice();
      } else {
        moves = pickCategoryDiverseMoves(zone.movePool, floor*7+13, 3);
      }
      if(zone.dashMove && floorInZone===4) moves.push(zone.dashMove);
      BOSS_ATTACKS[kind] = moves;
    }
  });
}

// stageAt(i) builds a fixed 100-floor tower (i is 0-indexed, floor = i+1). Every block of 10 floors
// is one zone; the 10th floor of each zone (floor 10, 20, 30...) is that zone's stronger Guardian.
function stageAt(i){
  const floor = clamp(i, 0, TOWER_MAX_FLOOR-1);
  const zoneIndex = Math.floor(floor/10);
  const zone = ZONES[Math.min(zoneIndex, ZONES.length-1)];
  const isGuardianFloor = (floor+1)%10===0;
  const hpMult = 1 + floor*0.24;       // steeper HP growth than before — damage scaling felt right, HP didn't
  const dmgMult = 1 + floor*0.12;
  const mult = dmgMult;                // kept for any old code still reading .mult (damage-oriented)
  const enemyHpMult = 1 + floor*0.10;  // normal (non-boss) enemies scale more gently so runs don't get out of hand
  const enemyDmgMult = 1 + floor*0.055; // damage scales noticeably slower than HP for trash mobs
  const CHEST_BASE_COST = 18;
  const chestCost = Math.round(CHEST_BASE_COST * (1 + floor*0.12));
  return { ...zone, floor:floor+1, zoneIndex, isGuardianFloor,
    bossKind: isGuardianFloor ? zone.guardianBoss : `floor_${floor+1}`,
    mult, hpMult, dmgMult, enemyHpMult, enemyDmgMult,
    name: isGuardianFloor ? `${zone.name} — Guardián` : zone.name,
    chestCost,
  };
}

const ENEMY_DEFS = {
  skeleton: { name:'Esqueleto', hp:34, speed:118, dmg:9, kind:'melee', range:26, atkCd:0.9, radius:16, color:'#ccc3b0', gold:[1,3] },
  archer:   { name:'Arquero en Ruinas', hp:22, speed:96, dmg:7, kind:'ranged', range:300, atkCd:1.7, projSpeed:300, radius:15, color:'#8fae7a', gold:[1,3] },
  zombie:   { name:'Rastrero Podrido', hp:58, speed:78, dmg:13, kind:'melee', range:28, atkCd:1.1, radius:19, color:'#6f8a53', gold:[2,4] },
  witch:    { name:'Bruja Venenosa', hp:30, speed:92, dmg:6, kind:'ranged', range:280, atkCd:1.9, projSpeed:260, radius:15, color:'#8a4fae', gold:[2,4], poison:true },
  demon:    { name:'Demonio Menor', hp:44, speed:168, dmg:12, kind:'melee', range:26, atkCd:0.8, radius:17, color:'#c23a3a', gold:[2,5] },
  summoner: { name:'Invocador de Llamas', hp:34, speed:100, dmg:11, kind:'ranged', range:320, atkCd:1.6, projSpeed:320, radius:16, color:'#d97b2b', gold:[2,5] },
  wisp:     { name:'Chispa Errante', hp:20, speed:150, dmg:6, kind:'ranged', range:260, atkCd:1.3, projSpeed:340, radius:13, color:'#ffb3ec', gold:[2,4] },
  bomber:   { name:'Reventado', hp:26, speed:130, dmg:8, kind:'melee', range:24, atkCd:1.0, radius:16, color:'#ff8a3d', gold:[2,4],
    explodesOnDeath:true, explodeRadius:70, explodeDmg:16 },
  shielded: { name:'Escudero Óseo', hp:40, speed:88, dmg:10, kind:'melee', range:26, atkCd:1.1, radius:18, color:'#8a8f9c', gold:[2,5],
    armor:24 },
  erratic:  { name:'Fantasma Errático', hp:24, speed:150, dmg:7, kind:'ranged', range:270, atkCd:1.5, projSpeed:280, radius:14, color:'#c9b8ff', gold:[2,5],
    erratic:true, dodgeChance:0.3 },
  charger:  { name:'Embestidor Óseo', hp:36, speed:104, dmg:15, kind:'melee', range:26, atkCd:1.0, radius:17, color:'#e0a15a', gold:[2,4],
    charger:true, chargeSpeed:540, chargeWindup:0.55, chargeDur:0.35, chargeCd:1.6 },
  brute:    { name:'Bestia del Osario', hp:100, speed:60, dmg:20, kind:'melee', range:32, atkCd:1.3, radius:24, color:'#8a3a2a', gold:[3,6] },
  shaman:   { name:'Chamán del Pantano', hp:26, speed:88, dmg:5, kind:'ranged', range:260, atkCd:2.2, projSpeed:240, radius:15, color:'#5ad98a', gold:[2,5],
    healer:true, healRadius:150, healAmount:6, healCd:3 },
  sniper:   { name:'Francotirador Óseo', hp:24, speed:68, dmg:23, kind:'ranged', range:430, atkCd:2.6, projSpeed:480, radius:14, color:'#d9d0a0', gold:[2,5],
    chargeShot:true, chargeShotWindup:0.9 },
  frostSprite: { name:'Espina de Escarcha', hp:22, speed:112, dmg:7, kind:'ranged', range:270, atkCd:1.8, projSpeed:300, radius:14, color:'#9fd8ff', gold:[2,4],
    slowOnHit:true, slowFactor:0.55, slowDur:1.2 },
  swarmling: { name:'Enjambre Óseo', hp:12, speed:172, dmg:4, kind:'melee', range:20, atkCd:0.6, radius:10, color:'#b8ada0', gold:[1,2] },
};
const ELITE_CHANCE = 0.055;
const ELITE_MULT = { hp:2.3, dmg:1.5, gold:2.0 };

const BOSS_DEFS = {
  boneGuardian: { name:'Guardián de Hueso', hp:340, speed:100, dmg:20, radius:34, color:'#d9cdb3', contactCd:1.0,
    minion:'skeleton', title:'El primer centinela' },
  motherWitch:  { name:'Bruja Madre', hp:460, speed:90, dmg:16, radius:32, color:'#a44fd9', contactCd:1.0,
    minion:'zombie', title:'La que teje el pantano' },
  abyssLord:    { name:'Señor del Abismo', hp:640, speed:115, dmg:24, radius:38, color:'#ff5a3d', contactCd:0.9,
    minion:'demon', title:'Lo que espera abajo' },
  empressOfLight: { name:'Emperatriz de la Luz', hp:560, speed:150, dmg:15, radius:30, color:'#ffb3ec', contactCd:1.0,
    minion:'wisp', title:'Gracia letal del jardín' },
  mirrorLord: { name:'Reflejo', hp:420, speed:120, dmg:18, radius:30, color:'#e8e8f5', contactCd:1.0,
    minion:'skeleton', title:'Todo lo que sos, vuelto en tu contra' },
  twinBoss: { name:'Hermanas Gemelas', hp:260, speed:110, dmg:14, radius:26, color:'#ff9ad1', contactCd:1.0,
    minion:'wisp', title:'Ninguna cae sola' },
  trueFinal: { name:'El Verdadero Abismo', hp:1100, speed:120, dmg:22, radius:40, color:'#ffffff', contactCd:0.85,
    minion:'demon', title:'No queda ceremonia. Solo esto.' },

  // zone guardians — the notably stronger boss on floors 10, 20, 30... (70/80/90 are new; the rest reuse the kinds above)
  glacierMonarch: { name:'Monarca del Glaciar', hp:900, speed:100, dmg:24, radius:38, color:'#c8ecff', contactCd:0.85,
    minion:'frostSprite', title:'Señor de un frío que no perdona' },
  stormLord:      { name:'Señor del Trueno', hp:980, speed:120, dmg:26, radius:38, color:'#fff05a', contactCd:0.85,
    minion:'sniper', title:'La tormenta hecha carne' },
  starDevourer:   { name:'Devorador de Estrellas', hp:1060, speed:110, dmg:28, radius:40, color:'#5a3d8a', contactCd:0.8,
    minion:'erratic', title:'Se traga hasta la luz' },
  // the 90 regular-floor bosses (one unique boss per non-guardian floor, 1-100) are generated
  // programmatically right after ZONES is defined — see generateFloorBosses() below.
};

const BOSS_ATTACKS = {
  boneGuardian: ['boneShards','boneCage','boneWall','boneGrab'],
  motherWitch: ['poisonPool','curseMark','witchCauldron','wither','acidDeluge','venomousWeb'],
  abyssLord: ['slam','magmaCross','blazingFissure','growingMagma'],
  empressOfLight: ['butterflyBurst','gracefulVeil','radiantNova','rainbowLine','spiralBloom','petalRing'],
  mirrorLord: ['mirrorSplit','phantomBarrage','glassRain'],
  twinBoss: ['eyeLaser','cursedFlameBreath','twinCharge','sisterCall','megaLaser'],
  trueFinal: ['boneWall','boneGrab','curseMark','wither','fireWave','mirrorSplit','phantomBarrage','twinPulse','twinSwap','echoDash','slam','meteor','poisonPool','boneCage','abyssalCollapse'],

  // zone guardians — every move below is exclusive to its own Guardian; none of the 9 non-final
  // Guardians share a single attack with any other Guardian
  glacierMonarch: ['frostNova','iceCage','blizzardWall','frozenGround'],
  stormLord: ['chainLightning','stormField','thunderdome'],
  starDevourer: ['voidLance','voidRift','gravityWell','starCollapse'],
};
generateFloorBosses(); // now that BOSS_DEFS/BOSS_ATTACKS exist, fill in the 90 regular-floor bosses

const BOSS_ITEMS = {
  boneGuardian: { id:'bossBone', name:'Corona de Hueso Antiguo', icon:'♛', desc:'+5% daño y +3% reducción de daño', apply:p=>{ p.dmgMult*=1.05; p.armor+=0.03; } },
  motherWitch:  { id:'bossWitch', name:'Frasco de la Bruja Madre', icon:'☘', desc:'+4% robo de vida y +4% velocidad', apply:p=>{ grantLifesteal(p,0.04); p.speedMult*=1.04; } },
  abyssLord:    { id:'bossAbyss', name:'Núcleo del Abismo', icon:'⚡', desc:'+8% daño y -8% enfriamiento', apply:p=>{ p.dmgMult*=1.08; p.cdMult*=0.92; } },
  empressOfLight:{ id:'bossEmpress', name:'Pluma Prismática', icon:'✦', desc:'+5% crítico y +18 HP máx', apply:p=>{ p.critChance+=0.05; p.maxHp+=18; p.hp+=18; } },
  mirrorLord: { id:'bossMirror', name:'Esquirla de Espejo', icon:'◈', desc:'+5% daño y +5% enfriamiento reducido', apply:p=>{ p.dmgMult*=1.05; p.cdMult*=0.95; } },
  twinBoss: { id:'bossTwin', name:'Lazo de las Gemelas', icon:'⚭', desc:'+4% robo de vida y +4% crítico', apply:p=>{ grantLifesteal(p,0.04); p.critChance+=0.04; } },
  trueFinal: { id:'bossTrueFinal', name:'Corazón del Verdadero Abismo', icon:'☉', desc:'+9% daño, +6% velocidad y +20 HP máx', apply:p=>{ p.dmgMult*=1.09; p.speedMult*=1.06; p.maxHp+=20; p.hp+=20; } },
};

const ULTIMATE_ABILITIES = [
  { id:'ira_celeste', name:'Ira Celeste', icon:'⚡', cd:42, color:'#ffd54a',
    desc:'Rayos golpean a todos los enemigos en pantalla',
    cast: p=>{
      [...game.enemies, ...bossTargets()].forEach(t=>{
        dealDamageToTarget(t, computeDamage(16), 'ult');
        addParticles(t.x,t.y,'#ffd54a',12,180,0.4);
      });
      shake(12);
    } },
  { id:'velo_vacio', name:'Velo del Vacío', icon:'◈', cd:30, color:'#6a8dff',
    desc:'Invulnerabilidad breve y explosión de daño a tu alrededor',
    cast: p=>{
      p.invuln = Math.max(p.invuln, 1.6);
      explodeAt(p.x,p.y,120, computeDamage(20));
    } },
  { id:'pacto_sangre', name:'Pacto de Sangre', icon:'♥', cd:38, color:'#e8434f',
    desc:'Cura el 28% de tu vida máxima al instante',
    cast: p=>{
      p.hp = Math.min(p.maxHp, p.hp + p.maxHp*0.28);
      addParticles(p.x,p.y,'#e8434f',24,170,0.5);
    } },
];

const ITEM_POOL = {
  common: [
    { id:'potion', name:'Poción de Vida', icon:'♥', desc:'+8 HP máx', apply:p=>{ p.maxHp+=8; p.hp+=8; } },
    { id:'boots', name:'Botas Veloces', icon:'👢', desc:'+4% velocidad', apply:p=>{ p.speedMult*=1.04; } },
    { id:'clover', name:'Trébol de la Suerte', icon:'☘', desc:'+3% prob. crítico', apply:p=>{ p.critChance+=0.03; } },
    { id:'flask', name:'Frasco Templado', icon:'✚', desc:'Regenera un poco de HP', apply:p=>{ p.regen+=0.35; } },
    { id:'dagger', name:'Filo Menor', icon:'✊', desc:'+3.5% daño', apply:p=>{ p.dmgMult*=1.035; } },
  ],
  rare: [
    { id:'gauntlet', name:'Guantelete de Fuerza', icon:'✊', desc:'+8% daño', apply:p=>{ p.dmgMult*=1.08; } },
    { id:'ring', name:'Anillo Vampírico', icon:'⦿', desc:'+3% robo de vida', apply:p=>{ grantLifesteal(p,0.03); } },
    { id:'amulet', name:'Amuleto Arcano', icon:'☥', desc:'-8% enfriamiento', apply:p=>{ p.cdMult*=0.92; } },
    { id:'skin', name:'Piel de Piedra', icon:'▣', desc:'+6% reducción de daño', apply:p=>{ p.armor+=0.06; } },
    { id:'regen', name:'Cristal de Regeneración', icon:'✚', desc:'Regenera HP con el tiempo', apply:p=>{ p.regen+=0.75; } },
    { id:'boots2', name:'Botas del Cazador', icon:'👢', desc:'+8% velocidad', apply:p=>{ p.speedMult*=1.08; } },
    { id:'effect_execute', name:'Filo Ejecutor', icon:'☠', desc:'Los golpes críticos ejecutan enemigos con menos de 12% de vida', apply:p=>{ p.relics.effect_execute=true; } },
    { id:'effect_thorns', name:'Talismán de Represalia', icon:'⛊', desc:'20% de prob. de liberar una onda de daño al recibir un golpe', apply:p=>{ p.relics.effect_thorns=true; } },
  ],
  epic: [
    { id:'phoenix', name:'Corazón de Fénix', icon:'♦', desc:'+20 HP máx', apply:p=>{ p.maxHp+=20; p.hp+=20; } },
    { id:'rage', name:'Fragmento de Furia', icon:'⚡', desc:'+14% daño, -8% HP máx', apply:p=>{ p.dmgMult*=1.14; const cut=p.maxHp*0.08; p.maxHp-=cut; p.hp=Math.max(1,p.hp-cut); } },
    { id:'crown', name:'Corona del Abismo', icon:'♛', desc:'+8% daño y +6% velocidad', apply:p=>{ p.dmgMult*=1.08; p.speedMult*=1.06; } },
    { id:'core', name:'Núcleo Arcano', icon:'☥', desc:'-14% enfriamiento', apply:p=>{ p.cdMult*=0.86; } },
    { id:'soul', name:'Fragmento de Alma', icon:'✦', desc:'+5% robo de vida y +5% crítico', apply:p=>{ grantLifesteal(p,0.05); p.critChance+=0.05; } },
    { id:'effect_deathburst', name:'Núcleo Volátil', icon:'☄', desc:'25% de prob. de que un enemigo derrotado libere una explosión de daño', apply:p=>{ p.relics.effect_deathburst=true; } },
  ],
};
const CURSED_ITEMS = [
  { id:'curse_blood', name:'Pacto de Sangre Eterno', icon:'☠', desc:'+18% daño, pero -18% HP máx', cursed:true,
    apply:p=>{ p.dmgMult*=1.18; const cut=p.maxHp*0.18; p.maxHp-=cut; p.hp=Math.max(1,p.hp-cut); } },
  { id:'curse_whisper', name:'Susurro del Abismo', icon:'👁', desc:'+10% daño y +6% velocidad, pero recibís 20% más daño', cursed:true,
    apply:p=>{ p.dmgMult*=1.10; p.speedMult*=1.06; p.curseDmgTakenMult*=1.20; } },
  { id:'curse_gold', name:'Oro Maldito', icon:'🜏', desc:'El oro que consigas vale x1.2, pero pierdes 20% de tu HP máx ya mismo', cursed:true,
    apply:p=>{ p.goldMult*=1.2; const cut=p.maxHp*0.20; p.maxHp-=cut; p.hp=Math.max(1,p.hp-cut); } },
  { id:'curse_haste', name:'Sed de Poder', icon:'⏳', desc:'-15% enfriamiento, pero -15% daño causado', cursed:true,
    apply:p=>{ p.cdMult*=0.85; p.dmgMult*=0.85; } },
  { id:'curse_shackle', name:'Grillete de Sombra', icon:'⛓', desc:'+15% velocidad de movimiento, pero -18% velocidad de ataque', cursed:true,
    apply:p=>{ p.speedMult*=1.15; p.cdMult*=1.18; } },
  { id:'curse_eye', name:'Ojo Codicioso', icon:'👁‍🗨', desc:'+30% de oro, pero -10% velocidad de movimiento', cursed:true,
    apply:p=>{ p.goldMult*=1.3; p.speedMult*=0.90; } },
  { id:'curse_coldheart', name:'Corazón Frío', icon:'❄', desc:'+10% crítico, pero reduce tu robo de vida a la mitad', cursed:true,
    apply:p=>{ p.critChance+=0.10; p.lifesteal*=0.5; } },
  { id:'curse_yoke', name:'Yugo del Poder', icon:'🔗', desc:'-18% enfriamiento de habilidades, pero -8% de armadura', cursed:true,
    apply:p=>{ p.cdMult*=0.82; p.armor=Math.max(0,p.armor-0.08); } },
];
const CURSED_CHEST_CHANCE = 0.14;
const POTIONS = [
  { id:'hp', key:'Digit1', name:'Poción de Vida', icon:'❤', desc:'Cura 25 HP al instante', color:'#e8434f' },
  { id:'def', key:'Digit2', name:'Poción de Resistencia', icon:'🛡', desc:'+30% reducción de daño por 6s', color:'#8a8f9c' },
  { id:'dmg', key:'Digit3', name:'Poción de Furia', icon:'⚔', desc:'+25% daño por 6s', color:'#ff6a3d' },
  { id:'spd', key:'Digit4', name:'Poción de Viento', icon:'💨', desc:'+30% velocidad por 6s', color:'#6a8dff' },
];
const UTILITY_CHEST_CHANCE = 0.05;
const RELICS = [
  { id:'relic_heart', name:'Corazón Eterno', icon:'❤', desc:'+50 HP máx instantáneo', apply:p=>{ p.maxHp+=50; p.hp+=50; } },
  { id:'relic_storm', name:'Tormenta Contenida', icon:'🌩', desc:'12% de prob. de encadenar un rayo a otro enemigo cercano', apply:p=>{} },
  { id:'relic_greed', name:'Codicia Infinita', icon:'💰', desc:'+25% de oro por el resto de la run', apply:p=>{ p.goldMult*=1.25; } },
  { id:'relic_phoenix', name:'Pluma de Fénix', icon:'🔥', desc:'Revive una vez con 50% de vida al morir', apply:p=>{} },
];
const RELIC_DROP_CHANCE = 0.35;

const ITEM_FAMILIES = {
  ofensiva: ['dagger','gauntlet','rage','crown','curse_blood','curse_whisper','bossBone','bossAbyss'],
  vital: ['potion','phoenix','flask','regen','bossEmpress','curse_gold','curse_eye'],
  mistica: ['amulet','core','clover','soul','curse_haste','curse_coldheart','curse_yoke','bossWitch','bossMirror','bossTwin','bossTrueFinal'],
  veloz: ['boots','boots2','ring','curse_shackle'],
};
const SYNERGY_THRESHOLD = 3;
const SYNERGIES = {
  ofensiva: { name:'Sinergia: Furia de Combate', desc:'+10% daño adicional', apply:p=>{ p.dmgMult*=1.10; } },
  vital: { name:'Sinergia: Vitalidad Plena', desc:'+8% robo de vida adicional', apply:p=>{ grantLifesteal(p,0.08); } },
  mistica: { name:'Sinergia: Resonancia Arcana', desc:'-10% enfriamiento adicional', apply:p=>{ p.cdMult*=0.90; } },
  veloz: { name:'Sinergia: Paso Ligero', desc:'+10% velocidad adicional', apply:p=>{ p.speedMult*=1.10; } },
};
function checkSynergies(p){
  Object.keys(ITEM_FAMILIES).forEach(fam=>{
    if(p.synergiesUnlocked[fam]) return;
    const count = p.items.filter(it=>ITEM_FAMILIES[fam].includes(it.id)).length;
    if(count>=SYNERGY_THRESHOLD){
      p.synergiesUnlocked[fam]=true;
      SYNERGIES[fam].apply(p);
      spawnToast(`🔗 ${SYNERGIES[fam].name} — ${SYNERGIES[fam].desc}`);
      addParticles(p.x,p.y,'#8ec9ff',24,200,0.5);
    }
  });
}
const CHEST_TIERS = {
  common: { label:'Común', costMult:1,   color:'#a89a8c', glow:'rgba(168,154,140,0.35)', wood:'#4a3620' },
  rare:   { label:'Raro',  costMult:2.2, color:'#6a8dff', glow:'rgba(106,141,255,0.45)', wood:'#213055' },
  epic:   { label:'Épico', costMult:4,   color:'#d24aff', glow:'rgba(210,74,255,0.55)', wood:'#3a1a4a' },
};

// ---------- traveling merchant: every 5 floors (5,15,25...95), offers a curated choice of 3 items ----------
const MERCHANT_INTERVAL = 5;
function isMerchantFloor(stageIndex){
  const floor = stageIndex+1;
  return floor%MERCHANT_INTERVAL===0 && floor%10!==0 && floor<TOWER_MAX_FLOOR;
}
function rollMerchantOffers(stageIndex){
  const s = stageAt(stageIndex);
  const pool = [
    ...ITEM_POOL.rare.map(it=>({item:it, tier:'rare'})),
    ...ITEM_POOL.epic.map(it=>({item:it, tier:'epic'})),
  ];
  const picks = [];
  const usedIds = new Set();
  while(picks.length<3 && picks.length<pool.length){
    const cand = pool[Math.floor(Math.random()*pool.length)];
    if(usedIds.has(cand.item.id)) continue;
    usedIds.add(cand.item.id);
    const cost = Math.round(s.chestCost*CHEST_TIERS[cand.tier].costMult*1.3);
    picks.push({ item:cand.item, tier:cand.tier, cost, bought:false });
  }
  return picks;
}


/* ============================================================
   INPUT
   ============================================================ */
const keys = {};
const mouse = { x:0, y:0, down:false };
let devKeyBuffer = '';
window.addEventListener('keydown', e=>{
  keys[e.code]=true;
  if(e.code==='Escape'){ if(merchantOpen) closeMerchant(); else togglePause(); }
  if(e.code==='Tab' && !merchantOpen){ e.preventDefault(); toggleInventory(); }
  if(['Space','KeyW','KeyA','KeyS','KeyD','KeyR','Digit1','Digit2','Digit3','Digit4'].includes(e.code)) e.preventDefault();
  // secret dev code: type "diosmodo" anywhere to toggle infinite HP + infinite damage for testing
  if(e.key && e.key.length===1){
    devKeyBuffer = (devKeyBuffer + e.key.toLowerCase()).slice(-8);
    if(devKeyBuffer==='diosmodo'){
      devMode = !devMode;
      devKeyBuffer='';
      spawnToast(devMode ? '🛠️ Modo desarrollador ACTIVADO — vida infinita, daño infinito y todos los personajes desbloqueados' : '🛠️ Modo desarrollador desactivado');
      updateDevModeBadge();
      buildRoster(); // refresh in case we're already on the character-select screen
    }
  }
});
window.addEventListener('keyup', e=>{ keys[e.code]=false; });
function updateDevModeBadge(){
  let el = document.getElementById('dev-mode-badge');
  if(!el){
    el = document.createElement('div');
    el.id = 'dev-mode-badge';
    el.textContent = '🛠️ MODO DESARROLLADOR — vida infinita / daño infinito';
    el.style.cssText = 'position:fixed;top:8px;left:50%;transform:translateX(-50%);z-index:99999;'
      + 'background:rgba(164,79,217,0.92);color:#fff;font-family:monospace;font-size:12px;'
      + 'padding:5px 14px;border-radius:0 0 8px 8px;letter-spacing:0.5px;pointer-events:none;'
      + 'box-shadow:0 2px 10px rgba(0,0,0,0.4);';
    document.body.appendChild(el);
  }
  el.style.display = devMode ? 'block' : 'none';

  // floor-jump box: only usable once a run is in progress, lets you warp straight to any
  // floor's boss fight (skipping the regular wave) to test it in isolation
  let jumpEl = document.getElementById('dev-floor-jump');
  if(!jumpEl){
    jumpEl = document.createElement('div');
    jumpEl.id = 'dev-floor-jump';
    jumpEl.style.cssText = 'position:fixed;top:36px;left:50%;transform:translateX(-50%);z-index:99999;'
      + 'display:flex;gap:6px;align-items:center;background:rgba(20,12,30,0.94);padding:5px 10px;'
      + 'border-radius:0 0 8px 8px;font-family:monospace;font-size:12px;color:#fff;'
      + 'box-shadow:0 2px 10px rgba(0,0,0,0.4);';
    jumpEl.innerHTML = `
      <span>Ir al piso:</span>
      <input id="dev-floor-input" type="number" min="1" max="${TOWER_MAX_FLOOR}" value="10"
        style="width:52px;background:#1a1024;border:1px solid #a44fd9;color:#fff;border-radius:4px;padding:2px 4px;font-family:monospace;">
      <button id="dev-floor-go" style="background:#a44fd9;border:none;color:#fff;border-radius:4px;padding:3px 10px;cursor:pointer;font-family:monospace;">Ir</button>
    `;
    document.body.appendChild(jumpEl);
    const input = document.getElementById('dev-floor-input');
    const go = document.getElementById('dev-floor-go');
    const jump = ()=>{ const val = parseInt(input.value,10); if(!isNaN(val)) devJumpToFloor(val); };
    go.addEventListener('click', jump);
    // stop keystrokes here from reaching the game's own WASD/dev-code listener on window
    input.addEventListener('keydown', e=>{ e.stopPropagation(); if(e.key==='Enter') jump(); });
  }
  jumpEl.style.display = devMode ? 'flex' : 'none';
}

// Warps straight to a given floor's boss fight, skipping the normal enemy wave — for testing a
// specific boss in isolation. Requires a run already in progress (a hero picked, game.player set).
function devJumpToFloor(floor){
  if(!game || !game.player){ spawnToast('Iniciá una partida primero para poder saltar de piso'); return; }
  floor = clamp(Math.round(floor), 1, TOWER_MAX_FLOOR);
  game.stageIndex = floor-1;
  syncCharacterLevel(game.player, game.stageIndex);
  hideScreen('screen-stage'); hideScreen('screen-clear'); hideScreen('screen-victory');
  $('hud').classList.remove('hidden');
  startStage(game.stageIndex);
  game.spawnQueue = []; // skip the wave entirely
  game.enemies = [];
  beginBossPhase();
  startLoop();
  spawnToast(`🛠️ Saltaste al piso ${floor}: ${game.currentStage.name}`);
}
canvas.addEventListener('mousemove', e=>{ mouse.x=e.clientX; mouse.y=e.clientY; });
canvas.addEventListener('mousedown', ()=>{ mouse.down=true; });
window.addEventListener('mouseup', ()=>{ mouse.down=false; });
function keyPressed(code){ // edge trigger
  if(keys[code] && !keys['__prev_'+code]){ return true; }
  return false;
}
function updateKeyEdges(){
  ['KeyQ','KeyE','Space','KeyR','Digit1','Digit2','Digit3','Digit4'].forEach(c=>{ keys['__prev_'+c]=keys[c]; });
}

/* ============================================================
   GAME STATE
   ============================================================ */
let game = null; // active run state
let devMode = false; // secret dev/test mode: infinite HP + one-shot damage (toggled by typing "diosmodo")
let selectedHero = null;
const PACTS = [
  { id:'hardMode', name:'Pacto del Enjambre', desc:'+30% vida/daño de enemigos, pero +15% de oro', icon:'⚔' },
  { id:'noHeal', name:'Pacto de Sangre Seca', desc:'Sin regeneración pasiva ni robo de vida, pero +20% daño', icon:'☠' },
  { id:'glassRun', name:'Pacto Frágil', desc:'-25% de tu vida máxima inicial, pero +25% de velocidad', icon:'💨' },
];
let selectedPacts = {};
function buildPacts(){
  const row = $('pacts-row');
  if(!row) return;
  row.innerHTML = PACTS.map(pc=>`
    <div class="route-card${selectedPacts[pc.id]?' selected':''}" data-pact="${pc.id}">
      <div class="ic">${pc.icon}</div>
      <div class="nm">${pc.name}</div>
      <div class="ds">${pc.desc}</div>
    </div>
  `).join('');
  row.querySelectorAll('.route-card').forEach(card=>{
    card.addEventListener('click', ()=>{
      const id = card.dataset.pact;
      selectedPacts[id] = !selectedPacts[id];
      card.classList.toggle('selected');
    });
  });
}

const HOME_UPGRADES = [
  { id:'hp', name:'Vitalidad', desc:'+6 HP máx inicial', icon:'♥', baseCost:20 },
  { id:'gold', name:'Fortuna', desc:'+5% de oro (multiplicativo)', icon:'◆', baseCost:25 },
  { id:'dmg', name:'Instinto', desc:'+2% daño inicial', icon:'⚔', baseCost:30 },
];
function homeUpgradeCost(id){
  const count = progress.homeUpgrades[id]||0;
  const def = HOME_UPGRADES.find(u=>u.id===id);
  return Math.round(def.baseCost * Math.pow(1.35, count));
}
function buyHomeUpgrade(id){
  const cost = homeUpgradeCost(id);
  if(progress.essence<cost) return;
  progress.essence -= cost;
  progress.homeUpgrades[id] = (progress.homeUpgrades[id]||0)+1;
  buildHomeAltar();
}
function buildHomeAltar(){
  const row = $('home-altar-row');
  if(!row) return;
  $('essence-count').textContent = progress.essence;
  $('best-stage-count').textContent = progress.bestStage;
  row.innerHTML = HOME_UPGRADES.map(u=>{
    const count = progress.homeUpgrades[u.id]||0;
    const cost = homeUpgradeCost(u.id);
    const affordable = progress.essence>=cost;
    return `<div class="ult-card">
      <div class="ic" style="color:var(--gold)">${u.icon}</div>
      <div class="nm">${u.name}${count>0?` (x${count})`:''}</div>
      <div class="ds">${u.desc}</div>
      <button class="btn ghost" style="margin-top:8px; padding:6px 14px; font-size:11px;" ${affordable?'':'disabled'} data-upgrade="${u.id}">${cost} esencia</button>
    </div>`;
  }).join('');
  row.querySelectorAll('button[data-upgrade]').forEach(btn=>{
    btn.addEventListener('click', ()=> buyHomeUpgrade(btn.dataset.upgrade));
  });
}
let paused = false;
let inventoryOpen = false;
let merchantOpen = false;
let animId = null;

function freshPlayerStats(heroDef){
  const ultCooldowns = {};
  progress.unlockedAbilities.forEach(id=>{ ultCooldowns[id]=0; });
  const hpMult = selectedPacts.glassRun ? 0.75 : 1;
  const startHp = heroDef.hp*hpMult;
  const p = {
    def:heroDef,
    x:0,y:0, radius:18, facing:0,
    hp:startHp, maxHp:startHp,
    speedMult: selectedPacts.glassRun ? 1.25 : 1,
    dmgMult: selectedPacts.noHeal ? 1.2 : 1,
    cdMult:1, armor:0, critChance:0.05, lifesteal:0, regen:0, shield:0,
    curseDmgTakenMult:1, goldMult:1, slowTimer:0, slowFactor:1,
    atkTimer:0, qTimer:0, eTimer:0, ultCooldowns,
    invuln:0, // brief i-frames
    effects:{ warcry:0, blink:0, shadow:0, shadowCrit:false, wall:0 },
    items:[], families:{}, synergiesUnlocked:{}, relics:{}, phoenixUsed:false,
    stance:'melee', // hybrid class only
    combo:0, comboMult:1, comboTimer:0, timeSinceHit:999, witherTimer:0,
    potions:{hp:0,def:0,dmg:0,spd:0}, potionEffects:{def:0,dmg:0,spd:0},
    facingX:1, facingY:0,
    charLevel:1, // starts at 1 each run, rises as the player descends (see levelUpCharacterTo)
  };
  const hpUp = progress.homeUpgrades.hp||0;
  const goldUp = progress.homeUpgrades.gold||0;
  const dmgUp = progress.homeUpgrades.dmg||0;
  if(hpUp){ p.maxHp += 8*hpUp; p.hp += 8*hpUp; }
  if(goldUp){ p.goldMult *= Math.pow(1.08, goldUp); }
  if(dmgUp){ p.dmgMult *= Math.pow(1.03, dmgUp); }
  return p;
}

// ---------- character level scaling ----------
// Each hero grows in whichever stat defines their class (melee -> HP, caster -> damage, etc,
// see the `scaling` field on each HEROES entry). Level starts at 1 each run and rises with depth.
const LEVEL_FLOORS_PER_STEP = 5; // one level every 5 floors, in sync with the merchant cadence
function characterLevelForFloorIndex(stageIndex){
  return 1 + Math.floor(stageIndex / LEVEL_FLOORS_PER_STEP);
}
function applyStatScaling(p, scaling){
  if(scaling.stat==='hp'){
    const add = p.maxHp*scaling.perLevel;
    p.maxHp += add; p.hp += add;
  } else if(scaling.stat==='dmg'){
    p.dmgMult *= (1+scaling.perLevel);
  } else if(scaling.stat==='crit'){
    p.critChance += scaling.perLevel;
  } else if(scaling.stat==='cd'){
    p.cdMult *= (1-scaling.perLevel);
  }
}
function levelUpCharacterOnce(p){
  const scaling = p.def.scaling;
  if(!scaling) return;
  (Array.isArray(scaling) ? scaling : [scaling]).forEach(s=>applyStatScaling(p, s));
}
const LIFESTEAL_CAP = 0.10;
// Lifesteal is capped at 10% healing — anything an item/relic/synergy would push past that cap
// is instead converted into a permanent bonus to whatever stat defines the character's class,
// so the value isn't just wasted once you're capped out.
function grantLifesteal(p, amount){
  p.lifesteal += amount;
  if(p.lifesteal > LIFESTEAL_CAP){
    const overflow = p.lifesteal - LIFESTEAL_CAP;
    p.lifesteal = LIFESTEAL_CAP;
    const scaling = p.def.scaling;
    if(scaling){
      const first = Array.isArray(scaling) ? scaling[0] : scaling;
      applyStatScaling(p, { stat:first.stat, perLevel: overflow*1.5 });
    }
  }
}
// Call whenever game.stageIndex changes — brings the character up to the level the current
// floor calls for, applying each intermediate level-up in order so bonuses compound correctly.
function syncCharacterLevel(p, stageIndex){
  const target = characterLevelForFloorIndex(stageIndex);
  while(p.charLevel < target){
    levelUpCharacterOnce(p);
    p.charLevel++;
  }
}

function newGame(){
  return {
    stageIndex:0,
    currentStage: stageAt(0),
    gold:0,
    player: freshPlayerStats(selectedHero),
    world: computeWorldBounds(),
    camera: {x:0, y:0},
    enemies:[], projectiles:[], hazards:[], particles:[], goldOrbs:[], chests:[], swings:[], relicPickups:[], utilityChests:[],
    altar:null, boss:null, bossCountdown:null, portal:null, pet:null, sacrificeAltar:null, merchant:null,
    phase:'combat', // combat | shopping | bossIntro | boss | portal | clear
    spawnQueue:[],
    stagesSinceMirror:0, stagesSinceTwin:0, // bad-luck protection so these bosses can't stay hidden by pure RNG
    shake:0,
    kills:0,
    time:0,
    pacts: {...selectedPacts}, pendingRoute:null, routeGoldMult:1, routeEliteBoost:false, routeSpecialBuff:false,
    stats:{ bossesThisRun:0, stageReached:0, noHitBoss:false, bossTookDamage:false },
  };
}

/* ============================================================
   MENU / CHARACTER SELECT
   ============================================================ */
function buildRoster(){
  const roster = $('roster');
  roster.innerHTML='';
  Object.values(HEROES).forEach(h=>{
    const isLocked = h.locked && !progress.unlocked[h.id] && !devMode;
    const card = document.createElement('div');
    card.className='hero-card'+(isLocked?' locked':'');
    card.style.setProperty('--accent-c', isLocked ? '#4a4256' : h.accent);
    card.style.setProperty('--glow-c', isLocked ? 'rgba(74,66,86,0.25)' : h.glow);
    if(isLocked){
      const ach = ACHIEVEMENTS.find(a=>a.unlocks===h.id);
      card.style.opacity='0.55'; card.style.cursor='not-allowed';
      card.innerHTML = `
        <div class="rune-circle" style="filter:grayscale(1);">🔒</div>
        <div class="hero-name">???</div>
        <div class="hero-class">${h.className}</div>
        <div class="hero-abilities" style="text-align:center; border-top:1px solid var(--line); padding-top:10px;">
          <div style="color:var(--bone-dim);">Logro: <b style="color:var(--bone);">${ach.name}</b></div>
          <div style="margin-top:4px; font-size:11px;">${ach.desc}</div>
        </div>
      `;
    } else {
      card.innerHTML = `
        <div class="rune-circle">${h.icon}</div>
        <div class="hero-name">${h.name}</div>
        <div class="hero-class">${h.className}</div>
        <div class="hero-stats">
          <div class="hero-stat"><b>${h.hp}</b>VIDA</div>
          <div class="hero-stat"><b>${(h.atk||h.atkMelee).kind==='melee'?'Cuerpo':'Distancia'}</b>ATAQUE</div>
        </div>
        <div class="hero-abilities">
          <div><span class="k">Q</span>${h.q.name} — ${h.q.desc}</div>
          <div style="margin-top:5px;"><span class="k">E</span>${h.e.name} — ${h.e.desc}</div>
        </div>
      `;
      card.addEventListener('click', ()=>{
        document.querySelectorAll('.hero-card').forEach(c=>c.classList.remove('selected'));
        card.classList.add('selected');
        selectedHero = h;
        $('btn-start').disabled=false;
      });
    }
    roster.appendChild(card);
  });
}

function buildUltimates(){
  const row = $('ultimates-row');
  if(!row) return;
  row.innerHTML = ULTIMATE_ABILITIES.map(a=>{
    const unlocked = progress.unlockedAbilities.includes(a.id);
    return `<div class="ult-card${unlocked?'':' locked'}">
        <div class="ic" style="color:${unlocked?a.color:'var(--bone-dim)'}">${unlocked?a.icon:'🔒'}</div>
        <div class="nm">${unlocked?a.name:'???'}</div>
        <div class="ds">${unlocked?a.desc:'Cae raramente (5%) al derrotar a un jefe'}</div>
      </div>`;
  }).join('');
}
buildRoster();
buildUltimates();
buildHomeAltar();
buildPacts();

$('btn-start').addEventListener('click', ()=>{
  game = newGame();
  hideScreen('screen-menu');
  showScreen('screen-stage');
  setStageIntro(0);
});

$('btn-enter-stage').addEventListener('click', ()=>{
  hideScreen('screen-stage');
  $('hud').classList.remove('hidden');
  startStage(game.stageIndex);
  startLoop();
});

$('btn-next-stage').addEventListener('click', ()=>{
  hideScreen('screen-clear');
  game.stageIndex++;
  syncCharacterLevel(game.player, game.stageIndex);
  showScreen('screen-stage');
  setStageIntro(game.stageIndex);
});

$('btn-victory-restart').addEventListener('click', ()=>{ resetToMenu(); });
$('btn-retry').addEventListener('click', ()=>{
  game = newGame();
  hideScreen('screen-gameover');
  $('hud').classList.remove('hidden');
  startStage(0);
  startLoop();
});
$('btn-menu').addEventListener('click', ()=>{ resetToMenu(); });
$('btn-resume').addEventListener('click', ()=>{ togglePause(); });
$('btn-pause-menu').addEventListener('click', ()=>{ resetToMenu(); });

function resetToMenu(){
  stopLoop();
  game=null;
  paused=false;
  closeInventory();
  document.querySelectorAll('.screen').forEach(s=>s.classList.add('hidden'));
  $('hud').classList.add('hidden');
  $('screen-menu').classList.remove('hidden');
  buildRoster();
  buildUltimates();
  buildHomeAltar();
  buildPacts();
}

function showScreen(id){ $(id).classList.remove('hidden'); }
function hideScreen(id){ $(id).classList.add('hidden'); }

document.querySelectorAll('.screen').forEach(s=>{ if(s.id!=='screen-menu') s.classList.add('hidden'); });

const ROUTES = [
  { id:'blood', name:'Camino de Sangre', icon:'⚔', desc:'+35% enemigos, pero -22% oro por enemigo' },
  { id:'risk', name:'Camino del Riesgo', icon:'☠', desc:'Los enemigos especiales tienen +50% vida y velocidad' },
];

function setStageIntro(i){
  const s = stageAt(i);
  $('stage-eyebrow').textContent = `Piso ${i+1} / ${TOWER_MAX_FLOOR}`;
  $('stage-title').textContent = s.name;
  $('stage-desc').textContent = s.desc;
  buildRoutes();
}

function buildRoutes(){
  const row = $('route-row');
  if(!row || !game) return;
  if(!game.pendingRoute) game.pendingRoute = 'blood';
  row.innerHTML = ROUTES.map(r=>`
    <div class="route-card${game.pendingRoute===r.id?' selected':''}" data-route="${r.id}">
      <div class="ic">${r.icon}</div>
      <div class="nm">${r.name}</div>
      <div class="ds">${r.desc}</div>
    </div>
  `).join('');
  row.querySelectorAll('.route-card').forEach(card=>{
    card.addEventListener('click', ()=>{
      game.pendingRoute = card.dataset.route;
      row.querySelectorAll('.route-card').forEach(c=>c.classList.remove('selected'));
      card.classList.add('selected');
    });
  });
}

/* ============================================================
   STAGE / WAVE SETUP
   ============================================================ */
function startStage(i){
  const s = stageAt(i);
  game.currentStage = s;
  const b = arenaBounds();
  game.player.x = b.x + b.w/2;
  game.player.y = b.y + b.h/2;
  game.enemies=[]; game.projectiles=[]; game.hazards=[]; game.goldOrbs=[]; game.chests=[]; game.swings=[]; game.shockwaves=[]; game.afterimages=[];
  game.altar=null; game.boss=null; game.bossCountdown=null; game.portal=null; game.pet=null; game.sacrificeAltar=null; game.relicPickups=[]; game.utilityChests=[]; game.merchant=null;
  game.phase='combat';

  const route = game.pendingRoute || 'blood';
  game.routeGoldMult = route==='blood' ? 0.78 : 1; // more kills but less gold per kill — used to be a free lunch
  game.routeEliteBoost = false;
  game.routeSpecialBuff = route==='risk';
  const routeEnemyMult = route==='blood' ? 1.35 : 1;
  game.pendingRoute = null;

  const kinds = s.enemyKinds;
  const total = Math.max(4, Math.round((6 + Math.round(i*3.6)) * routeEnemyMult));
  const specialChance = i<2 ? 0 : clamp(0.06+i*0.012, 0.06, 0.3);
  const specialKinds = ['bomber','shielded','erratic','sniper','swarmling'];
  const queue=[];
  for(let n=0;n<total;n++){
    let kind = kinds[n%kinds.length];
    if(Math.random()<specialChance) kind = specialKinds[Math.floor(Math.random()*specialKinds.length)];
    queue.push({ kind, delay: n*Math.max(0.22, 0.5-i*0.015) + Math.random()*0.3 });
  }
  game.spawnQueue = queue;
  $('hud-stage-eyebrow').textContent = `Piso ${i+1} / ${TOWER_MAX_FLOOR}`;
  $('hud-stage-name').textContent = s.name;
  updatePhaseNote();

  game.stats.stageReached = Math.max(game.stats.stageReached, i+1);
  checkAchievements();
}

function updatePhaseNote(){
  const notes = {
    combat:'Elimina a todos los enemigos',
    shopping:'Compra cofres y activa el altar',
    bossIntro:'El jefe está despertando...',
    boss:'¡Derrota al jefe!',
    portal:'Entra al portal para continuar',
  };
  $('hud-phase-note').textContent = notes[game.phase] || '';
}

const SPECIAL_ENEMY_KINDS = ['bomber','shielded','erratic','sniper','swarmling'];

function spawnEnemyAt(kind, x, y, isBossMinion, isElite){
  const def = ENEMY_DEFS[kind];
  const hardMult = game.pacts.hardMode ? 1.3 : 1;
  const hpMult = ((game.currentStage && game.currentStage.enemyHpMult) || 1) * hardMult;
  const dmgMult = ((game.currentStage && game.currentStage.enemyDmgMult) || 1) * hardMult;
  let hp = Math.round(def.hp*hpMult);
  let dmg = Math.round(def.dmg*dmgMult);
  let goldMin = def.gold[0], goldMax = def.gold[1];
  if(isElite){
    hp = Math.round(hp*ELITE_MULT.hp);
    dmg = Math.round(dmg*ELITE_MULT.dmg);
    goldMin = Math.round(goldMin*ELITE_MULT.gold); goldMax = Math.round(goldMax*ELITE_MULT.gold);
  }
  const specialBuffed = game.routeSpecialBuff && SPECIAL_ENEMY_KINDS.includes(kind);
  let speedMult = 1;
  if(specialBuffed){ hp = Math.round(hp*1.3); speedMult = 1.25; }
  game.enemies.push({
    kind, def, x, y, hp, maxHp:hp, dmg, radius:def.radius*(isElite?1.35:1),
    atkTimer: Math.random()*def.atkCd, hitFlash:0, poisonTimer:0, isBossMinion:!!isBossMinion,
    isElite:!!isElite, goldMin, goldMax, armorHp: def.armor||0, wanderAng: Math.random()*Math.PI*2,
    speedMult,
  });
}

function spawnFromEdge(kind){
  const b = arenaBounds();
  const side = Math.floor(Math.random()*4);
  let x,y;
  if(side===0){ x=b.x+Math.random()*b.w; y=b.y+8; }
  else if(side===1){ x=b.x+Math.random()*b.w; y=b.y+b.h-8; }
  else if(side===2){ x=b.x+8; y=b.y+Math.random()*b.h; }
  else { x=b.x+b.w-8; y=b.y+Math.random()*b.h; }
  spawnEnemyAt(kind, x, y, false, Math.random()<ELITE_CHANCE*(game.routeEliteBoost?2.5:1));
}

function beginShoppingPhase(){
  game.phase='shopping';
  updatePhaseNote();
  const b = arenaBounds();
  const s = game.currentStage;
  const layout = [
    { x:b.x+b.w*0.20, y:b.y+b.h*0.76, tier:'common' },
    { x:b.x+b.w*0.40, y:b.y+b.h*0.86, tier:'common' },
    { x:b.x+b.w*0.62, y:b.y+b.h*0.86, tier:'rare' },
    { x:b.x+b.w*0.82, y:b.y+b.h*0.76, tier:'epic' },
  ];
  game.chests = layout.map(p=>{
    const t = CHEST_TIERS[p.tier];
    return { x:p.x, y:p.y, radius: p.tier==='epic'?24:(p.tier==='rare'?21:18), tier:p.tier,
      cost: Math.round(s.chestCost*t.costMult), opened:false, bob:Math.random()*10, sparkTimer:Math.random()*0.6 };
  });
  game.altar = { x:b.x+b.w/2, y:b.y+b.h*0.22, radius:30, active:true, pulse:0 };
  game.sacrificeAltar = { x:b.x+b.w*0.10, y:b.y+b.h*0.48, radius:24, used:false, pulse:0 };
  if(isMerchantFloor(game.stageIndex)){
    game.merchant = { x:b.x+b.w*0.90, y:b.y+b.h*0.48, radius:26, offers: rollMerchantOffers(game.stageIndex), pulse:0 };
    spawnToast(`Un mercader errante ofrece 3 objetos a elección.`);
  }
  spawnToast(`Sala del tesoro. Cofres comunes, raros y épicos disponibles.`);
}

// Player walks up to the active altar -> a 3..2..1 countdown plays before the boss actually appears,
// so nothing can hit the player the instant the fight starts.
function startBossCountdown(){
  game.phase='bossIntro';
  updatePhaseNote();
  game.bossCountdown = 3.0;
  game.altar.active=false;
  game.chests.forEach(c=>c.opened=true); // chests close once the ritual begins
  game.sacrificeAltar = null;
  spawnToast('El altar se enciende...');
  shake(3);
}

function pickBossKindForStage(i){
  return stageAt(i).bossKind;
}

function beginBossPhase(){
  game.phase='boss';
  updatePhaseNote();
  const s = game.currentStage;
  const bossKind = pickBossKindForStage(game.stageIndex);
  const def = BOSS_DEFS[bossKind];
  const b = arenaBounds();
  const isTrueFinal = bossKind==='trueFinal';
  const guardianMult = s.isGuardianFloor && !isTrueFinal ? 1.5 : 1; // guardian floors (10, 20, 30...) hit noticeably harder
  const hp = Math.round(def.hp*s.hpMult*(isTrueFinal?1.3:2.6)*guardianMult);
  let dmg = Math.round(def.dmg*s.dmgMult*guardianMult);
  const hover = bossKind==='empressOfLight';
  const isGuardian = s.isGuardianFloor && !isTrueFinal;
  // regular bosses attack frequently with lower per-hit damage; guardians (10, 20, 30...) instead
  // attack less often, a bit harder, but the real difficulty comes from those attacks being much
  // harder to dodge (faster projectiles, shorter reaction windows — see isGuardian usage below)
  let dmgReduceFactor = hover ? 0.55 : 0.72;
  if(isGuardian) dmgReduceFactor *= 1.15;
  dmg = Math.round(dmg*dmgReduceFactor);
  game.boss = {
    kind:bossKind, def, x:b.x+b.w/2, y:b.y+b.h*0.3, hp, maxHp:hp, dmg, radius:def.radius,
    attackTimer:1.4, phase:1, telegraph:null, contactTimer:0, hitFlash:0, spawnGrace:1.1, hover, petalTimer:0,
    twin:null, strafeDir: Math.random()<0.5?1:-1, isGuardian,
  };
  if(bossKind==='twinBoss'){
    game.boss.twin = { x:b.x+b.w/2-90, y:b.y+b.h*0.3, hp, maxHp:hp, radius:def.radius*0.85, hitFlash:0, alive:true, def };
  }
  $('boss-hp-wrap').classList.add('show');
  $('boss-name').textContent = def.name + (s.isGuardianFloor && !isTrueFinal ? ' — Guardián de Piso' : '');
  spawnToast(`${def.title}`);
  game.player.invuln = Math.max(game.player.invuln, 1.1); // safety cushion as the boss materializes
  game.stats.bossTookDamage = false;
  shake(6);
}

function onStageClear(){
  // sweep up anything still lying on the floor — gold, potions, relics — so nothing is lost
  // just because the player didn't walk over it before heading to the portal
  if(game.goldOrbs && game.goldOrbs.length){
    let swept = 0;
    const p = game.player;
    game.goldOrbs.forEach(g=>{ swept += Math.round(g.value * p.goldMult * (game.pacts.hardMode ? 1.15 : 1) * comboFactor(p) * game.routeGoldMult); });
    if(swept>0){ game.gold += swept; spawnToast(`💰 Recogiste ${swept} de oro que quedó en el piso`); }
    game.goldOrbs = [];
  }
  if(game.utilityChests && game.utilityChests.length){
    game.utilityChests.forEach(uc=>{
      const potion = POTIONS[Math.floor(Math.random()*POTIONS.length)];
      game.player.potions[potion.id]++;
    });
    game.utilityChests = [];
  }
  if(game.relicPickups && game.relicPickups.length){
    game.relicPickups.forEach(rp=>{
      if(!game.player.relics[rp.relic.id]){
        rp.relic.apply(game.player);
        game.player.relics[rp.relic.id] = true;
        game.player.items.push({ id:rp.relic.id, name:rp.relic.name, icon:rp.relic.icon, desc:rp.relic.desc });
      }
    });
    game.relicPickups = [];
  }
  game.phase='clear';
  closeInventory();
  $('boss-hp-wrap').classList.remove('show');
  stopLoop();
  if(game.stageIndex >= TOWER_MAX_FLOOR-1){
    finishVictory();
    return;
  }
  $('clear-title').textContent = `${game.currentStage.name}: superada`;
  showScreen('screen-clear');
}

function finishVictory(){
  stopLoop();
  $('hud').classList.add('hidden');
  progress.bestStage = Math.max(progress.bestStage, TOWER_MAX_FLOOR);
  $('victory-summary').innerHTML = `
    <div id="run-summary">
      Personaje: <b>${game.player.def.name}</b><br>
      Torre conquistada: <b>Piso ${TOWER_MAX_FLOOR}/${TOWER_MAX_FLOOR}</b><br>
      Enemigos eliminados: <b>${game.kills}</b><br>
      Oro final: <b>${game.gold}</b><br>
      Objetos obtenidos: <b>${game.player.items.length}</b>
    </div>`;
  showScreen('screen-victory');
}

function onPlayerDeath(){
  stopLoop();
  closeInventory();
  $('hud').classList.add('hidden');
  const essenceGained = Math.round(game.stats.stageReached*1.5 + game.kills*0.12 + game.stats.bossesThisRun*4);
  progress.essence += essenceGained;
  progress.bestStage = Math.max(progress.bestStage, game.stats.stageReached);
  $('gameover-summary').innerHTML = `
    <div id="run-summary">
      Piso alcanzado: <b>${game.currentStage.name}</b> (#${game.stageIndex+1} / ${TOWER_MAX_FLOOR})<br>
      Jefes derrotados: <b>${game.stats.bossesThisRun}</b><br>
      Enemigos eliminados: <b>${game.kills}</b><br>
      Oro reunido: <b>${game.gold}</b><br>
      Esencia ganada: <b>+${essenceGained}</b> (total: ${progress.essence})<br>
      Récord de profundidad: <b>Piso ${progress.bestStage}</b>
    </div>`;
  showScreen('screen-gameover');
}

/* ============================================================
   PAUSE / LOOP
   ============================================================ */
function togglePause(){
  if(!game || game.phase==='clear') return;
  if(!$('hud') || $('hud').classList.contains('hidden')) return;
  paused=!paused;
  if(paused){ showScreen('screen-pause'); }
  else { hideScreen('screen-pause'); }
}

function toggleInventory(){
  if(!game) return;
  if(!$('hud') || $('hud').classList.contains('hidden')) return;
  if(paused) return;
  inventoryOpen = !inventoryOpen;
  if(inventoryOpen){ buildInventoryPanel(); $('inventory-panel').classList.remove('hidden'); }
  else { $('inventory-panel').classList.add('hidden'); }
}

function closeInventory(){
  inventoryOpen = false;
  $('inventory-panel').classList.add('hidden');
}

function openMerchant(){
  if(!game || !game.merchant) return;
  if(paused || inventoryOpen) return;
  merchantOpen = true;
  buildMerchantPanel();
  $('merchant-panel').classList.remove('hidden');
}
function closeMerchant(){
  merchantOpen = false;
  $('merchant-panel').classList.add('hidden');
}
function buildMerchantPanel(){
  const m = game.merchant;
  if(!m) return;
  $('merchant-gold').textContent = game.gold;
  $('merchant-list').innerHTML = m.offers.map((o,idx)=>{
    const tier = CHEST_TIERS[o.tier];
    const afford = game.gold>=o.cost && !o.bought && !m.chosen;
    return `
    <div class="merchant-item ${o.bought?'bought':''}" style="--tc:${tier.color}" data-idx="${idx}">
      <div class="ic">${o.item.icon}</div>
      <div class="body">
        <div class="nm">[${tier.label}] ${o.item.name}</div>
        <div class="ds">${o.item.desc}</div>
      </div>
      <button class="btn ghost merchant-buy" data-idx="${idx}" ${afford?'':'disabled'}>${o.bought?'Comprado':(o.cost+' ◆')}</button>
    </div>`;
  }).join('');
  $('merchant-list').querySelectorAll('.merchant-buy').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const idx = parseInt(btn.getAttribute('data-idx'));
      buyMerchantOffer(idx);
    });
  });
}
function buyMerchantOffer(idx){
  const m = game.merchant;
  if(!m || m.chosen) return;
  const o = m.offers[idx];
  if(!o || o.bought) return;
  if(game.gold<o.cost){ spawnToast(`Necesitas ${o.cost} de oro para este objeto.`); return; }
  game.gold -= o.cost;
  o.bought = true;
  m.chosen = true; // the merchant only sells one item per visit — the choice is made
  const p = game.player;
  o.item.apply(p);
  p.items.push(o.item);
  checkSynergies(p);
  spawnToast(`${o.item.icon} [Mercader] ${o.item.name} — ${o.item.desc}`);
  addParticles(m.x,m.y,CHEST_TIERS[o.tier].color,26,200,0.5);
  buildMerchantPanel();
}
$('merchant-close') && $('merchant-close').addEventListener('click', closeMerchant);

function buildInventoryPanel(){
  const p = game.player;
  $('inv-stats').innerHTML = `
    <div>Daño: <b>×${p.dmgMult.toFixed(2)}</b></div>
    <div>Velocidad: <b>×${p.speedMult.toFixed(2)}</b></div>
    <div>Enfriamiento: <b>×${p.cdMult.toFixed(2)}</b></div>
    <div>Armadura: <b>${Math.round(p.armor*100)}%</b></div>
    <div>Robo de vida: <b>${Math.round(p.lifesteal*100)}%</b></div>
    <div>Crítico: <b>${Math.round(p.critChance*100)}%</b></div>
    <div>Regeneración: <b>${p.regen.toFixed(1)}/s</b></div>
    <div>Oro: <b>${game.gold}</b></div>
  `;
  const list = $('inv-list');
  if(!p.items.length){
    list.innerHTML = '<div class="inv-empty">Todavía no conseguiste objetos en esta run.</div>';
    return;
  }
  const counts = {};
  p.items.forEach(it=>{
    if(!counts[it.id]) counts[it.id] = { item:it, n:0 };
    counts[it.id].n++;
  });
  list.innerHTML = Object.values(counts).map(({item,n})=>`
    <div class="inv-item">
      <div class="ic">${item.icon}</div>
      <div>
        <div class="nm">${item.name}${n>1?` ×${n}`:''}</div>
        <div class="ds">${item.desc}</div>
      </div>
    </div>
  `).join('');
}

let lastT = 0;
let stopRequested = false;
function startLoop(){
  stopRequested = false;
  lastT = performance.now();
  if(animId) cancelAnimationFrame(animId);
  animId = requestAnimationFrame(loop);
}
function stopLoop(){ stopRequested = true; if(animId) cancelAnimationFrame(animId); animId=null; }

function loop(t){
  if(stopRequested) return;
  const dt = Math.min(0.033, (t-lastT)/1000);
  lastT=t;
  if(!paused && !inventoryOpen && !merchantOpen && game && (game.phase==='combat'||game.phase==='shopping'||game.phase==='bossIntro'||game.phase==='boss'||game.phase==='portal')){
    update(dt);
  }
  if(stopRequested) return;
  render();
  updateKeyEdges();
  animId = requestAnimationFrame(loop);
}

/* ============================================================
   HELPERS
   ============================================================ */
function dist(ax,ay,bx,by){ return Math.hypot(ax-bx, ay-by); }
function clamp(v,a,b){ return Math.max(a,Math.min(b,v)); }
function rand(a,b){ return a+Math.random()*(b-a); }
function spawnToast(msg){
  const el = document.createElement('div');
  el.className='item-toast';
  el.textContent = msg;
  $('toast-layer').appendChild(el);
  setTimeout(()=>el.remove(), 3100);
}
function shake(amount){ game.shake = Math.max(game.shake, amount); }

function addParticles(x,y,color,count,speed,life){
  for(let i=0;i<count;i++){
    const a = Math.random()*Math.PI*2;
    const s = rand(speed*0.4, speed);
    game.particles.push({ x,y, vx:Math.cos(a)*s, vy:Math.sin(a)*s, life, maxLife:life, color, r:rand(2,4), type:'circle' });
  }
}
function addDamageText(x,y,val,color,crit){
  game.particles.push({ x, y, vx:rand(-20,20), vy:-70, life:0.7, maxLife:0.7, color, type:'text',
    text:(crit?'¡':'')+Math.round(val)+(crit?'!':''), size: crit?20:15 });
}

/* ============================================================
   UPDATE
   ============================================================ */
function update(dt){
  game.time+=dt;
  const b = arenaBounds();
  const p = game.player;

  // --- boss ritual countdown (3..2..1) before the boss actually appears ---
  if(game.phase==='bossIntro'){
    game.bossCountdown -= dt;
    if(game.bossCountdown<=0){ beginBossPhase(); }
  }

  // --- spawn queue ---
  if(game.phase==='combat'){
    game.spawnQueue.forEach(s=>s.delay-=dt);
    while(game.spawnQueue.length && game.spawnQueue[0].delay<=0){
      const s = game.spawnQueue.shift();
      spawnFromEdge(s.kind);
    }
    if(game.spawnQueue.length===0 && game.enemies.length===0){
      beginShoppingPhase();
    }
  }

  // --- player timers ---
  p.atkTimer = Math.max(0,p.atkTimer-dt);
  p.qTimer = Math.max(0,p.qTimer-dt);
  p.eTimer = Math.max(0,p.eTimer-dt);
  p.invuln = Math.max(0,p.invuln-dt);
  p.effects.warcry = Math.max(0,p.effects.warcry-dt);
  p.effects.shadow = Math.max(0,p.effects.shadow-dt);
  p.effects.wall = Math.max(0,p.effects.wall-dt);
  p.potionEffects.def = Math.max(0,p.potionEffects.def-dt);
  p.potionEffects.dmg = Math.max(0,p.potionEffects.dmg-dt);
  p.potionEffects.spd = Math.max(0,p.potionEffects.spd-dt);
  p.witherTimer = Math.max(0,p.witherTimer-dt);
  p.slowTimer = Math.max(0,(p.slowTimer||0)-dt);
  p.invertTimer = Math.max(0,(p.invertTimer||0)-dt);
  p.chillTimer = Math.max(0,(p.chillTimer||0)-dt);
  p.weakenTimer = Math.max(0,(p.weakenTimer||0)-dt);
  p.qLockTimer = Math.max(0,(p.qLockTimer||0)-dt);
  p.eLockTimer = Math.max(0,(p.eLockTimer||0)-dt);
  if(p.combo>0){ p.comboTimer -= dt; if(p.comboTimer<=0) p.combo=0; }
  if(p.effects.shadow<=0) p.effects.shadowCrit=false;
  if(!game.pacts.noHeal && p.regen>0 && p.hp<p.maxHp) p.hp = Math.min(p.maxHp, p.hp + p.regen*(p.witherTimer>0?0.5:1)*dt);
  p.timeSinceHit += dt;
  if(!game.pacts.noHeal && p.timeSinceHit>=5 && p.hp<p.maxHp) p.hp = Math.min(p.maxHp, p.hp + (p.witherTimer>0?0.5:1)*dt);
  Object.keys(p.ultCooldowns).forEach(id=>{ p.ultCooldowns[id] = Math.max(0, p.ultCooldowns[id]-dt); });

  // --- movement ---
  let mx=0,my=0;
  if(keys['KeyW']) my-=1;
  if(keys['KeyS']) my+=1;
  if(keys['KeyA']) mx-=1;
  if(keys['KeyD']) mx+=1;
  let mlen = Math.hypot(mx,my);
  if(mlen>0){ mx/=mlen; my/=mlen; }
  const speed = Math.min(MAX_PLAYER_SPEED, p.def.speed*p.speedMult*(p.effects.shadow>0?1.15:1)*(p.potionEffects.spd>0?1.30:1)*(p.slowTimer>0?p.slowFactor:1));
  if(p.invertTimer>0){ mx=-mx; my=-my; } // mirrorGaze: your own reflection turns your movement against you
  p.x += mx*speed*dt;
  p.y += my*speed*dt;
  p.x = clamp(p.x, b.x+p.radius, b.x+b.w-p.radius);
  p.y = clamp(p.y, b.y+p.radius, b.y+b.h-p.radius);

  // facing toward mouse (convert screen-space mouse to world-space using camera offset)
  const worldMouseX = mouse.x + game.camera.x;
  const worldMouseY = mouse.y + game.camera.y;
  const dx = worldMouseX-p.x, dy = worldMouseY-p.y;
  const flen = Math.hypot(dx,dy)||1;
  p.facingX = dx/flen; p.facingY = dy/flen;
  p.facing = Math.atan2(dy,dx);

  // --- basic attack ---
  if(mouse.down && p.atkTimer<=0){
    doBasicAttack();
    p.atkTimer = Math.max(MIN_ATK_CD, currentAtk(p).cd * p.cdMult * (p.chillTimer>0 ? p.chillFactor : 1));
  }

  // --- abilities ---
  if(keyPressed('KeyQ') && p.qTimer<=0 && !(p.qLockTimer>0)){ doAbilityQ(); }
  if(keyPressed('KeyE') && p.eTimer<=0 && !(p.eLockTimer>0)){ doAbilityE(); }
  if(keyPressed('KeyR')) doUltimate();
  if(keyPressed('Digit1')) usePotion('hp');
  if(keyPressed('Digit2')) usePotion('def');
  if(keyPressed('Digit3')) usePotion('dmg');
  if(keyPressed('Digit4')) usePotion('spd');

  // --- interact ---
  if(keyPressed('Space')) doInteract();

  // --- enemies ---
  updateEnemies(dt);
  // --- boss ---
  if(game.boss) updateBoss(dt);
  // --- projectiles ---
  updateProjectiles(dt);
  // --- hazards ---
  updateHazards(dt);
  // --- gold orbs ---
  updateGoldOrbs(dt);
  updateRelicPickups(dt);
  updateUtilityChests(dt);
  // --- particles ---
  updateParticles(dt);
  // --- slash / swing visuals ---
  updateSwings(dt);
  updateShockwaves(dt);
  updateAfterimages(dt);
  // --- pet (summoner) ---
  if(game.pet) updatePet(dt);
  // --- chests bob/interact ---
  if(game.phase==='shopping') updateChests(dt);
  // --- altar prompt ---
  updateAltarPrompt();

  // shake decay
  game.shake = Math.max(0, game.shake - dt*18);

  // camera follows the player through the (now larger) world
  updateCamera();

  // hud
  syncHud();

  // death check
  if(p.hp<=0){
    if(p.relics.relic_phoenix && !p.phoenixUsed){
      p.phoenixUsed = true;
      p.hp = p.maxHp*0.5;
      p.invuln = 1.5;
      spawnToast('🔥 La Pluma de Fénix te trae de vuelta');
      addParticles(p.x,p.y,'#ff8a3d',34,220,0.6);
      shake(10);
    } else {
      onPlayerDeath();
    }
  }
}

function currentAtk(p){
  if(p.def.id==='dual') return p.stance==='ranged' ? p.def.atkRanged : p.def.atkMelee;
  return p.def.atk;
}

function doBasicAttack(){
  const p = game.player;
  const atk = currentAtk(p);
  if(atk.kind==='melee'){
    // hit all enemies (and boss) within range+arc
    const targets = [...game.enemies, ...bossTargets()];
    let hitAny=false;
    targets.forEach(t=>{
      const d = dist(p.x,p.y,t.x,t.y);
      if(d<=atk.range+t.radius){
        const ang = Math.atan2(t.y-p.y,t.x-p.x);
        let diff = Math.abs(ang-p.facing);
        if(diff>Math.PI) diff=Math.PI*2-diff;
        if(diff <= (atk.arc*Math.PI/180)){
          dealDamageToTarget(t, computeDamage(atk.dmg), 'melee');
          hitAny=true;
        }
      }
    });
    game.swings.push({ x:p.x, y:p.y, angle:p.facing, arc:(atk.arc*Math.PI/180), range:atk.range*0.85,
      life:0.16, maxLife:0.16, color:p.def.accent });
    addParticles(p.x+p.facingX*40, p.y+p.facingY*40, p.def.accent, 8, 150, 0.25);
  } else {
    spawnProjectile({ x:p.x, y:p.y, vx:p.facingX*atk.projSpeed, vy:p.facingY*atk.projSpeed,
      dmg:computeDamage(atk.dmg), radius:atk.radius, owner:'player', color:p.def.accent, life:1.4 });
    addParticles(p.x+p.facingX*22, p.y+p.facingY*22, p.def.accent, 4, 110, 0.15);
  }
}

function updateCamera(){
  const w = arenaBounds();
  const viewW = canvas.width, viewH = canvas.height;
  let cx, cy;
  if(w.w <= viewW){ cx = w.x - (viewW-w.w)/2; }
  else { cx = clamp(game.player.x - viewW/2, w.x, w.x+w.w-viewW); }
  if(w.h <= viewH){ cy = w.y - (viewH-w.h)/2; }
  else { cy = clamp(game.player.y - viewH/2, w.y, w.y+w.h-viewH); }
  game.camera.x = cx; game.camera.y = cy;
}

function comboFactor(p){ return 1 + Math.min(p.combo,50)*0.004; }

function computeDamage(base){
  const p = game.player;
  if(devMode) return { value: 999999, crit:true }; // dev mode: one-shots everything
  let dmg = base*p.dmgMult*comboFactor(p);
  if(p.weakenTimer>0) dmg *= p.weakenFactor;
  if(p.effects.warcry>0) dmg*=1.35;
  if(p.potionEffects.dmg>0) dmg*=1.25;
  if(p.def.id==='vidrio' && p.hp < p.maxHp*0.5) dmg*=1.4;
  let crit=false;
  if(Math.random()<p.critChance || p.effects.shadowCrit){ dmg*=1.8; crit=true; p.effects.shadowCrit=false; }
  return { value:dmg, crit };
}

function bossTargets(){
  const arr=[];
  if(game.boss){
    arr.push(game.boss);
    if(game.boss.twin && game.boss.twin.alive) arr.push(game.boss.twin);
  }
  return arr;
}

function dealDamageToTarget(t, dmgObj, source){
  let val = dmgObj.value;
  t.hitFlash = 0.12;
  if(t.shieldTimer>0) val *= 0.55; // sisterCall: the twins guard each other for a few seconds
  if(t.armorHp>0){
    const absorbed = Math.min(t.armorHp, val);
    t.armorHp -= absorbed;
    val -= absorbed;
    addParticles(t.x,t.y,'#c9c9d4',6,110,0.2);
    if(t.armorHp<=0 && val<=0) return; // the armor held the whole hit
  }
  if(val<=0) return;
  t.hp -= val;
  // Filo Ejecutor: a critical hit finishes off anything already below 12% HP outright — kept off
  // the boss and its twin so it can't trivialize a guardian fight, only trash enemies
  if(dmgObj.crit && game.player.relics.effect_execute && t!==game.boss && !(game.boss && game.boss.twin===t) && t.maxHp && t.hp>0 && t.hp/t.maxHp<0.12){
    t.hp = 0;
    addParticles(t.x,t.y,'#ff3d3d',10,160,0.3);
  }
  addDamageText(t.x, t.y-t.radius-6, val, dmgObj.crit?'#ffcb47':'#fff', dmgObj.crit);
  addParticles(t.x, t.y, dmgObj.crit?'#ffcb47':'#ffffff', dmgObj.crit?9:4, dmgObj.crit?170:100, dmgObj.crit?0.28:0.18);
  if(!game.pacts.noHeal && game.player.lifesteal>0){ game.player.hp = Math.min(game.player.maxHp, game.player.hp + val*Math.min(0.10,game.player.lifesteal)*(game.player.witherTimer>0?0.5:1)); }
  if(source!=='chain'){ game.player.combo++; game.player.comboTimer = 4; }
  if(source!=='chain' && game.player.relics.relic_storm && Math.random()<0.15){
    const others = [...game.enemies, ...bossTargets()].filter(o=>o!==t && dist(o.x,o.y,t.x,t.y)<150);
    if(others.length){
      const target2 = others[Math.floor(Math.random()*others.length)];
      addParticles(t.x,t.y,'#8ec9ff',6,140,0.2);
      dealDamageToTarget(target2, {value: val*0.5, crit:false}, 'chain');
    }
  }
  if(t.hp<=0){
    if(t===game.boss){
      if(game.boss.kind==='twinBoss' && game.boss.twin && game.boss.twin.alive){ onTwinComponentDeath(true); }
      else { onBossDeath(); }
    } else if(game.boss && game.boss.twin && t===game.boss.twin){
      onTwinComponentDeath(false);
    } else {
      killEnemy(t);
    }
  }
}

function onTwinComponentDeath(deadIsPrimary){
  const boss = game.boss;
  if(deadIsPrimary){
    addParticles(boss.x, boss.y, boss.def.color, 22, 190, 0.45);
    spawnToast('Una gemela cae. La otra toma su lugar.');
    shake(6);
    game.boss = {
      kind: boss.kind, def: boss.def, x: boss.twin.x, y: boss.twin.y,
      hp: boss.twin.hp, maxHp: boss.twin.maxHp, dmg: boss.dmg, radius: boss.twin.radius,
      attackTimer: 0.6, phase: boss.phase, telegraph:null, contactTimer:0, hitFlash:0, spawnGrace:0,
      hover:false, petalTimer:0, twin:null,
    };
    $('boss-hp-wrap').classList.add('show');
  } else {
    boss.twin.alive = false;
    spawnToast('Una gemela cae. La otra sigue en pie.');
    addParticles(boss.twin.x, boss.twin.y, boss.def.color, 22, 190, 0.45);
    shake(6);
  }
}

function killEnemy(t){
  const idx = game.enemies.indexOf(t);
  if(idx>=0) game.enemies.splice(idx,1);
  game.kills++;
  addParticles(t.x,t.y,(t.def&&t.def.color)||'#ffffff',t.isElite?18:10,t.isElite?220:180,0.4);
  // Núcleo Volátil: a chance for a defeated enemy to detonate, damaging whatever's nearby
  if(game.player.relics.effect_deathburst && Math.random()<0.25){
    explodeAt(t.x,t.y,90,computeDamage(10));
  }
  if(t.def && t.def.explodesOnDeath){
    addParticles(t.x,t.y,'#ff8a3d',22,220,0.45);
    shake(4);
    const p = game.player;
    if(dist(t.x,t.y,p.x,p.y) < t.def.explodeRadius+p.radius) hitPlayer(t.def.explodeDmg);
  }
  if(!t.isBossMinion){
    const g = Math.round(rand(t.goldMin!==undefined?t.goldMin:(t.def?t.def.gold[0]:1), t.goldMax!==undefined?t.goldMax:(t.def?t.def.gold[1]:2)));
    const GOLD_ORB_CAP = 40; // once the floor's this cluttered, fold new drops into the nearest orb instead of adding more
    if(game.goldOrbs.length >= GOLD_ORB_CAP){
      let nearest=null, nd=Infinity;
      game.goldOrbs.forEach(o=>{ const d=dist(o.x,o.y,t.x,t.y); if(d<nd){ nd=d; nearest=o; } });
      if(nearest) nearest.value += g;
    } else {
      game.goldOrbs.push({ x:t.x, y:t.y, value:g, vx:rand(-40,40), vy:rand(-40,40) });
    }
  }
  maybeDropRelic(t);
  maybeDropUtilityChest(t);
}

function onBossDeath(){
  const boss = game.boss;
  addParticles(boss.x, boss.y, boss.def.color, 40, 260, 0.7);
  shake(14);
  const g = 20 + game.stageIndex*10;
  game.goldOrbs.push({ x:boss.x, y:boss.y, value:g, vx:0, vy:0 });
  spawnBossDrops(boss);
  game.portal = { x:boss.x, y:boss.y, radius:34, pulse:0 };
  game.boss=null;
  $('boss-hp-wrap').classList.remove('show');
  spawnToast(`¡${boss.def.name} derrotado! Un portal se abre.`);
  game.stats.bossesThisRun++;
  if(!game.stats.bossTookDamage) game.stats.noHitBoss = true;
  checkAchievements();
  game.phase='portal';
  updatePhaseNote();
}

function spawnBossDrops(boss){
  const p = game.player;
  const item = BOSS_ITEMS[boss.kind];
  if(item && Math.random()<0.10){
    const already = p.items.some(it=>it.id===item.id);
    if(already){
      const bonus = 18 + game.stageIndex*5;
      game.gold += bonus;
      spawnToast(`Ya tenías ${item.name}. +${bonus} oro en su lugar.`);
    } else {
      item.apply(p);
      p.items.push(item);
      checkSynergies(p);
      spawnToast(`👑 Objeto de jefe: ${item.name} — ${item.desc}`);
      addParticles(boss.x,boss.y,'#ffd54a',26,220,0.6);
    }
  }
  const lockedAbilities = ULTIMATE_ABILITIES.filter(a=>!progress.unlockedAbilities.includes(a.id));
  if(lockedAbilities.length && Math.random()<0.05){
    const ab = lockedAbilities[Math.floor(Math.random()*lockedAbilities.length)];
    progress.unlockedAbilities.push(ab.id);
    p.ultCooldowns[ab.id] = 0;
    spawnToast(`🔓 ¡HABILIDAD DESBLOQUEADA! ${ab.name} — tecla R`);
    addParticles(boss.x,boss.y,ab.color,36,260,0.7);
    shake(10);
  }
}

/* ---------- abilities ---------- */
function doAbilityQ(){
  const p = game.player;
  const id = p.def.id;
  p.qTimer = Math.max(MIN_ABILITY_CD, p.def.q.cd*p.cdMult);
  if(id==='guerrero'){
    // dash forward dealing damage along the whole path, with invulnerability plus a defensive window on landing
    const dashDist = 230;
    const steps=8;
    p.invuln = Math.max(p.invuln, 0.55);
    p.effects.wall = Math.max(p.effects.wall, 1.2);
    const alreadyHit = new Set();
    const b = arenaBounds();
    for(let i=1;i<=steps;i++){
      const nx = p.x + p.facingX*(dashDist/steps);
      const ny = p.y + p.facingY*(dashDist/steps);
      p.x = clamp(nx, b.x+p.radius, b.x+b.w-p.radius);
      p.y = clamp(ny, b.y+p.radius, b.y+b.h-p.radius);
      spawnAfterimage(p.x, p.y, p.radius, p.def.accent, p.def.icon);
      [...game.enemies, ...bossTargets()].forEach(t=>{
        if(!alreadyHit.has(t) && dist(p.x,p.y,t.x,t.y) < 70+t.radius){
          alreadyHit.add(t);
          dealDamageToTarget(t, computeDamage(p.def.atk.dmg*1.8), 'q');
          addParticles(t.x,t.y,p.def.accent,6,120,0.25);
        }
      });
    }
    addParticles(p.x,p.y,p.def.accent,14,200,0.35);
    shake(4);
  } else if(id==='maga'){
    spawnProjectile({ x:p.x,y:p.y, vx:p.facingX*260, vy:p.facingY*260, dmg:computeDamage(p.def.atk.dmg*1.5),
      radius:18, owner:'player', color:'#ff6a3d', life:2.4, explode:true, explodeRadius:95, shape:'ember' });
  } else if(id==='picaro'){
    for(let i=-1.5;i<=1.5;i++){
      const ang = p.facing + i*0.18;
      spawnProjectile({ x:p.x,y:p.y, vx:Math.cos(ang)*560, vy:Math.sin(ang)*560, dmg:computeDamage(p.def.atk.dmg*0.75),
        radius:5, owner:'player', color:'#d24aff', life:1, shape:'shard' });
    }
  } else if(id==='paladin'){
    p.shield = Math.max(p.shield, p.maxHp*0.35);
    addParticles(p.x,p.y,'#ffcb47',20,160,0.5);
  } else if(id==='nigromante'){
    [...game.enemies, ...bossTargets()].forEach(t=>{
      if(dist(p.x,p.y,t.x,t.y) < 130) dealDamageToTarget(t, computeDamage(p.def.atk.dmg*1.6), 'q');
    });
    addParticles(p.x,p.y,'#8bff6b',24,200,0.45);
    spawnShockwave(p.x,p.y,'#8bff6b',130,0.35);
    shake(4);
  } else if(id==='vidrio'){
    const targets = [...game.enemies, ...bossTargets()];
    targets.forEach(t=>{
      const d = dist(p.x,p.y,t.x,t.y);
      if(d<=110+t.radius){
        const ang = Math.atan2(t.y-p.y,t.x-p.x);
        let diff = Math.abs(ang-p.facing); if(diff>Math.PI) diff=Math.PI*2-diff;
        if(diff <= (80*Math.PI/180)){
          const dmgObj = computeDamage(p.def.atk.dmg*1.8);
          dmgObj.crit = true; dmgObj.value *= 1.3;
          dealDamageToTarget(t, dmgObj, 'q');
        }
      }
    });
    game.swings.push({ x:p.x, y:p.y, angle:p.facing, arc:(80*Math.PI/180), range:110, life:0.2, maxLife:0.2, color:'#e8e8f5' });
    addParticles(p.x,p.y,'#e8e8f5',16,220,0.3);
    shake(5);
  } else if(id==='coloso'){
    game.enemies.forEach(t=>{
      const d = dist(p.x,p.y,t.x,t.y);
      if(d<220 && d>1){
        const ang = Math.atan2(p.y-t.y,p.x-t.x);
        t.x += Math.cos(ang)*90; t.y += Math.sin(ang)*90;
        t.stunTimer = Math.max(t.stunTimer||0, 1.1);
      }
    });
    addParticles(p.x,p.y,'#9c8a6a',26,200,0.5);
    spawnShockwave(p.x,p.y,'#9c8a6a',220,0.4);
    shake(9);
  } else if(id==='silvano'){
    game.pet = { x:p.x-30, y:p.y, hp:1, maxHp:1, radius:14, speed:270, dmg:Math.round(p.def.atk.dmg*1.4),
      atkTimer:0, atkCd:0.6, color:'#5bbf7a', hitFlash:0, life:14 };
    addParticles(p.x,p.y,'#5bbf7a',18,160,0.4);
  } else if(id==='dual'){
    p.stance = p.stance==='melee' ? 'ranged' : 'melee';
    addParticles(p.x,p.y,'#5ac8d8',14,150,0.3);
  }
  addParticles(p.x,p.y,'#fff',6,90,0.2);
}

function doAbilityE(){
  const p = game.player;
  const id = p.def.id;
  p.eTimer = Math.max(MIN_ABILITY_CD, p.def.e.cd*p.cdMult);
  if(id==='guerrero'){
    p.effects.warcry = 5;
    [...game.enemies, ...bossTargets()].forEach(t=>{
      const d = dist(p.x,p.y,t.x,t.y);
      if(d<160){
        const ang = Math.atan2(t.y-p.y,t.x-p.x);
        t.x += Math.cos(ang)*40; t.y += Math.sin(ang)*40;
      }
    });
    addParticles(p.x,p.y,'#ff6a3d',22,220,0.5);
    shake(8);
  } else if(id==='maga'){
    const b = arenaBounds();
    const nx = clamp(p.x+p.facingX*220, b.x+p.radius, b.x+b.w-p.radius);
    const ny = clamp(p.y+p.facingY*220, b.y+p.radius, b.y+b.h-p.radius);
    addParticles(p.x,p.y,'#6a8dff',16,160,0.4);
    p.x=nx; p.y=ny;
    p.invuln = 0.3;
    addParticles(p.x,p.y,'#6a8dff',16,160,0.4);
  } else if(id==='picaro'){
    p.effects.shadow = 1.3;
    p.effects.shadowCrit = true;
    p.invuln = 0.2;
    addParticles(p.x,p.y,'#d24aff',18,180,0.45);
  } else if(id==='paladin'){
    let healed = 0;
    [...game.enemies, ...bossTargets()].forEach(t=>{
      if(dist(p.x,p.y,t.x,t.y) < 140){ dealDamageToTarget(t, computeDamage(p.def.atk.dmg*1.2), 'e'); healed+=8; }
    });
    p.hp = Math.min(p.maxHp, p.hp + Math.max(14,healed));
    addParticles(p.x,p.y,'#ffcb47',26,220,0.5);
    shake(6);
  } else if(id==='nigromante'){
    let drained = 0;
    [...game.enemies, ...bossTargets()].forEach(t=>{
      if(dist(p.x,p.y,t.x,t.y) < 150){ const dmgObj=computeDamage(p.def.atk.dmg*0.9); dealDamageToTarget(t, dmgObj, 'e'); drained+=dmgObj.value*0.6; }
    });
    p.hp = Math.min(p.maxHp, p.hp + drained);
    addParticles(p.x,p.y,'#8bff6b',22,190,0.5);
  } else if(id==='vidrio'){
    p.shield = Math.max(p.shield, 46);
    addParticles(p.x,p.y,'#e8e8f5',20,170,0.4);
  } else if(id==='coloso'){
    p.shield = Math.max(p.shield, 90);
    p.effects.wall = 4;
    addParticles(p.x,p.y,'#9c8a6a',24,180,0.45);
    shake(4);
  } else if(id==='silvano'){
    if(game.pet){
      explodeAt(game.pet.x, game.pet.y, 130, computeDamage(p.def.atk.dmg*3));
      addParticles(game.pet.x,game.pet.y,'#5bbf7a',30,220,0.5);
      game.pet = null;
      shake(6);
    } else {
      p.hp = Math.min(p.maxHp, p.hp + p.maxHp*0.15);
      addParticles(p.x,p.y,'#5bbf7a',16,150,0.35);
    }
  } else if(id==='dual'){
    const dashDist=130, steps=6;
    const b = arenaBounds();
    for(let i=0;i<steps;i++){
      p.x = clamp(p.x+p.facingX*(dashDist/steps), b.x+p.radius, b.x+b.w-p.radius);
      p.y = clamp(p.y+p.facingY*(dashDist/steps), b.y+p.radius, b.y+b.h-p.radius);
    }
    [...game.enemies, ...bossTargets()].forEach(t=>{
      if(dist(p.x,p.y,t.x,t.y) < 80+t.radius) dealDamageToTarget(t, computeDamage(currentAtk(p).dmg*1.5), 'e');
    });
    p.invuln = Math.max(p.invuln, 0.2);
    addParticles(p.x,p.y,'#5ac8d8',16,190,0.35);
    shake(3);
  }
}

function doUltimate(){
  const p = game.player;
  const ids = progress.unlockedAbilities;
  if(!ids.length) return;
  let best=null;
  ids.forEach(id=>{ const cd=p.ultCooldowns[id]||0; if(!best || cd<best.cd) best={id,cd}; });
  if(!best || best.cd>0) return;
  const ability = ULTIMATE_ABILITIES.find(a=>a.id===best.id);
  ability.cast(p);
  // the R ultimate's cooldown ignores cdMult entirely — cooldown-reduction items/synergies
  // don't touch it, it always sits at its own base cd (floored at MIN_ULT_CD = 30s)
  p.ultCooldowns[ability.id] = Math.max(MIN_ULT_CD, ability.cd);
}

function doInteract(){
  const p = game.player;
  // chests
  if(game.phase==='shopping'){
    game.chests.forEach(c=>{
      if(!c.opened && dist(p.x,p.y,c.x,c.y)<60){
        if(game.gold>=c.cost){
          game.gold-=c.cost;
          c.opened=true;
          const tier = CHEST_TIERS[c.tier];
          const cursed = Math.random()<CURSED_CHEST_CHANCE;
          const item = cursed
            ? CURSED_ITEMS[Math.floor(Math.random()*CURSED_ITEMS.length)]
            : ITEM_POOL[c.tier][Math.floor(Math.random()*ITEM_POOL[c.tier].length)];
          item.apply(p);
          p.items.push(item);
          checkSynergies(p);
          if(cursed){
            spawnToast(`☠ [MALDITO] ${item.name} — ${item.desc}`);
            addParticles(c.x,c.y,'#e8434f',30,220,0.6);
            shake(8);
          } else {
            spawnToast(`${item.icon} [${tier.label}] ${item.name} — ${item.desc}`);
            addParticles(c.x,c.y,tier.color,c.tier==='epic'?32:(c.tier==='rare'?24:16),c.tier==='epic'?240:180,0.55);
            shake(c.tier==='epic'?7:(c.tier==='rare'?4:0));
          }
        } else {
          spawnToast(`Necesitas ${c.cost} de oro para este cofre.`);
        }
      }
    });
    if(game.altar && game.altar.active && dist(p.x,p.y,game.altar.x,game.altar.y)<70){
      startBossCountdown();
    }
    if(game.sacrificeAltar && !game.sacrificeAltar.used && dist(p.x,p.y,game.sacrificeAltar.x,game.sacrificeAltar.y)<60){
      game.sacrificeAltar.used = true;
      const cut = p.maxHp*0.15;
      p.maxHp -= cut; p.hp = Math.max(1, p.hp-cut);
      const bonus = 15 + game.stageIndex*6;
      game.gold += bonus;
      spawnToast(`Sacrificaste ${Math.round(cut)} HP máx por ${bonus} oro.`);
      addParticles(game.sacrificeAltar.x, game.sacrificeAltar.y, '#e8434f', 26, 200, 0.5);
      shake(5);
    }
    if(game.merchant && dist(p.x,p.y,game.merchant.x,game.merchant.y)<70 && !merchantOpen){
      openMerchant();
    }
  } else if(game.phase==='portal'){
    if(game.portal && dist(p.x,p.y,game.portal.x,game.portal.y)<70){
      onStageClear();
    }
  }
}

/* ---------- enemies ---------- */
function updatePet(dt){
  const pet = game.pet;
  const p = game.player;
  pet.life -= dt;
  pet.hitFlash = Math.max(0, pet.hitFlash-dt);
  pet.atkTimer = Math.max(0, pet.atkTimer-dt);
  if(pet.life<=0){ game.pet = null; return; }
  const targets = [...game.enemies, ...bossTargets()];
  let nearest=null, nearestD=Infinity;
  targets.forEach(t=>{ const d=dist(pet.x,pet.y,t.x,t.y); if(d<nearestD){ nearestD=d; nearest=t; } });
  if(nearest && nearestD<420){
    if(nearestD>34){
      const ang = Math.atan2(nearest.y-pet.y,nearest.x-pet.x);
      pet.x += Math.cos(ang)*pet.speed*dt;
      pet.y += Math.sin(ang)*pet.speed*dt;
    } else if(pet.atkTimer<=0){
      pet.atkTimer = pet.atkCd;
      pet.hitFlash = 0.12;
      dealDamageToTarget(nearest, computeDamage(pet.dmg), 'pet');
      addParticles(nearest.x,nearest.y,'#5bbf7a',5,110,0.18);
    }
  } else {
    const d = dist(pet.x,pet.y,p.x,p.y);
    if(d>70){
      const ang = Math.atan2(p.y-pet.y,p.x-pet.x);
      pet.x += Math.cos(ang)*pet.speed*0.8*dt;
      pet.y += Math.sin(ang)*pet.speed*0.8*dt;
    }
  }
  const b = arenaBounds();
  pet.x = clamp(pet.x, b.x+pet.radius, b.x+b.w-pet.radius);
  pet.y = clamp(pet.y, b.y+pet.radius, b.y+b.h-pet.radius);
}

function drawPet(pet){
  ctx.save();
  ctx.globalAlpha = clamp(pet.life/2, 0.5, 1);
  ctx.translate(pet.x,pet.y);
  ctx.fillStyle = pet.hitFlash>0 ? '#ffffff' : pet.color;
  ctx.shadowColor=pet.color; ctx.shadowBlur=10;
  ctx.beginPath(); ctx.arc(0,0,pet.radius,0,Math.PI*2); ctx.fill();
  ctx.shadowBlur=0;
  ctx.strokeStyle='#0a0710'; ctx.lineWidth=2; ctx.stroke();
  ctx.restore();
}


function updateEnemies(dt){
  const p = game.player;
  game.enemies.forEach(en=>{
    en.hitFlash = Math.max(0,en.hitFlash-dt);
    en.atkTimer = Math.max(0,en.atkTimer-dt);
    if(en.stunTimer>0){ en.stunTimer -= dt; return; }
    if(en.poisonTimer>0){ en.poisonTimer-=dt; if(Math.floor(en.poisonTimer*10)%3===0){} }
    const d = dist(en.x,en.y,p.x,p.y);
    const def = en.def;
    const spd = def.speed*(en.speedMult||1);

    // ---- healer aura: works alongside whatever else this enemy is doing ----
    if(def.healer){
      en.healTimer = (en.healTimer===undefined ? Math.random()*def.healCd : en.healTimer) - dt;
      if(en.healTimer<=0){
        en.healTimer = def.healCd;
        let healedAny=false;
        game.enemies.forEach(other=>{
          if(other!==en && other.hp<other.maxHp && dist(en.x,en.y,other.x,other.y)<def.healRadius){
            other.hp = Math.min(other.maxHp, other.hp+def.healAmount);
            healedAny=true;
          }
        });
        if(healedAny) addParticles(en.x,en.y,'#5ad98a',10,90,0.4);
      }
    }

    if(def.charger){
      // ---- charge-dash melee: idle -> windup (telegraph) -> dash -> cooldown ----
      en.chargeState = en.chargeState || 'idle';
      if(en.chargeState==='dashing'){
        en.chargeTimer -= dt;
        en.x += en.chargeDirX*def.chargeSpeed*dt;
        en.y += en.chargeDirY*def.chargeSpeed*dt;
        if(en.atkTimer<=0 && d<en.radius+p.radius+6){
          en.atkTimer = 0.5;
          hitPlayer(en.dmg);
          addParticles(p.x,p.y,'#e8434f',8,140,0.3);
        }
        if(en.chargeTimer<=0){ en.chargeState='cooldown'; en.chargeTimer=def.chargeCd; }
      } else if(en.chargeState==='windup'){
        en.chargeTimer -= dt;
        if(en.chargeTimer<=0){
          en.chargeState='dashing'; en.chargeTimer=def.chargeDur;
          const ang = Math.atan2(p.y-en.y,p.x-en.x);
          en.chargeDirX = Math.cos(ang); en.chargeDirY = Math.sin(ang);
        }
      } else if(en.chargeState==='cooldown'){
        en.chargeTimer -= dt;
        if(d>def.range*0.7){
          const ang = Math.atan2(p.y-en.y,p.x-en.x);
          en.x += Math.cos(ang)*spd*dt; en.y += Math.sin(ang)*spd*dt;
        } else if(en.atkTimer<=0){
          en.atkTimer = def.atkCd;
          hitPlayer(en.dmg*0.6);
          addParticles(p.x,p.y,'#e8434f',6,120,0.25);
        }
        if(en.chargeTimer<=0) en.chargeState='idle';
      } else { // idle
        if(d>def.range*0.7){
          const ang = Math.atan2(p.y-en.y,p.x-en.x);
          en.x += Math.cos(ang)*spd*dt; en.y += Math.sin(ang)*spd*dt;
        } else {
          en.chargeState='windup'; en.chargeTimer=def.chargeWindup;
        }
      }
    } else if(def.kind==='melee'){
      if(d>def.range*0.7){
        const ang = Math.atan2(p.y-en.y,p.x-en.x);
        en.x += Math.cos(ang)*spd*dt;
        en.y += Math.sin(ang)*spd*dt;
      } else if(en.atkTimer<=0){
        en.atkTimer = def.atkCd;
        hitPlayer(en.dmg);
        addParticles(p.x,p.y,'#e8434f',8,140,0.3);
      }
    } else {
      // ---- ranged kinds (including chargeShot snipers, which pause & telegraph before firing) ----
      const aiming = def.chargeShot && en.aiming;
      if(!aiming){
        if(def.erratic){
          en.wanderAng += (Math.random()-0.5)*3.2*dt;
          const wx = Math.cos(en.wanderAng), wy = Math.sin(en.wanderAng);
          if(d>def.range*0.6){
            const ang = Math.atan2(p.y-en.y,p.x-en.x);
            en.x += (Math.cos(ang)*0.7 + wx*0.5)*spd*dt;
            en.y += (Math.sin(ang)*0.7 + wy*0.5)*spd*dt;
          } else {
            en.x += wx*spd*0.7*dt;
            en.y += wy*spd*0.7*dt;
          }
        } else if(d>def.range*0.75){
          const ang = Math.atan2(p.y-en.y,p.x-en.x);
          en.x += Math.cos(ang)*spd*dt;
          en.y += Math.sin(ang)*spd*dt;
        } else if(d<def.range*0.4){
          const ang = Math.atan2(en.y-p.y,en.x-p.x);
          en.x += Math.cos(ang)*spd*dt;
          en.y += Math.sin(ang)*spd*dt;
        }
      }
      if(def.chargeShot){
        if(en.aiming){
          en.aimTimer -= dt;
          if(en.aimTimer<=0){
            en.aiming=false;
            en.atkTimer = def.atkCd;
            const ang = Math.atan2(p.y-en.y,p.x-en.x);
            spawnProjectile({ x:en.x,y:en.y, vx:Math.cos(ang)*def.projSpeed, vy:Math.sin(ang)*def.projSpeed,
              dmg:en.dmg, radius:6, owner:'enemy', color:'#ffb3ec', life:2 });
          }
        } else if(en.atkTimer<=0 && d<def.range){
          en.aiming = true;
          en.aimTimer = def.chargeShotWindup;
        }
      } else if(en.atkTimer<=0 && d<def.range){
        en.atkTimer = def.atkCd;
        const ang = Math.atan2(p.y-en.y,p.x-en.x);
        spawnProjectile({ x:en.x,y:en.y, vx:Math.cos(ang)*def.projSpeed, vy:Math.sin(ang)*def.projSpeed,
          dmg:en.dmg, radius:6, owner:'enemy', color:def.poison?'#8bff6b':(def.slowOnHit?'#9fd8ff':'#e8434f'), life:2, poison:def.poison,
          slow: def.slowOnHit ? { factor:def.slowFactor, dur:def.slowDur } : null });
      }
    }
    const b = arenaBounds();
    en.x = clamp(en.x, b.x+en.radius, b.x+b.w-en.radius);
    en.y = clamp(en.y, b.y+en.radius, b.y+b.h-en.radius);
  });

  // separation pass: gently push overlapping enemies apart so a crowd doesn't collapse into a
  // single stacked pile — cheap O(n²) pass, fine for the enemy counts this game spawns
  const n = game.enemies.length;
  const eb = arenaBounds();
  for(let i=0;i<n;i++){
    const a = game.enemies[i];
    for(let j=i+1;j<n;j++){
      const c = game.enemies[j];
      const dx = c.x-a.x, dy = c.y-a.y;
      const dst = Math.hypot(dx,dy) || 0.01;
      const minDist = (a.radius+c.radius)*0.92;
      if(dst < minDist){
        const push = (minDist-dst)/dst*0.5;
        const ox = dx*push, oy = dy*push;
        a.x = clamp(a.x-ox, eb.x+a.radius, eb.x+eb.w-a.radius);
        a.y = clamp(a.y-oy, eb.y+a.radius, eb.y+eb.h-a.radius);
        c.x = clamp(c.x+ox, eb.x+c.radius, eb.x+eb.w-c.radius);
        c.y = clamp(c.y+oy, eb.y+c.radius, eb.y+eb.h-c.radius);
      }
    }
  }
}

function hitPlayer(dmg){
  const p = game.player;
  if(devMode) return; // dev mode: infinite HP, take no damage at all
  if(p.invuln>0) return;
  if(game && game.phase==='boss') game.stats.bossTookDamage = true;
  p.timeSinceHit = 0;
  if(p.shield>0){
    p.shield -= dmg;
    addParticles(p.x,p.y,'#ffcb47',10,150,0.3);
    if(p.shield<0) p.hp += p.shield; // overflow spills onto HP
    p.shield = Math.max(0,p.shield);
    p.invuln = 0.15;
    shake(3);
    return;
  }
  const wallBonus = (p.effects.wall>0 ? 0.25 : 0) + (p.potionEffects.def>0 ? 0.30 : 0);
  const reduced = dmg*(1-Math.min(0.85,p.armor+wallBonus))*p.curseDmgTakenMult;
  p.hp -= reduced;
  p.combo = 0;
  p.invuln = 0.35;
  shake(4);
  // Talismán de Represalia: a chance to hit back everything nearby the instant you get hit
  if(p.relics.effect_thorns && Math.random()<0.20){
    explodeAt(p.x,p.y,110, computeDamage(14));
  }
}

/* ---------- boss AI ---------- */
function updateBoss(dt){
  const p = game.player;
  const boss = game.boss;
  const b = arenaBounds();
  boss.hitFlash = Math.max(0,boss.hitFlash-dt);
  boss.shieldTimer = Math.max(0,(boss.shieldTimer||0)-dt);
  if(boss.regenTimer>0){
    boss.regenTimer -= dt;
    boss.hp = Math.min(boss.maxHp, boss.hp + (boss.regenPerSec||0)*dt);
  }

  // materializing: boss just appeared, does nothing yet (visual pop-in only)
  if(boss.spawnGrace>0){
    boss.spawnGrace -= dt;
    return;
  }

  if(boss.twin && boss.twin.alive){
    boss.twin.hitFlash = Math.max(0, boss.twin.hitFlash-dt);
    boss.twin.shieldTimer = Math.max(0,(boss.twin.shieldTimer||0)-dt);
    // flies independently in a slow orbit around the player instead of being locked to the main
    // boss's position — this used to snap back every frame, undoing anything twinSwap/attacks did
    const orbitAng = performance.now()/900;
    const tx = clamp(p.x+Math.cos(orbitAng)*170, b.x+40, b.x+b.w-40);
    const ty = clamp(p.y+Math.sin(orbitAng)*170, b.y+40, b.y+b.h-40);
    const twSpeed = 120;
    const dtx = tx-boss.twin.x, dty = ty-boss.twin.y;
    const dtLen = Math.hypot(dtx,dty)||1;
    boss.twin.x = clamp(boss.twin.x+(dtx/dtLen)*twSpeed*dt, b.x+30, b.x+b.w-30);
    boss.twin.y = clamp(boss.twin.y+(dty/dtLen)*twSpeed*dt, b.y+30, b.y+b.h-30);
  }

  boss.contactTimer = Math.max(0,boss.contactTimer-dt);
  boss.attackTimer -= dt;

  if(boss.hp < boss.maxHp*0.5 && boss.phase===1){
    boss.phase=2; boss.def={...boss.def, speed:boss.def.speed*1.15};
    if(boss.kind==='twinBoss'){
      // at half HP the Twins open their signature mega laser immediately, rather than leaving it
      // to random chance — a clear, telegraphed "things just changed" moment
      boss.forceNextAttack = 'megaLaser';
      spawnToast('¡Las Hermanas Gemelas fusionan su mirada!');
    }
  }

  // movement: approach player unless telegraphing
  if(!boss.telegraph){
    const d = dist(boss.x,boss.y,p.x,p.y);
    if(boss.hover){
      const desired = 300;
      if(d>desired+50){
        const ang = Math.atan2(p.y-boss.y,p.x-boss.x);
        boss.x += Math.cos(ang)*boss.def.speed*dt;
        boss.y += Math.sin(ang)*boss.def.speed*dt;
      } else if(d<desired-50){
        const ang = Math.atan2(boss.y-p.y,boss.x-p.x);
        boss.x += Math.cos(ang)*boss.def.speed*dt;
        boss.y += Math.sin(ang)*boss.def.speed*dt;
      } else {
        const ang = Math.atan2(p.y-boss.y,p.x-boss.x) + Math.PI/2;
        boss.x += Math.cos(ang)*boss.def.speed*0.55*dt;
        boss.y += Math.sin(ang)*boss.def.speed*0.55*dt;
      }
      boss.petalTimer -= dt;
      if(boss.petalTimer<=0){
        boss.petalTimer = 0.1;
        const ang = Math.random()*Math.PI*2;
        game.particles.push({ x:boss.x+Math.cos(ang)*boss.radius, y:boss.y+Math.sin(ang)*boss.radius,
          vx:rand(-14,14), vy:22, life:1.1, maxLife:1.1, color:'#ffd6f0', r:rand(1.5,3), type:'circle' });
      }
    } else if(d>90){
      const ang = Math.atan2(p.y-boss.y,p.x-boss.x);
      boss.x += Math.cos(ang)*boss.def.speed*dt;
      boss.y += Math.sin(ang)*boss.def.speed*dt;
    } else {
      // too close to approach further — back off a little or circle-strafe instead of standing
      // completely still, which made some kits (all close-range/self attacks, no repositioning
      // move) feel like the boss never moved at all
      if(d<50){
        const ang = Math.atan2(boss.y-p.y,boss.x-p.x);
        boss.x += Math.cos(ang)*boss.def.speed*0.6*dt;
        boss.y += Math.sin(ang)*boss.def.speed*0.6*dt;
      } else {
        const ang = Math.atan2(p.y-boss.y,p.x-boss.x) + Math.PI/2*(boss.strafeDir||1);
        boss.x += Math.cos(ang)*boss.def.speed*0.5*dt;
        boss.y += Math.sin(ang)*boss.def.speed*0.5*dt;
      }
      if(boss.contactTimer<=0){
        boss.contactTimer = boss.def.contactCd;
        hitPlayer(boss.dmg*0.6);
      }
    }
  }
  boss.x = clamp(boss.x, b.x+boss.radius, b.x+b.w-boss.radius);
  boss.y = clamp(boss.y, b.y+boss.radius, b.y+b.h-boss.radius);

  // telegraph resolution
  if(boss.telegraph){
    if(boss.telegraph.type==='boneGrab'){
      // wind pulls the player toward the boss from anywhere in the room, growing stronger as it
      // charges — except inside the small safe pocket, which is completely still
      const inSafeZone = boss.telegraph.safeX!==undefined && dist(boss.telegraph.safeX,boss.telegraph.safeY,p.x,p.y) < boss.telegraph.safeR;
      const dGrab = dist(boss.x,boss.y,p.x,p.y);
      if(!inSafeZone && dGrab>boss.radius+p.radius+10){
        const prog = 1 - clamp(boss.telegraph.t/boss.telegraph.dur,0,1); // 0 -> 1 as the pull intensifies
        const pullSpeed = 25 + prog*130;
        const ang = Math.atan2(boss.y-p.y, boss.x-p.x);
        p.x = clamp(p.x+Math.cos(ang)*pullSpeed*dt, b.x+p.radius, b.x+b.w-p.radius);
        p.y = clamp(p.y+Math.sin(ang)*pullSpeed*dt, b.y+p.radius, b.y+b.h-p.radius);
        if(Math.random()<0.4) addParticles(p.x,p.y,boss.def.color,2,60,0.25);
      }
    } else if(boss.telegraph.type==='gravityWell'){
      // unlike boneGrab, this pulls toward a FIXED point in space that stays put even if the boss moves
      const wx = boss.telegraph.tx, wy = boss.telegraph.ty;
      const dWell = dist(wx,wy,p.x,p.y);
      if(dWell>18){
        const prog = 1 - clamp(boss.telegraph.t/boss.telegraph.dur,0,1);
        const pullSpeed = 20 + prog*95;
        const ang = Math.atan2(wy-p.y, wx-p.x);
        p.x = clamp(p.x+Math.cos(ang)*pullSpeed*dt, b.x+p.radius, b.x+b.w-p.radius);
        p.y = clamp(p.y+Math.sin(ang)*pullSpeed*dt, b.y+p.radius, b.y+b.h-p.radius);
        if(Math.random()<0.4) addParticles(p.x,p.y,boss.def.color,2,50,0.25);
      }
    } else if(boss.telegraph.type==='megaLaser'){
      // the beam sweeps continuously across its arc — dodging means getting ahead of the sweep
      // and staying clear, not just sidestepping once. Two beams (main + twin) cross if she's
      // still alive, cutting the safe pockets down further
      const tgL = boss.telegraph;
      const elapsed = tgL.dur - tgL.t;
      const checkBeam = (originX, originY, startAngle)=>{
        if(elapsed <= tgL.hotAt) return; // still in the warning-preview window, not burning yet
        const sweepProg = clamp((elapsed-tgL.hotAt)/(tgL.dur-tgL.hotAt), 0, 1);
        const curAngle = startAngle + tgL.sweepDir*tgL.sweepArc*sweepProg;
        const angToPlayer = Math.atan2(p.y-originY, p.x-originX);
        const diff = Math.abs(((angToPlayer-curAngle+Math.PI)%(Math.PI*2)+Math.PI*2)%(Math.PI*2)-Math.PI);
        const dToPlayer = dist(originX,originY,p.x,p.y);
        if(diff < 0.1 && dToPlayer < tgL.beamLen){
          tgL.tick = (tgL.tick||0) - dt;
          if(tgL.tick<=0){
            hitPlayer(boss.dmg*0.42);
            tgL.tick = 0.15;
            addParticles(p.x,p.y,'#ff3d3d',8,120,0.25);
            shake(2);
          }
        }
      };
      checkBeam(boss.x, boss.y, tgL.startAngle);
      if(boss.twin && boss.twin.alive && tgL.twinStartAngle!==undefined){
        checkBeam(boss.twin.x, boss.twin.y, tgL.twinStartAngle);
      }
    }
    boss.telegraph.t -= dt;
    if(boss.telegraph.t<=0){
      game._echoProjectiles = true; // boss attacks fire roughly double the projectiles — see spawnProjectile
      game._guardianAttack = !!boss.isGuardian; // guardians' projectiles fly faster — see spawnProjectile
      const hazardsBefore = game.hazards.length;
      resolveBossAttack(boss.telegraph.type, boss.telegraph);
      if(boss.isGuardian){
        // same idea as the projectile speed boost, but for ground hazards: less warning before
        // the ground actually hurts you
        for(let hi=hazardsBefore; hi<game.hazards.length; hi++){
          if(game.hazards[hi].telegraph) game.hazards[hi].telegraph *= 0.8;
        }
      }
      game._echoProjectiles = false;
      game._guardianAttack = false;
      boss.telegraph=null;
      // the cooldown to the NEXT attack starts now, after this one has fully resolved — previously
      // it ran concurrently with the wind-up itself, so the boss barely got any time to actually
      // move between attacks (worse the deeper the run, since wind-up stayed fixed while the
      // cooldown window shrank)
      const freq = clamp(1 - game.stageIndex*0.035, 0.38, 1);
      const baseRange = boss.phase===2 ? [0.6,1.0] : [0.95,1.5];
      let attackTimer = rand(baseRange[0], baseRange[1]) * freq;
      // guardians (floors 10, 20, 30...) get noticeably more room between attacks than regular
      // floor bosses — the fight is built around a few hard-hitting, deliberate attacks rather
      // than a continuous stream of smaller ones
      if(boss.isGuardian) attackTimer *= 1.6;
      boss.attackTimer = attackTimer;
    }
  } else if(boss.attackTimer<=0){
    pickBossAttack(boss);
  }
}

const ATTACK_NAMES = {
  charge: 'Embestida Ósea',
  boneSlam: 'Golpe Sísmico',
  boneShards: 'Lluvia de Fragmentos',
  boneCage: 'Jaula de Huesos',
  boneWall: 'Muralla de Huesos',
  boneGrab: 'Garra Ósea',
  radialBurst: 'Estallido Pútrido',
  blinkStrike: 'Golpe Fantasma',
  poisonPool: 'Aliento del Pantano',
  curseMark: 'Marca Maldita',
  wither: 'Marchitar',
  slam: 'Puño del Abismo',
  fireRain: 'Lluvia Ígnea',
  meteor: 'Caída Estelar',
  lavaGeyser: 'Géiseres de Lava',
  magmaCross: 'Cruz de Magma',
  blazingFissure: 'Fisura Ardiente',
  growingMagma: 'Magma Creciente',
  frostNova: 'Nova de Escarcha',
  iceCage: 'Jaula de Hielo',
  stormBolt: 'Rayo Certero',
  stormField: 'Campo de Tormenta',
  voidLance: 'Lanza del Vacío',
  voidRift: 'Grieta del Vacío',
  witchCauldron: 'Caldero de Bruja',
  gracefulVeil: 'Velo de Luz',
  glassRain: 'Lluvia de Cristal',
  blizzardWall: 'Muralla de Escarcha',
  frozenGround: 'Suelo Congelado',
  chainLightning: 'Rayo Encadenado',
  thunderdome: 'Cúpula de Tormenta',
  gravityWell: 'Pozo de Gravedad',
  starCollapse: 'Colapso Estelar',
  sisterCall: 'Llamado de las Hermanas',
  eyeLaser: 'Rayo del Ojo',
  megaLaser: 'Mega Rayo Láser',
  acidDeluge: 'El Gran Colapso',
  venomousWeb: 'Brote de la Red Venenosa',
  cursedFlameBreath: 'Aliento Maldito',
  twinCharge: 'Embestida Doble',
  mirrorDecoy: 'Señuelo Especular',
  glassField: 'Campo de Cristal',
  illusionSwap: 'Intercambio Ilusorio',
  mirrorGaze: 'Mirada del Espejo',
  fracturedBurst: 'Ráfaga Fracturada',
  boundStrike: 'Golpe Vinculado',
  bondPulse: 'Pulso Compartido',
  twinStrike: 'Golpe Doble',
  bondedShield: 'Escudo Espiritual',
  spiritLink: 'Vínculo Espiritual',
  iceLance: 'Lanza de Hielo',
  crystalPrison: 'Prisión de Cristal',
  avalanche: 'Avalancha',
  frostBreath: 'Aliento Helado',
  numbingChill: 'Frío Entumecedor',
  thunderStrike: 'Golpe de Trueno',
  stormVortex: 'Vórtice de Tormenta',
  staticField: 'Campo Estático',
  skySiege: 'Asedio Celestial',
  boltRunner: 'Rayo Corredor',
  voidTendrils: 'Tentáculos del Vacío',
  darkPulse: 'Pulso Oscuro',
  starlightDrain: 'Drenaje Estelar',
  umbraStep: 'Paso de Sombra',
  collapsingStar: 'Estrella Colapsante',
  royalDecree: 'Decreto Real',
  throneSlam: 'Golpe del Trono',
  crownfire: 'Fuego de Corona',
  finalJudgment: 'Juicio Final',
  soulBarrage: 'Ráfaga de Almas',
  boneCross: 'Cruz de Huesos',
  boneSpiral: 'Espiral Ósea',
  skullBarrage: 'Ráfaga de Cráneos',
  graveSpikes: 'Espinas de Tumba',
  boneWhip: 'Látigo de Hueso',
  deathRattle: 'Estertor Mortal',
  hauntingWail: 'Lamento Errante',
  cryptCollapse: 'Colapso de Cripta',
  boneShrapnel: 'Metralla Ósea',
  graveyardShift: 'Salto de Cementerio',
  deathMark: 'Marca Mortal',
  skeletalSwarm: 'Enjambre Esquelético',
  tombstoneSlam: 'Golpe de Lápida',
  ribcage: 'Jaula de Costillas',
  deathToll: 'Toque Funesto',
  skullStorm: 'Tormenta de Cráneos',
  gravebind: 'Atadura de Tumba',
  boneChain: 'Cadena Ósea',
  cryptWhisper: 'Susurro de Cripta',
  deathsDoor: 'Puerta de la Muerte',
  rattlingBones: 'Huesos Traqueteantes',
  deathKnell: 'Tañido Fúnebre',
  bogBurst: 'Estallido de Ciénaga',
  leechSwarm: 'Enjambre de Sanguijuelas',
  witchesCurse: 'Maldición de Bruja',
  numbTonic: 'Tónico Entumecedor',
  rootSnare: 'Trampa de Raíces',
  quicksand: 'Arena Movediza',
  poisonBrew: 'Brebaje Venenoso',
  witchsEye: 'Ojo de Bruja',
  cauldronBubble: 'Burbujeo del Caldero',
  swampSurge: 'Oleada del Pantano',
  willOWisp: 'Fuego Fatuo',
  vineLine: 'Sendero de Enredaderas',
  venomLash: 'Latigazo Venenoso',
  shadowBrew: 'Brebaje de Sombras',
  batSwarm: 'Enjambre de Murciélagos',
  mireField: 'Campo de Lodo',
  curseBind: 'Atadura Maldita',
  witchsMark: 'Marca de Bruja',
  spectralHex: 'Hechizo Espectral',
  gooBurst: 'Estallido Viscoso',
  plagueCloud: 'Nube de Plaga',
  witchesRing: 'Círculo de Brujas',
  lavaSpurt: 'Chorro de Lava',
  infernoRing: 'Anillo Infernal',
  brimstoneRain: 'Lluvia de Azufre',
  demonRoar: 'Rugido Demoníaco',
  ashCloud: 'Nube de Ceniza',
  moltenTrap: 'Trampa de Magma',
  cinderSwarm: 'Enjambre de Cenizas',
  flameSurge: 'Oleada de Llamas',
  infernalBond: 'Pacto Infernal',
  sulfurBreath: 'Aliento de Azufre',
  pyreCollapse: 'Colapso de la Pira',
  scorchedEarth: 'Tierra Quemada',
  demonEye: 'Ojo Demoníaco',
  infernalChains: 'Cadenas Infernales',
  brimstoneSpiral: 'Espiral de Azufre',
  flameWreath: 'Corona de Fuego',
  hellgate: 'Puerta Infernal',
  cinderVolley: 'Ráfaga de Cenizas',
  moltenWave: 'Ola de Magma',
  demonicHowl: 'Aullido Demoníaco',
  infernalCrown: 'Corona Infernal',
  demonicBlast: 'Estallido Demoníaco',
  abyssalCollapse: 'Colapso del Abismo',
  summon: 'Refuerzos',
  boneVolley: 'Ráfaga Ósea',
  risingSpikes: 'Espinas Crecientes',
  boneArmor: 'Armadura de Hueso',
  boneTrap: 'Trampa Oculta',
  toxicSpores: 'Esporas Tóxicas',
  swampGrasp: 'Garra del Pantano',
  witchesBlessing: 'Bendición del Pantano',
  hexTrail: 'Rastro Maldito',
  mudSlow: 'Lodo Aferrado',
  cinderBurst: 'Estallido de Cenizas',
  flameWhip: 'Latigazo de Fuego',
  emberField: 'Campo de Ascuas',
  moltenCore: 'Núcleo Fundido',
  cinderRain: 'Lluvia de Cenizas',
  thornVolley: 'Ráfaga de Espinas',
  bloomTrap: 'Trampa Floreciente',
  healingBloom: 'Florecer',
  lightTwins: 'Luces Gemelas',
  radiantPath: 'Sendero Radiante',
  fireWave: 'Oleada de Fuego',
  butterflyBurst: 'Danza de Alas',
  prismDash: 'Corte Prismático',
  radiantNova: 'Nova Radiante',
  rainbowLine: 'Cortina de Luz',
  spiralBloom: 'Floración Espiral',
  petalRing: 'Anillo de Pétalos',
  mirrorSplit: 'Fractura Especular',
  phantomBarrage: 'Ráfaga Fantasma',
  echoDash: 'Eco Cortante',
  twinPulse: 'Pulso Gemelo',
  twinSwap: 'Intercambio Espectral',
  crossFire: 'Fuego Cruzado',
  petalStorm: 'Tormenta de Pétalos',
  vineWhip: 'Latigazo de Enredadera',
  prismShard: 'Esquirla Prismática',
  nectarSwarm: 'Enjambre de Néctar',
  gildedThorns: 'Espinas Doradas',
  dewTrap: 'Trampa de Rocío',
  crystalBloom: 'Floración de Cristal',
  thornCage: 'Jaula de Espinas',
  sunbeamLine: 'Rayo de Sol',
  bloomRing: 'Anillo Floreciente',
  sunfireCross: 'Cruz de Sol',
  radianceField: 'Campo de Resplandor',
  lightCascade: 'Cascada de Luz',
  tangleRoots: 'Raíces Enredadas',
  mirrorBloom: 'Pulso de Luz',
  verdantSurge: 'Oleada Verdiente',
  glowWisp: 'Chispa Radiante',
  sunfireLance: 'Lanza de Sol',
  lightPollen: 'Polen Cegador',
  witheringPetals: 'Pétalos Marchitos',
  petalVeil: 'Velo de Pétalos',
  gardenGuardians: 'Guardianes del Jardín',
  shatterVolley: 'Ráfaga Quebrada',
  reflectedBarrage: 'Ráfaga Reflejada',
  prismaticShards: 'Esquirlas Prismáticas',
  mirageSwarm: 'Enjambre de Espejismos',
  silverStrike: 'Golpe de Plata',
  mirrorMaze: 'Laberinto de Espejos',
  shatterZone: 'Zona Quebradiza',
  reflectivePool: 'Estanque Reflectante',
  glassSpikes: 'Espinas de Cristal',
  doubleVision: 'Visión Doble',
  distortionField: 'Campo de Distorsión',
  echoChamber: 'Cámara del Eco',
  hallOfMirrors: 'Salón de los Espejos',
  mirrorShatter: 'Espejo Roto',
  reflectivePulse: 'Pulso Reflejado',
  phantomChaser: 'Fantasma Acechante',
  reflectedLance: 'Lanza Reflejada',
  hauntingReflection: 'Reflejo Persecutor',
  disorientingGaze: 'Mirada Desorientadora',
  shatteredFocus: 'Concentración Rota',
  silveredSkin: 'Piel Plateada',
  mirroredEcho: 'Eco Espectral',
  twinVolley: 'Ráfaga Gemela',
  soulShards: 'Esquirlas del Alma',
  pairedBolts: 'Rayos Emparejados',
  spiritBurst: 'Estallido Espiritual',
  boundArrows: 'Flechas Vinculadas',
  soulTether: 'Lazo del Alma',
  kinshipRing: 'Anillo de Parentesco',
  dualBloom: 'Floración Doble',
  sharedPain: 'Dolor Compartido',
  weaveTrap: 'Trampa Entrelazada',
  pactCircle: 'Círculo del Pacto',
  tetherLine: 'Línea del Vínculo',
  soulPulse: 'Pulso del Alma',
  boundSurge: 'Oleada Vinculada',
  spiritChaser: 'Espíritu Acechante',
  soulLance: 'Lanza del Alma',
  kinseeker: 'Buscador de Sangre',
  sharedWound: 'Herida Compartida',
  soulSap: 'Drenaje del Alma',
  boundCurse: 'Maldición Vinculante',
  sharedBlessing: 'Bendición Compartida',
  twinSpirits: 'Espíritus Gemelos',
};
const GROUND_SELF_ATTACKS = ['boneSlam','slam','fireWave','mirrorBloom','verdantSurge','mirrorShatter','reflectivePulse','soulPulse','boundSurge'];
const GROUND_TARGET_ATTACKS = ['fireRain','poisonPool','meteor','boneCage','boneWall','lavaGeyser','growingMagma','iceCage','stormField','voidRift','risingSpikes','boneTrap','swampGrasp','hexTrail','emberField','moltenCore','cinderRain','bloomTrap','radiantPath','glassField','bondPulse','spiritLink','crystalPrison','avalanche','stormVortex','skySiege','voidTendrils','collapsingStar','finalJudgment','thunderStrike','boneCross','boneSpiral','graveSpikes','cryptCollapse','ribcage','deathToll','deathsDoor','deathKnell','rootSnare','quicksand','poisonBrew','swampSurge','vineLine','mireField','plagueCloud','witchesRing','infernoRing','brimstoneRain','moltenTrap','flameSurge','pyreCollapse','scorchedEarth','brimstoneSpiral','moltenWave','dewTrap','crystalBloom','thornCage','sunbeamLine','bloomRing','sunfireCross','radianceField','lightCascade','tangleRoots','mirrorMaze','shatterZone','reflectivePool','glassSpikes','doubleVision','distortionField','echoChamber','hallOfMirrors','soulTether','kinshipRing','dualBloom','sharedPain','weaveTrap','pactCircle','tetherLine','acidDeluge','venomousWeb'];
const DASH_ATTACKS = ['charge','blinkStrike','prismDash','echoDash'];
const BURST_ATTACKS = ['radialBurst','radiantNova','butterflyBurst','rainbowLine','spiralBloom','petalRing','mirrorSplit','phantomBarrage','twinPulse','crossFire','boneShards','frostNova','stormBolt','boneVolley','toxicSpores','boneArmor','witchesBlessing','summon','mudSlow','cinderBurst','thornVolley','healingBloom','lightTwins','flameWhip','eyeLaser','cursedFlameBreath','mirrorDecoy','fracturedBurst','boundStrike','illusionSwap','twinStrike','mirrorGaze','bondedShield','iceLance','boltRunner','soulBarrage','frostBreath','darkPulse','crownfire','numbingChill','staticField','starlightDrain','royalDecree','umbraStep','throneSlam','skullBarrage','boneShrapnel','skeletalSwarm','skullStorm','boneWhip','deathRattle','hauntingWail','graveyardShift','deathMark','tombstoneSlam','gravebind','boneChain','cryptWhisper','rattlingBones','bogBurst','leechSwarm','witchesCurse','numbTonic','witchsEye','cauldronBubble','willOWisp','venomLash','shadowBrew','batSwarm','curseBind','witchsMark','spectralHex','gooBurst','lavaSpurt','cinderSwarm','demonRoar','ashCloud','infernalBond','sulfurBreath','demonEye','infernalChains','flameWreath','hellgate','cinderVolley','demonicHowl','infernalCrown','petalStorm','vineWhip','prismShard','nectarSwarm','gildedThorns','glowWisp','sunfireLance','lightPollen','witheringPetals','petalVeil','gardenGuardians','shatterVolley','reflectedBarrage','prismaticShards','mirageSwarm','silverStrike','phantomChaser','reflectedLance','hauntingReflection','disorientingGaze','shatteredFocus','silveredSkin','mirroredEcho','twinVolley','soulShards','pairedBolts','spiritBurst','boundArrows','spiritChaser','soulLance','kinseeker','sharedWound','soulSap','boundCurse','sharedBlessing','twinSpirits'];
const DASH_ATTACKS_EXTRA_TELEGRAPH = ['twinCharge']; // uses the simple line telegraph like real dash attacks, without counting toward the dash budget

function showAttackBanner(boss, type){
  const el = $('boss-attack-name');
  if(!el) return;
  const name = ATTACK_NAMES[type];
  if(!name) return;
  el.textContent = name;
  el.style.color = boss.def.color;
  el.classList.remove('show');
  void el.offsetWidth;
  el.classList.add('show');
}

// Picks the next attack from the pool, but blocks a type that's already been used the last
// two times in a row (so no boss can do the same attack 3+ times back to back). The Empress of
// Light is exempt — her kit is built around repeatable light-weaving patterns.
function pickAttackAvoidingTripleRepeat(boss, pool){
  boss.recentAttacks = boss.recentAttacks || [];
  let candidates = pool;
  if(boss.kind!=='empressOfLight' && boss.recentAttacks.length>=2 &&
     boss.recentAttacks[boss.recentAttacks.length-1] === boss.recentAttacks[boss.recentAttacks.length-2]){
    const banned = boss.recentAttacks[boss.recentAttacks.length-1];
    const filtered = pool.filter(t=>t!==banned);
    candidates = filtered.length ? filtered : pool;
  }
  const type = candidates[Math.floor(Math.random()*candidates.length)];
  boss.recentAttacks.push(type);
  if(boss.recentAttacks.length>2) boss.recentAttacks.shift();
  return type;
}

function pickBossAttack(boss){
  const basePool = BOSS_ATTACKS[boss.kind] || ['charge','summon','radialBurst'];
  let pool = boss.phase===2 ? [...basePool, basePool[basePool.length-1], basePool[basePool.length-2]] : basePool;
  if(boss.phase!==2) pool = pool.filter(t=>t!=='megaLaser'); // signature enrage move, can't roll before half HP
  boss.attackCount = (boss.attackCount||0)+1;
  if(boss.lastSummonAttack===undefined) boss.lastSummonAttack = -10;
  const canSummon = (boss.attackCount - boss.lastSummonAttack) >= 10;
  if(!canSummon && pool.includes('summon')){
    const filtered = pool.filter(t=>t!=='summon');
    pool = filtered.length ? filtered : pool;
  }
  let type;
  if(boss.forceNextAttack){
    type = boss.forceNextAttack;
    boss.forceNextAttack = null;
    boss.recentAttacks = boss.recentAttacks||[];
    boss.recentAttacks.push(type);
    if(boss.recentAttacks.length>2) boss.recentAttacks.shift();
  } else {
    type = pickAttackAvoidingTripleRepeat(boss, pool);
  }
  if(type==='summon') boss.lastSummonAttack = boss.attackCount;
  const p = game.player;
  boss.telegraph = { type, t: 0.55, dur: 0.55, tx:p.x, ty:p.y };
  if(type==='blinkStrike'){
    const ang = Math.random()*Math.PI*2;
    const bnds = arenaBounds();
    const oldX = boss.x, oldY = boss.y;
    boss.x = clamp(p.x+Math.cos(ang)*110, bnds.x+boss.radius, bnds.x+bnds.w-boss.radius);
    boss.y = clamp(p.y+Math.sin(ang)*110, bnds.y+boss.radius, bnds.y+bnds.h-boss.radius);
    boss.telegraph.t = 0.85; boss.telegraph.dur = 0.85; // boss teleports in immediately but the strike lands later, so it's dodgeable
    spawnShockwave(oldX, oldY, boss.def.color, boss.radius*1.4, 0.3);
    spawnShockwave(boss.x, boss.y, boss.def.color, boss.radius*1.4, 0.3);
    addParticles(oldX,oldY,boss.def.color,14,160,0.3);
    addParticles(boss.x,boss.y,boss.def.color,20,200,0.4);
  }
  if(type==='boneGrab'){
    // the wind now pulls from anywhere in the arena — there's no cone to sidestep. Instead, a
    // single small safe pocket opens up somewhere in the room where the wind can't reach; you
    // have to actually run there and hold it, not just juke sideways out of a line
    boss.telegraph.t = 1.5; boss.telegraph.dur = 1.5;
    const bnds = arenaBounds();
    let sx, sy, tries=0;
    do {
      sx = rand(bnds.x+90, bnds.x+bnds.w-90);
      sy = rand(bnds.y+90, bnds.y+bnds.h-90);
      tries++;
    } while(dist(sx,sy,boss.x,boss.y)<220 && tries<12);
    boss.telegraph.safeX = sx; boss.telegraph.safeY = sy; boss.telegraph.safeR = 78;
    spawnToast('¡El viento arrasa la sala entera — buscá el ojo de calma!');
  }
  if(type==='gravityWell'){
    boss.telegraph.t = 1.1; boss.telegraph.dur = 1.1; // slower than boneGrab, but escapable by running early since the well doesn't chase
  }
  if(type==='megaLaser'){
    // a wide sweeping beam (or two, if the twin sister is still alive) that rotates across a big
    // arc — you can't just juke sideways once, you have to get ahead of the sweep and stay there
    const dur = 2.6;
    boss.telegraph.t = dur; boss.telegraph.dur = dur;
    boss.telegraph.hotAt = 0.55; // brief full-arc preview before the beam actually starts burning
    const toPlayerAngle = Math.atan2(p.y-boss.y, p.x-boss.x);
    const sweepDir = Math.random()<0.5 ? 1 : -1;
    const sweepArc = Math.PI*0.8;
    boss.telegraph.sweepDir = sweepDir;
    boss.telegraph.sweepArc = sweepArc;
    boss.telegraph.startAngle = toPlayerAngle - sweepDir*sweepArc/2;
    boss.telegraph.beamLen = Math.max(arenaBounds().w, arenaBounds().h);
    if(boss.twin && boss.twin.alive){
      // the twin's beam sweeps the opposite direction, crossing over the main beam — much less
      // room to hide than a single sweep alone
      const twinToPlayerAngle = Math.atan2(p.y-boss.twin.y, p.x-boss.twin.x);
      boss.telegraph.twinStartAngle = twinToPlayerAngle - (-sweepDir)*sweepArc/2;
    }
    spawnToast('Un rayo gemelo comienza a barrer la sala — anticipate al giro');
  }
  if(type==='acidDeluge'){
    // she retreats to the back of the room and channels — the actual rain is staggered across
    // the whole floor via many individually-timed hazards spawned in resolveBossAttack, so there's
    // no single safe corner to camp in for long
    const bnds = arenaBounds();
    boss.x = clamp(bnds.x+bnds.w/2, bnds.x+boss.radius, bnds.x+bnds.w-boss.radius);
    boss.y = clamp(bnds.y+bnds.h*0.14, bnds.y+boss.radius, bnds.y+bnds.h-boss.radius);
    boss.telegraph.t = 0.8; boss.telegraph.dur = 0.8;
    addParticles(boss.x,boss.y,boss.def.color,20,160,0.4);
    spawnToast('La Bruja Madre se retira al fondo y comienza a canalizar');
  }
  if(type==='venomousWeb'){
    boss.telegraph.t = 0.7; boss.telegraph.dur = 0.7; // brief roar before the floor cracks open
  }
  addParticles(boss.x,boss.y, boss.def.color, 10, 100, 0.6);
  if(boss.isGuardian){
    // guardians give you noticeably less warning before an attack lands than the same attack
    // from a regular floor boss — the read-and-react window itself shrinks, which is what
    // actually makes an attack harder to dodge
    boss.telegraph.t *= 0.8;
    boss.telegraph.dur *= 0.8;
  }
  showAttackBanner(boss, type);
}

function resolveBossAttack(type, tg){
  const p = game.player;
  const boss = game.boss;
  const b = arenaBounds();
  const targetX = tg ? tg.tx : p.x;
  const targetY = tg ? tg.ty : p.y;
  if(type==='charge'){
    const ang = Math.atan2(p.y-boss.y,p.x-boss.x);
    const dashDist=220, steps=10;
    for(let i=0;i<steps;i++){
      boss.x += Math.cos(ang)*(dashDist/steps);
      boss.y += Math.sin(ang)*(dashDist/steps);
    }
    if(dist(boss.x,boss.y,p.x,p.y) < boss.radius+p.radius+20) hitPlayer(boss.dmg);
    shake(8);
    addParticles(boss.x,boss.y,boss.def.color,16,220,0.4);
  } else if(type==='boneShards'){
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    const n=7;
    for(let i=0;i<n;i++){
      const a = ang + (i-(n-1)/2)*0.13;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(a)*260, vy:Math.sin(a)*260,
        dmg:boss.dmg*0.6, radius:7, owner:'enemy', color:boss.def.color, life:2.4, shape:'shard' });
    }
    addParticles(boss.x,boss.y,boss.def.color,14,150,0.4);
    shake(5);
  } else if(type==='summon'){
    for(let i=0;i<2;i++){
      const ang = Math.random()*Math.PI*2;
      spawnEnemyAt(boss.def.minion, boss.x+Math.cos(ang)*70, boss.y+Math.sin(ang)*70, true);
    }
    spawnToast('El jefe invoca refuerzos');
  } else if(type==='radialBurst'){
    const n=10;
    for(let i=0;i<n;i++){
      const ang = (i/n)*Math.PI*2;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*230, vy:Math.sin(ang)*230,
        dmg:boss.dmg*0.7, radius:8, owner:'enemy', color:boss.def.color, life:2.2 });
    }
    shake(6);
  } else if(type==='boneSlam'){
    const r=150;
    if(dist(boss.x,boss.y,p.x,p.y)<r) hitPlayer(boss.dmg*1.1);
    addParticles(boss.x,boss.y,'#d9cdb3',28,260,0.5);
    spawnShockwave(boss.x,boss.y,'#d9cdb3',r,0.4);
    shake(9);
  } else if(type==='blinkStrike'){
    if(dist(boss.x,boss.y,p.x,p.y)<boss.radius+p.radius+30) hitPlayer(boss.dmg*0.7);
    addParticles(boss.x,boss.y,boss.def.color,10,150,0.3);
    shake(4);
  } else if(type==='slam'){
    const r=170;
    if(dist(boss.x,boss.y,p.x,p.y)<r) hitPlayer(boss.dmg*1.2);
    addParticles(boss.x,boss.y,'#ff5a3d',32,280,0.55);
    spawnShockwave(boss.x,boss.y,'#ff5a3d',r,0.45);
    shake(11);
  } else if(type==='magmaCross'){
    // fire erupts from the boss's own position in a fixed cross, unlike the scattered rings other bosses use
    const dirs = [[1,0],[-1,0],[0,1],[0,-1]];
    dirs.forEach(([dx,dy])=>{
      for(let k=1;k<=3;k++){
        const hx = clamp(boss.x+dx*k*58, b.x+22, b.x+b.w-22);
        const hy = clamp(boss.y+dy*k*58, b.y+22, b.y+b.h-22);
        game.hazards.push({ x:hx, y:hy, r:30, type:'fire', telegraph:0.6, active:1.3, tick:0, dmg:boss.dmg*0.5 });
      }
    });
    addParticles(boss.x, boss.y, '#ff5a3d', 24, 180, 0.4);
    spawnToast('El magma se abre en cruz');
  } else if(type==='blazingFissure'){
    // a solid crack of fire splits the arena in a straight line through where you were standing,
    // leaving exactly one gap open — find it and get through
    const vertical = Math.random()<0.5;
    const gapFrac = rand(0.22,0.78);
    const segments = 9;
    for(let i=0;i<segments;i++){
      const frac = i/(segments-1);
      if(Math.abs(frac-gapFrac) < 0.09) continue; // the escape gap
      let hx,hy;
      if(vertical){ hx = clamp(targetX, b.x+30,b.x+b.w-30); hy = clamp(b.y+30+frac*(b.h-60), b.y+30, b.y+b.h-30); }
      else { hy = clamp(targetY, b.y+30,b.y+b.h-30); hx = clamp(b.x+30+frac*(b.w-60), b.x+30, b.x+b.w-30); }
      game.hazards.push({ x:hx, y:hy, r:34, type:'fire', telegraph:0.7, active:1.4, tick:0, dmg:boss.dmg*0.55 });
    }
    addParticles(boss.x,boss.y,'#ff5a3d',20,180,0.4);
    spawnToast('Una fisura de fuego parte la arena en dos');
  } else if(type==='growingMagma'){
    // erupts small at your feet but keeps spreading for its whole duration — standing still is fatal
    game.hazards.push({ x:targetX, y:targetY, r:18, type:'fire', telegraph:0.5, active:2.2, tick:0, dmg:boss.dmg*0.45,
      expanding:true, expandRate:58 });
    addParticles(targetX,targetY,'#ff5a3d',18,160,0.4);
    spawnToast('El magma no deja de crecer');
  } else if(type==='fireRain'){
    for(let i=0;i<4;i++){
      const hx = clamp(targetX+rand(-140,140), b.x+24, b.x+b.w-24);
      const hy = clamp(targetY+rand(-140,140), b.y+24, b.y+b.h-24);
      game.hazards.push({ x:hx, y:hy, r:46, type:'fire', telegraph:0.7, active:1.8, tick:0, dmg:boss.dmg*0.5 });
    }
    spawnToast('El suelo arde bajo tus pies');
  } else if(type==='butterflyBurst'){
    const n=16;
    for(let i=0;i<n;i++){
      const ang = (i/n)*Math.PI*4;
      const speed = 160+(i%2)*40;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*speed, vy:Math.sin(ang)*speed,
        dmg:boss.dmg*0.55, radius:7, owner:'enemy', color: i%2?'#ffd6f0':'#ffcb47', life:2.4, shape:'feather' });
    }
    addParticles(boss.x,boss.y,'#ffb3ec',22,180,0.5);
  } else if(type==='prismDash'){
    for(let d=0; d<3; d++){
      const ang = Math.atan2(p.y-boss.y, p.x-boss.x) + rand(-0.5,0.5);
      const dashDist=140, steps=6;
      for(let i=0;i<steps;i++){
        boss.x = clamp(boss.x+Math.cos(ang)*(dashDist/steps), b.x+boss.radius, b.x+b.w-boss.radius);
        boss.y = clamp(boss.y+Math.sin(ang)*(dashDist/steps), b.y+boss.radius, b.y+b.h-boss.radius);
        spawnAfterimage(boss.x, boss.y, boss.radius, boss.def.color);
        addParticles(boss.x,boss.y,boss.def.color,3,80,0.3);
      }
      if(dist(boss.x,boss.y,p.x,p.y) < boss.radius+p.radius+16) hitPlayer(boss.dmg*0.6);
    }
    shake(7);
  } else if(type==='radiantNova'){
    const n=14;
    for(let ring=0; ring<2; ring++){
      for(let i=0;i<n;i++){
        const ang = (i/n)*Math.PI*2 + (ring?Math.PI/n:0);
        const speed = 180+ring*70;
        spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*speed, vy:Math.sin(ang)*speed,
          dmg:boss.dmg*0.6, radius:8, owner:'enemy', color: ring?'#ffcb47':'#ffb3ec', life:2.4, shape:'orb' });
      }
    }
    shake(8);
  } else if(type==='boneCage'){
    const n=6;
    for(let k=0;k<n;k++){
      const ang=(k/n)*Math.PI*2;
      const hx = clamp(targetX+Math.cos(ang)*90, b.x+22, b.x+b.w-22);
      const hy = clamp(targetY+Math.sin(ang)*90, b.y+22, b.y+b.h-22);
      game.hazards.push({ x:hx, y:hy, r:28, type:'spike', telegraph:0.55, active:0.9, tick:0, dmg:boss.dmg*0.6 });
    }
    addParticles(targetX, targetY, '#d9cdb3', 20, 160, 0.4);
    spawnToast('Huesos brotan a tu alrededor');
  } else if(type==='poisonPool'){
    for(let i=0;i<3;i++){
      const hx = clamp(targetX+rand(-160,160), b.x+24, b.x+b.w-24);
      const hy = clamp(targetY+rand(-160,160), b.y+24, b.y+b.h-24);
      game.hazards.push({ x:hx, y:hy, r:52, type:'poison', telegraph:0.6, active:3.2, tick:0, dmg:boss.dmg*0.28 });
    }
    addParticles(targetX, targetY, '#8bff6b', 22, 130, 0.45);
    spawnToast('El pantano exhala veneno');
  } else if(type==='meteor'){
    game.hazards.push({ x:targetX, y:targetY, r:95, type:'fire', telegraph:1.1, active:0.5, tick:0, dmg:boss.dmg*1.6 });
    addParticles(targetX, targetY, '#ff5a3d', 34, 260, 0.6);
    spawnToast('Algo cae del cielo');
    shake(4);
  } else if(type==='rainbowLine'){
    const dir = Math.random()<0.5 ? 1 : -1;
    const rows=3;
    for(let r=0;r<rows;r++){
      const y = clamp(b.y + b.h*(0.2+r*0.3), b.y+20, b.y+b.h-20);
      for(let k=0;k<6;k++){
        spawnProjectile({ x: dir>0? b.x-20-k*26 : b.x+b.w+20+k*26, y,
          vx: dir*260, vy:0, dmg:boss.dmg*0.45, radius:8, owner:'enemy',
          color: ['#ffb3ec','#ffcb47','#6a8dff'][k%3], life:3, shape:'orb' });
      }
    }
    shake(5);
  } else if(type==='spiralBloom'){
    const arms=5, perArm=6;
    const baseAng = Math.random()*Math.PI*2;
    for(let a=0;a<arms;a++){
      for(let k=0;k<perArm;k++){
        const ang = baseAng + (a/arms)*Math.PI*2 + k*0.11;
        const speed = 120+k*14;
        spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*speed, vy:Math.sin(ang)*speed,
          dmg:boss.dmg*0.32, radius:6, owner:'enemy', color: k%2?'#ffd6f0':'#ffcb47', life:2.6, shape:'feather' });
      }
    }
    addParticles(boss.x,boss.y,'#ffb3ec',18,150,0.4);
  } else if(type==='petalRing'){
    const n=20;
    const gapIndex = Math.floor(Math.random()*n);
    for(let ring=0; ring<2; ring++){
      for(let i=0;i<n;i++){
        if(i===gapIndex || i===(gapIndex+1)%n) continue; // dodge window
        const ang = (i/n)*Math.PI*2 + (ring?(Math.PI/n):0);
        const speed = 140+ring*50;
        spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*speed, vy:Math.sin(ang)*speed,
          dmg:boss.dmg*0.4, radius:7, owner:'enemy', color: ring?'#6a8dff':'#ffb3ec', life:2.8, shape:'feather' });
      }
    }
    addParticles(boss.x,boss.y,'#ffcb47',20,170,0.45);
  } else if(type==='boneWall'){
    const dir = Math.atan2(p.y-boss.y, p.x-boss.x);
    for(let k=0;k<6;k++){
      const dd = 60+k*55;
      const hx = clamp(boss.x+Math.cos(dir)*dd, b.x+20, b.x+b.w-20);
      const hy = clamp(boss.y+Math.sin(dir)*dd, b.y+20, b.y+b.h-20);
      game.hazards.push({ x:hx, y:hy, r:34, type:'spike', telegraph:0.5, active:1.0, tick:0, dmg:boss.dmg*0.7 });
    }
    spawnToast('Una muralla de huesos avanza');
  } else if(type==='curseMark'){
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x, y:boss.y, vx:Math.cos(ang)*95, vy:Math.sin(ang)*95,
      dmg:boss.dmg*0.9, radius:14, owner:'enemy', color:'#a44fd9', life:5.5, homing:true, poison:true, shape:'wisp' });
    spawnToast('Una marca maldita te persigue');
  } else if(type==='lavaGeyser'){
    for(let k=0;k<5;k++){
      const hx = rand(b.x+40, b.x+b.w-40);
      const hy = rand(b.y+40, b.y+b.h-40);
      game.hazards.push({ x:hx, y:hy, r:55, type:'fire', telegraph:0.9, active:1.2, tick:0, dmg:boss.dmg*0.6 });
    }
    spawnToast('El suelo entero burbujea');
  } else if(type==='mirrorSplit'){
    const b2x = clamp(boss.x + (boss.x-p.x)*0.4, b.x+20, b.x+b.w-20);
    const b2y = clamp(boss.y + (boss.y-p.y)*0.4, b.y+20, b.y+b.h-20);
    [{x:boss.x,y:boss.y},{x:b2x,y:b2y}].forEach(origin=>{
      const n=8;
      for(let i=0;i<n;i++){
        const ang=(i/n)*Math.PI*2;
        spawnProjectile({ x:origin.x,y:origin.y, vx:Math.cos(ang)*200, vy:Math.sin(ang)*200,
          dmg:boss.dmg*0.5, radius:7, owner:'enemy', color:'#e8e8f5', life:2.2, shape:'shard' });
      }
    });
    shake(6);
  } else if(type==='phantomBarrage'){
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    const n=9;
    for(let i=0;i<n;i++){
      const ang = ang0 + (i-(n-1)/2)*0.13;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*300, vy:Math.sin(ang)*300,
        dmg:boss.dmg*0.45, radius:6, owner:'enemy', color:'#c9c9d4', life:2, shape:'wisp' });
    }
  } else if(type==='echoDash'){
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    const dashDist=260, steps=6;
    for(let i=0;i<steps;i++){
      boss.x = clamp(boss.x+Math.cos(ang)*(dashDist/steps), b.x+boss.radius, b.x+b.w-boss.radius);
      boss.y = clamp(boss.y+Math.sin(ang)*(dashDist/steps), b.y+boss.radius, b.y+b.h-boss.radius);
      spawnAfterimage(boss.x, boss.y, boss.radius, boss.def.color);
      if(i%2===0) game.hazards.push({ x:boss.x, y:boss.y, r:34, type:'spike', telegraph:0.15, active:0.5, tick:0, dmg:boss.dmg*0.5 });
    }
    if(dist(boss.x,boss.y,p.x,p.y) < boss.radius+p.radius+18) hitPlayer(boss.dmg*0.7);
    shake(6);
  } else if(type==='twinPulse'){
    const origins = [{x:boss.x,y:boss.y}];
    if(boss.twin && boss.twin.alive) origins.push({x:boss.twin.x,y:boss.twin.y});
    origins.forEach(o=>{
      const n=10;
      for(let i=0;i<n;i++){
        const ang=(i/n)*Math.PI*2;
        spawnProjectile({ x:o.x,y:o.y, vx:Math.cos(ang)*190, vy:Math.sin(ang)*190,
          dmg:boss.dmg*0.5, radius:7, owner:'enemy', color:'#ff9ad1', life:2.2, shape:'orb' });
      }
    });
    shake(6);
  } else if(type==='crossFire'){
    const origins = [{x:boss.x,y:boss.y}];
    if(boss.twin && boss.twin.alive) origins.push({x:boss.twin.x,y:boss.twin.y});
    origins.forEach(o=>{
      const ang = Math.atan2(p.y-o.y, p.x-o.x);
      for(let k=-1;k<=1;k++){
        const a = ang + k*0.22;
        spawnProjectile({ x:o.x,y:o.y, vx:Math.cos(a)*280, vy:Math.sin(a)*280,
          dmg:boss.dmg*0.55, radius:7, owner:'enemy', color:'#ff9ad1', life:2.4, shape:'orb' });
      }
    });
  } else if(type==='boneGrab'){
    const inSafeZone = tg && tg.safeX!==undefined && dist(tg.safeX,tg.safeY,p.x,p.y) < tg.safeR;
    if(!inSafeZone){
      hitPlayer(boss.dmg*0.8);
      addParticles(p.x,p.y,boss.def.color,18,150,0.35);
      shake(7);
    } else {
      spawnToast('Encontraste el ojo de calma y el viento pasó de largo');
      addParticles(p.x,p.y,'#8bff6b',16,100,0.3);
    }
  } else if(type==='wither'){
    p.witherTimer = Math.max(p.witherTimer||0, 5);
    spawnToast('Sentís que tu fuerza se marchita');
    addParticles(p.x,p.y,'#a44fd9',22,140,0.4);
  } else if(type==='acidDeluge'){
    // El Gran Colapso: massive toxic stalactites and acid drops rain down across nearly the
    // entire arena, staggered so no one spot stays safe for long — keep moving, don't camp
    const n=22;
    for(let i=0;i<n;i++){
      const hx = rand(b.x+34, b.x+b.w-34);
      const hy = rand(b.y+34, b.y+b.h-34);
      game.hazards.push({ x:hx, y:hy, r:34+Math.random()*22, type:'poison',
        telegraph:0.4+Math.random()*2.6, active:0.5, tick:0, dmg:boss.dmg*0.4 });
    }
    spawnToast('¡Un diluvio ácido cae del techo sobre toda la sala!');
    shake(5);
  } else if(type==='venomousWeb'){
    // Brote de la Red Venenosa: the floor cracks open across almost the whole arena and thorned,
    // poisoned vines erupt everywhere except a carved-out path — a temporary maze you have to
    // actually navigate, not just an area to step out of once
    const cols=7, rows=5;
    const cellW = b.w/cols, cellH = b.h/rows;
    const safeCells = new Set();
    let row = Math.floor(Math.random()*rows);
    for(let col=0; col<cols; col++){
      safeCells.add(col+','+row);
      const r2 = Math.random();
      if(r2<0.35 && row>0){ row--; safeCells.add(col+','+row); }
      else if(r2>0.65 && row<rows-1){ row++; safeCells.add(col+','+row); }
    }
    for(let col=0; col<cols; col++){
      for(let r2=0; r2<rows; r2++){
        if(safeCells.has(col+','+r2)) continue;
        const hx = b.x + cellW*(col+0.5);
        const hy = b.y + cellH*(r2+0.5);
        game.hazards.push({ x:hx, y:hy, r:Math.min(cellW,cellH)*0.42, type:'poison',
          telegraph:0.6+Math.random()*0.4, active:5.5, tick:0, dmg:boss.dmg*0.32 });
      }
    }
    spawnToast('¡El suelo se agrieta — lianas venenosas brotan por toda la arena!');
    shake(6);
  } else if(type==='frostNova'){
    const n=10;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*210, vy:Math.sin(ang)*210,
        dmg:boss.dmg*0.55, radius:8, owner:'enemy', color:boss.def.color, life:2.4, shape:'orb',
        slow:{factor:0.55,dur:1.1} });
    }
    addParticles(boss.x,boss.y,boss.def.color,20,170,0.4);
    shake(6);
  } else if(type==='iceCage'){
    const n=6;
    for(let k=0;k<n;k++){
      const ang=(k/n)*Math.PI*2;
      const hx = clamp(targetX+Math.cos(ang)*90, b.x+22, b.x+b.w-22);
      const hy = clamp(targetY+Math.sin(ang)*90, b.y+22, b.y+b.h-22);
      game.hazards.push({ x:hx, y:hy, r:28, type:'ice', telegraph:0.55, active:0.9, tick:0, dmg:boss.dmg*0.55 });
    }
    addParticles(targetX, targetY, boss.def.color, 20, 160, 0.4);
    spawnToast('El hielo se cierra a tu alrededor');
  } else if(type==='stormBolt'){
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*620, vy:Math.sin(ang)*620,
      dmg:boss.dmg*0.95, radius:9, owner:'enemy', color:boss.def.color, life:1.2, shape:'orb' });
    addParticles(boss.x,boss.y,boss.def.color,12,140,0.3);
    shake(4);
  } else if(type==='stormField'){
    for(let i=0;i<4;i++){
      const hx = clamp(targetX+rand(-140,140), b.x+24, b.x+b.w-24);
      const hy = clamp(targetY+rand(-140,140), b.y+24, b.y+b.h-24);
      game.hazards.push({ x:hx, y:hy, r:40, type:'storm', telegraph:0.55, active:1.2, tick:0, dmg:boss.dmg*0.5 });
    }
    spawnToast('Rayos golpean el suelo a tu alrededor');
  } else if(type==='voidLance'){
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x, y:boss.y, vx:Math.cos(ang)*105, vy:Math.sin(ang)*105,
      dmg:boss.dmg*0.85, radius:13, owner:'enemy', color:boss.def.color, life:5, homing:true, shape:'wisp' });
    spawnToast('Una lanza del vacío te persigue');
  } else if(type==='voidRift'){
    for(let i=0;i<3;i++){
      const hx = clamp(targetX+rand(-160,160), b.x+24, b.x+b.w-24);
      const hy = clamp(targetY+rand(-160,160), b.y+24, b.y+b.h-24);
      game.hazards.push({ x:hx, y:hy, r:48, type:'void', telegraph:0.6, active:2.6, tick:0, dmg:boss.dmg*0.32 });
    }
    addParticles(targetX, targetY, boss.def.color, 22, 130, 0.45);
    spawnToast('El vacío se abre bajo tus pies');
  } else if(type==='witchCauldron'){
    // summons a cauldron away from her own body that fires its own spread of poison bolts —
    // the danger comes from a second point in space, not from the witch herself
    const cx = clamp(targetX, b.x+40, b.x+b.w-40), cy = clamp(targetY, b.y+40, b.y+b.h-40);
    const n=4;
    for(let i=0;i<n;i++){
      const ang = Math.atan2(p.y-cy, p.x-cx) + (i-(n-1)/2)*0.22;
      spawnProjectile({ x:cx,y:cy, vx:Math.cos(ang)*190, vy:Math.sin(ang)*190,
        dmg:boss.dmg*0.5, radius:8, owner:'enemy', color:'#8bff6b', life:2.6, poison:true, shape:'wisp' });
    }
    addParticles(cx,cy,'#8bff6b',16,120,0.4);
    spawnToast('La bruja invoca un caldero venenoso');
  } else if(type==='gracefulVeil'){
    // three concentric rings of light close in step by step around where you stood, instead of a
    // single ring or a line — you have to keep moving inward as each one lands
    const cx = clamp(p.x, b.x+60, b.x+b.w-60), cy = clamp(p.y, b.y+60, b.y+b.h-60);
    [220,150,90].forEach((rad, idx)=>{
      const n = 10;
      for(let i=0;i<n;i++){
        const ang = (i/n)*Math.PI*2;
        game.hazards.push({ x:cx+Math.cos(ang)*rad, y:cy+Math.sin(ang)*rad, r:22, type:'light',
          telegraph:0.5+idx*0.55, active:0.5, tick:0, dmg:boss.dmg*0.4 });
      }
    });
    addParticles(cx,cy,boss.def.color,20,140,0.4);
    spawnToast('Un velo de luz se cierra a tu alrededor');
  } else if(type==='glassRain'){
    // a grid of shards covers the floor, leaving one clear row and one clear column as the only
    // safe path — a 2D pattern instead of a line or a ring
    const cols=5, rows=4;
    const safeCol = Math.floor(Math.random()*cols);
    const safeRow = Math.floor(Math.random()*rows);
    for(let cx=0; cx<cols; cx++){
      for(let ry=0; ry<rows; ry++){
        if(cx===safeCol || ry===safeRow) continue;
        const hx = b.x + (cx+0.5)*(b.w/cols);
        const hy = b.y + (ry+0.5)*(b.h/rows);
        game.hazards.push({ x:hx, y:hy, r:34, type:'spike', telegraph:0.75, active:0.6, tick:0, dmg:boss.dmg*0.5 });
      }
    }
    addParticles(boss.x,boss.y,boss.def.color,18,150,0.35);
    spawnToast('El suelo se llena de fragmentos de espejo');
  } else if(type==='blizzardWall'){
    // a wall of ice sweeps across the whole arena from one side to the other, via staggered
    // telegraph timing along a line — you have to outrun it, not just dodge a fixed spot
    const vertical = Math.random()<0.5;
    const n = 10;
    const reverse = Math.random()<0.5;
    for(let i=0;i<n;i++){
      const frac = i/(n-1);
      const delay = reverse ? (1-frac)*1.3 : frac*1.3;
      let hx,hy;
      if(vertical){ hx = b.x+30+frac*(b.w-60); hy = clamp(p.y+rand(-40,40), b.y+30,b.y+b.h-30); }
      else { hy = b.y+30+frac*(b.h-60); hx = clamp(p.x+rand(-40,40), b.x+30,b.x+b.w-30); }
      game.hazards.push({ x:hx, y:hy, r:38, type:'ice', telegraph:0.4+delay, active:0.5, tick:0, dmg:boss.dmg*0.5 });
    }
    spawnToast('Una pared de escarcha barre la arena');
  } else if(type==='frozenGround'){
    // slows you directly (no projectile needed to trigger it) while ice erupts at random points
    // around the arena over the next few seconds
    p.slowTimer = Math.max(p.slowTimer||0, 3.5);
    p.slowFactor = 0.6;
    for(let i=0;i<5;i++){
      const hx = rand(b.x+40,b.x+b.w-40), hy = rand(b.y+40,b.y+b.h-40);
      game.hazards.push({ x:hx, y:hy, r:26, type:'ice', telegraph:0.4+rand(0,1.4), active:0.6, tick:0, dmg:boss.dmg*0.4 });
    }
    addParticles(p.x,p.y,boss.def.color,14,100,0.35);
    spawnToast('El suelo se congela bajo tus pies');
  } else if(type==='chainLightning'){
    // three sharp, deliberate strikes in sequence that jump around your position — a punchy triple
    // hit rather than a wide simultaneous barrage
    const points = [ {x:p.x,y:p.y}, {x:p.x+rand(-160,160),y:p.y+rand(-160,160)}, {x:p.x+rand(-160,160),y:p.y+rand(-160,160)} ];
    points.forEach((pt,idx)=>{
      const hx = clamp(pt.x, b.x+30,b.x+b.w-30), hy = clamp(pt.y, b.y+30,b.y+b.h-30);
      game.hazards.push({ x:hx, y:hy, r:36, type:'storm', telegraph:0.35+idx*0.5, active:0.35, tick:0, dmg:boss.dmg*0.65 });
    });
    spawnToast('El rayo salta de un punto a otro');
  } else if(type==='thunderdome'){
    // a long, chaotic barrage of many random strikes across the whole arena, rather than a
    // deliberate few — pure sustained chaos as the storm's ultimate move
    const n=9;
    for(let i=0;i<n;i++){
      const hx = rand(b.x+30,b.x+b.w-30), hy = rand(b.y+30,b.y+b.h-30);
      game.hazards.push({ x:hx, y:hy, r:30, type:'storm', telegraph:0.3+Math.random()*1.8, active:0.35, tick:0, dmg:boss.dmg*0.4 });
    }
    spawnToast('El cielo entero se descarga sobre la arena');
    shake(3);
  } else if(type==='gravityWell'){
    if(dist(tg.tx,tg.ty,p.x,p.y) < 40){
      hitPlayer(boss.dmg*0.9);
      addParticles(p.x,p.y,boss.def.color,20,160,0.4);
      shake(6);
    } else {
      spawnToast('Escapaste del pozo de gravedad a tiempo');
    }
  } else if(type==='megaLaser'){
    // all the damage already happened during the sweep itself (see the per-frame update) — this
    // is just the beam winding down
    spawnToast('El rayo gemelo se apaga');
    addParticles(boss.x,boss.y,'#ff3d3d',18,160,0.35);
    if(boss.twin && boss.twin.alive) addParticles(boss.twin.x,boss.twin.y,'#ff3d3d',18,160,0.35);
    shake(4);
  } else if(type==='starCollapse'){
    // one massive, long-telegraphed detonation centered on the boss itself, instead of many small
    // hazards — a single slow, unmistakable threat
    game.hazards.push({ x:boss.x, y:boss.y, r:150, type:'void', telegraph:1.5, active:0.4, tick:0, dmg:boss.dmg*1.5 });
    spawnToast('Algo colapsa en el centro del vacío...');
  } else if(type==='sisterCall'){
    // a defensive move: the twins heal and briefly shield each other, instead of another attack —
    // the only non-damaging move in the game
    const healAmt = boss.maxHp*0.08;
    boss.hp = Math.min(boss.maxHp, boss.hp+healAmt);
    boss.shieldTimer = Math.max(boss.shieldTimer||0, 3);
    addParticles(boss.x,boss.y,'#ff9ad1',20,150,0.4);
    if(boss.twin && boss.twin.alive){
      boss.twin.hp = Math.min(boss.twin.maxHp, boss.twin.hp+healAmt);
      boss.twin.shieldTimer = Math.max(boss.twin.shieldTimer||0, 3);
      addParticles(boss.twin.x,boss.twin.y,'#ff9ad1',20,150,0.4);
    }
    spawnToast('Las hermanas se protegen mutuamente');
  } else if(type==='eyeLaser'){
    // one eye locks on and fires a fast, precise shot — the "laser eye" half of the pair
    const origins = [{x:boss.x,y:boss.y}];
    if(boss.twin && boss.twin.alive) origins.push({x:boss.twin.x,y:boss.twin.y});
    const src = origins[Math.floor(Math.random()*origins.length)];
    const ang = Math.atan2(p.y-src.y, p.x-src.x);
    spawnProjectile({ x:src.x,y:src.y, vx:Math.cos(ang)*640, vy:Math.sin(ang)*640,
      dmg:boss.dmg*0.9, radius:6, owner:'enemy', color:'#ff4d4d', life:1.1, shape:'orb' });
    addParticles(src.x,src.y,'#ff4d4d',10,120,0.25);
    spawnToast('Un ojo dispara un rayo certero');
  } else if(type==='cursedFlameBreath'){
    // the other eye breathes a cone of cursed flame instead — always from whichever body is
    // currently furthest from the laser eye, so the two feel like distinct roles
    const src = (boss.twin && boss.twin.alive) ? boss.twin : boss;
    const ang0 = Math.atan2(p.y-src.y, p.x-src.x);
    const n=6;
    for(let i=0;i<n;i++){
      const ang = ang0 + (i-(n-1)/2)*0.14;
      spawnProjectile({ x:src.x,y:src.y, vx:Math.cos(ang)*260, vy:Math.sin(ang)*260,
        dmg:boss.dmg*0.45, radius:8, owner:'enemy', color:'#39d97a', life:1.8, shape:'ember' });
    }
    spawnToast('Fuego maldito brota del otro ojo');
  } else if(type==='twinCharge'){
    // both eyes charge you at once from wherever they currently are — the pair's signature
    // "stop circling and come straight at you" beat
    const chargers = [boss];
    if(boss.twin && boss.twin.alive) chargers.push(boss.twin);
    chargers.forEach(t=>{
      const ang = Math.atan2(p.y-t.y, p.x-t.x);
      const dashDist=170, steps=6, rad = t.radius||boss.radius*0.85;
      for(let i=0;i<steps;i++){
        t.x = clamp(t.x+Math.cos(ang)*(dashDist/steps), b.x+rad, b.x+b.w-rad);
        t.y = clamp(t.y+Math.sin(ang)*(dashDist/steps), b.y+rad, b.y+b.h-rad);
      }
      if(dist(t.x,t.y,p.x,p.y) < rad+p.radius+14) hitPlayer(boss.dmg*0.7);
      addParticles(t.x,t.y,'#ff9ad1',10,140,0.3);
    });
    shake(6);
    spawnToast('Ambos ojos embisten a la vez');
  } else if(type==='abyssalCollapse'){
    // the arena's edges become unsafe instead of the center — the opposite of every other ground
    // attack in the game, which threatens outward from a point
    const margin = 70;
    const edges = [
      {x:b.x+margin, y:b.y+b.h/2}, {x:b.x+b.w-margin, y:b.y+b.h/2},
      {x:b.x+b.w/2, y:b.y+margin}, {x:b.x+b.w/2, y:b.y+b.h-margin},
    ];
    edges.forEach(e=>{
      for(let i=0;i<3;i++){
        game.hazards.push({ x:e.x+rand(-50,50), y:e.y+rand(-50,50), r:70, type:'void', telegraph:0.6+i*0.5, active:1.6, tick:0, dmg:boss.dmg*0.4 });
      }
    });
    spawnToast('El abismo se traga los bordes de la arena');
    shake(6);
  } else if(type==='boneCross'){
    // fire erupts in a cross from where you stood, not from the boss — a bone-flavored variant
    // of magmaCross's shape, rooted on the target instead of the caster
    const dirs=[[1,0],[-1,0],[0,1],[0,-1]];
    dirs.forEach(([dx,dy])=>{
      for(let k=1;k<=2;k++){
        const hx = clamp(targetX+dx*k*50, b.x+22,b.x+b.w-22);
        const hy = clamp(targetY+dy*k*50, b.y+22,b.y+b.h-22);
        game.hazards.push({ x:hx, y:hy, r:26, type:'spike', telegraph:0.55, active:0.4, tick:0, dmg:boss.dmg*0.42 });
      }
    });
    spawnToast('Huesos brotan en cruz bajo tus pies');
  } else if(type==='boneSpiral'){
    // hazard points trace a bone spiral outward from your position
    const n=7;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2.6;
      const rad=18+i*15;
      const hx = clamp(targetX+Math.cos(ang)*rad, b.x+22,b.x+b.w-22);
      const hy = clamp(targetY+Math.sin(ang)*rad, b.y+22,b.y+b.h-22);
      game.hazards.push({ x:hx, y:hy, r:20, type:'spike', telegraph:0.3+i*0.09, active:0.4, tick:0, dmg:boss.dmg*0.38 });
    }
    spawnToast('Huesos giran en espiral hacia afuera');
  } else if(type==='skullBarrage'){
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    const n=5;
    for(let i=0;i<n;i++){
      const ang = ang0+(i-(n-1)/2)*0.12;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*260, vy:Math.sin(ang)*260,
        dmg:boss.dmg*0.5, radius:7, owner:'enemy', color:boss.def.color, life:1.8, shape:'shard' });
    }
  } else if(type==='graveSpikes'){
    const n=7;
    for(let i=0;i<n;i++){
      const hx = rand(b.x+30,b.x+b.w-30), hy = rand(b.y+30,b.y+b.h-30);
      game.hazards.push({ x:hx, y:hy, r:24, type:'spike', telegraph:0.5+Math.random()*1.0, active:0.4, tick:0, dmg:boss.dmg*0.32 });
    }
    spawnToast('Huesos brotan al azar por toda la arena');
  } else if(type==='boneWhip'){
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    const reach=250;
    const proj = (p.x-boss.x)*Math.cos(ang) + (p.y-boss.y)*Math.sin(ang);
    const perpDist = Math.hypot((p.x-boss.x)-Math.cos(ang)*proj, (p.y-boss.y)-Math.sin(ang)*proj);
    if(proj>0 && proj<reach && perpDist<38) hitPlayer(boss.dmg*0.85);
    addParticles(boss.x+Math.cos(ang)*reach, boss.y+Math.sin(ang)*reach, boss.def.color,10,110,0.22);
    shake(4);
  } else if(type==='deathRattle'){
    p.weakenTimer = Math.max(p.weakenTimer||0, 4);
    p.weakenFactor = 0.75;
    addParticles(p.x,p.y,boss.def.color,14,90,0.3);
    spawnToast('Un traqueteo mortal debilita tus golpes');
  } else if(type==='hauntingWail'){
    p.chillTimer = Math.max(p.chillTimer||0, 3.5);
    p.chillFactor = 1.5;
    addParticles(p.x,p.y,boss.def.color,14,90,0.3);
    spawnToast('Un lamento entumece tus reflejos');
  } else if(type==='cryptCollapse'){
    game.hazards.push({ x:targetX, y:targetY, r:120, type:'spike', telegraph:1.3, active:0.4, tick:0, dmg:boss.dmg*1.15 });
    spawnToast('La cripta colapsa sobre tu posición');
  } else if(type==='boneShrapnel'){
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    const n=6;
    for(let i=0;i<n;i++){
      const ang = ang0+(i-(n-1)/2)*0.45;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*200, vy:Math.sin(ang)*200,
        dmg:boss.dmg*0.48, radius:7, owner:'enemy', color:boss.def.color, life:2, shape:'shard' });
    }
  } else if(type==='graveyardShift'){
    // teleports to where you were STANDING WHEN THE ATTACK BEGAN, not your live position — so
    // running away during the wind-up actually avoids it, instead of it re-targeting you every frame
    boss.x = clamp(targetX+rand(-40,40), b.x+boss.radius, b.x+b.w-boss.radius);
    boss.y = clamp(targetY+rand(-40,40), b.y+boss.radius, b.y+b.h-boss.radius);
    if(dist(boss.x,boss.y,p.x,p.y) < boss.radius+p.radius+20) hitPlayer(boss.dmg*0.8);
    spawnShockwave(boss.x,boss.y,boss.def.color,50,0.3);
    spawnToast('Aparece de repente junto a vos');
  } else if(type==='deathMark'){
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*100, vy:Math.sin(ang)*100,
      dmg:boss.dmg*0.75, radius:12, owner:'enemy', color:boss.def.color, life:4.5, homing:true, shape:'wisp' });
    spawnToast('Una marca mortal te persigue');
  } else if(type==='skeletalSwarm'){
    const n=10;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*260, vy:Math.sin(ang)*260,
        dmg:boss.dmg*0.34, radius:5, owner:'enemy', color:boss.def.color, life:1.5, shape:'shard' });
    }
  } else if(type==='tombstoneSlam'){
    const r=150;
    if(dist(boss.x,boss.y,p.x,p.y)<r) hitPlayer(boss.dmg*1.0);
    addParticles(boss.x,boss.y,boss.def.color,22,200,0.4);
    spawnShockwave(boss.x,boss.y,boss.def.color,r,0.35);
    shake(7);
  } else if(type==='ribcage'){
    const n=8;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      const hx = clamp(targetX+Math.cos(ang)*95, b.x+22,b.x+b.w-22);
      const hy = clamp(targetY+Math.sin(ang)*95, b.y+22,b.y+b.h-22);
      game.hazards.push({ x:hx, y:hy, r:22, type:'spike', telegraph:0.6, active:0.4, tick:0, dmg:boss.dmg*0.36 });
    }
    spawnToast('Una jaula de costillas se cierra a tu alrededor');
  } else if(type==='deathToll'){
    const steps=7;
    for(let i=0;i<steps;i++){
      const frac=i/(steps-1);
      const hx = clamp(boss.x+(targetX-boss.x)*frac, b.x+24,b.x+b.w-24);
      const hy = clamp(boss.y+(targetY-boss.y)*frac, b.y+24,b.y+b.h-24);
      game.hazards.push({ x:hx, y:hy, r:24, type:'spike', telegraph:0.25+frac*0.85, active:0.4, tick:0, dmg:boss.dmg*0.38 });
    }
    spawnToast('Un eco funesto avanza hacia vos');
  } else if(type==='skullStorm'){
    [0,1,2].forEach(ring=>{
      const n=7, speed=170+ring*60;
      for(let i=0;i<n;i++){
        const ang=(i/n)*Math.PI*2 + ring*0.25;
        spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*speed, vy:Math.sin(ang)*speed,
          dmg:boss.dmg*0.34, radius:6, owner:'enemy', color:boss.def.color, life:1.9, shape:'shard' });
      }
    });
    shake(4);
  } else if(type==='gravebind'){
    p.slowTimer = Math.max(p.slowTimer||0, 3);
    p.slowFactor = 0.6;
    addParticles(p.x,p.y,boss.def.color,14,90,0.3);
    spawnToast('Manos huesudas se aferran a tus tobillos');
  } else if(type==='boneChain'){
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    [-0.3,0.3].forEach(off=>{
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang+off)*105, vy:Math.sin(ang+off)*105,
        dmg:boss.dmg*0.5, radius:9, owner:'enemy', color:boss.def.color, life:4.2, homing:true, shape:'shard' });
    });
    spawnToast('Dos marcas óseas te acechan');
  } else if(type==='cryptWhisper'){
    boss.hp = Math.min(boss.maxHp, boss.hp + boss.maxHp*0.08);
    addParticles(boss.x,boss.y,boss.def.color,16,110,0.3);
    spawnToast('Un susurro antiguo restaura sus fuerzas');
  } else if(type==='deathsDoor'){
    game.hazards.push({ x:targetX, y:targetY, r:20, type:'spike', telegraph:0.5, active:2.0, tick:0, dmg:boss.dmg*0.45, expanding:true, expandRate:52 });
    spawnToast('Una puerta hacia la muerte se abre bajo tus pies');
  } else if(type==='rattlingBones'){
    for(let k=0;k<3;k++){
      game.hazards.push({ x:boss.x, y:boss.y, r:14+k*11, type:'spike', telegraph:0.32*(k+1), active:0.3, tick:0, dmg:boss.dmg*0.42 });
    }
    addParticles(boss.x,boss.y,boss.def.color,16,140,0.3);
    spawnToast('Sus huesos traquetean con fuerza creciente');
  } else if(type==='deathKnell'){
    // an almost-instant single strike, the bone zone's reaction-test attack
    game.hazards.push({ x:targetX, y:targetY, r:32, type:'spike', telegraph:0.3, active:0.3, tick:0, dmg:boss.dmg*1.05 });
    spawnToast('Un tañido fúnebre marca el lugar');
  } else if(type==='boneVolley'){
    // a full ring of bone shards in every direction at once, instead of boneShards' narrow forward cone
    const n=12;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*220, vy:Math.sin(ang)*220,
        dmg:boss.dmg*0.5, radius:7, owner:'enemy', color:boss.def.color, life:2.2, shape:'shard' });
    }
    shake(5);
  } else if(type==='risingSpikes'){
    // an expanding ring of spikes starts small right at your feet and grows outward — the opposite
    // read of boneCage's fixed ring: here you have to keep running away as it grows
    const n=8;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      game.hazards.push({ x:targetX+Math.cos(ang)*30, y:targetY+Math.sin(ang)*30, r:20, type:'spike',
        telegraph:0.4, active:0.5, tick:0, dmg:boss.dmg*0.5, expanding:true, expandRate:70 });
    }
    addParticles(targetX,targetY,boss.def.color,14,120,0.3);
    spawnToast('Espinas brotan y avanzan hacia afuera');
  } else if(type==='boneArmor'){
    // a pure self-buff: the guardian hardens, absorbing a chunk of damage before it starts losing HP again.
    // capped (not additive) so repeated casts can't stack into permanent invulnerability
    boss.armorHp = Math.max(boss.armorHp||0, boss.maxHp*0.08);
    addParticles(boss.x,boss.y,boss.def.color,20,130,0.4);
    spawnToast('Sus huesos se endurecen');
  } else if(type==='boneTrap'){
    // a single hidden trap with a short telegraph and a big hit, instead of many scattered zones
    game.hazards.push({ x:targetX, y:targetY, r:46, type:'spike', telegraph:0.9, active:0.3, tick:0, dmg:boss.dmg*1.3 });
    spawnToast('Algo se oculta bajo el polvo...');
  } else if(type==='toxicSpores'){
    // a slow drifting cloud instead of a stationary pool — the danger creeps toward you over time
    const n=6;
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    for(let i=0;i<n;i++){
      const ang = ang0 + (i-(n-1)/2)*0.16;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*70, vy:Math.sin(ang)*70,
        dmg:boss.dmg*0.35, radius:11, owner:'enemy', color:'#8bff6b', life:3.4, poison:true, shape:'wisp' });
    }
    spawnToast('Esporas tóxicas flotan hacia vos');
  } else if(type==='swampGrasp'){
    // vines erupt in a tight cluster right under you with almost no warning — a quick punish
    // instead of a zone you can see coming from far away
    const n=5;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      game.hazards.push({ x:targetX+Math.cos(ang)*36, y:targetY+Math.sin(ang)*36, r:24, type:'spike',
        telegraph:0.35, active:0.4, tick:0, dmg:boss.dmg*0.55 });
    }
    spawnToast('Enredaderas brotan bajo tus pies');
  } else if(type==='witchesBlessing'){
    // a single big self-heal — a defensive move rather than another way to hurt you
    boss.hp = Math.min(boss.maxHp, boss.hp + boss.maxHp*0.12);
    addParticles(boss.x,boss.y,'#7fd98f',22,140,0.4);
    spawnToast('El pantano restaura sus fuerzas');
  } else if(type==='hexTrail'){
    // a poison trail snakes from the witch toward your position, arriving segment by segment as if
    // something were crawling across the floor toward you
    const steps=7;
    for(let i=0;i<steps;i++){
      const frac = i/(steps-1);
      const hx = clamp(boss.x + (targetX-boss.x)*frac, b.x+24, b.x+b.w-24);
      const hy = clamp(boss.y + (targetY-boss.y)*frac, b.y+24, b.y+b.h-24);
      game.hazards.push({ x:hx, y:hy, r:26, type:'poison', telegraph:0.25+frac*0.9, active:0.8, tick:0, dmg:boss.dmg*0.4 });
    }
    spawnToast('Algo repta hacia vos entre el lodo');
  } else if(type==='mudSlow'){
    // slows you directly, no projectile needed — the mud itself is the attack
    p.slowTimer = Math.max(p.slowTimer||0, 3);
    p.slowFactor = 0.62;
    addParticles(p.x,p.y,'#7fd98f',14,90,0.35);
    spawnToast('El barro se aferra a tus piernas');
  } else if(type==='bogBurst'){
    const n=10;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*190, vy:Math.sin(ang)*190,
        dmg:boss.dmg*0.42, radius:8, owner:'enemy', color:boss.def.color, life:3.0, poison:true, shape:'wisp' });
    }
  } else if(type==='leechSwarm'){
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    [-0.3,0.3].forEach(off=>{
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang+off)*95, vy:Math.sin(ang+off)*95,
        dmg:boss.dmg*0.45, radius:8, owner:'enemy', color:boss.def.color, life:4, homing:true, shape:'wisp' });
    });
    spawnToast('Sanguijuelas te acechan desde el lodo');
  } else if(type==='witchesCurse'){
    p.weakenTimer = Math.max(p.weakenTimer||0, 4);
    p.weakenFactor = 0.75;
    addParticles(p.x,p.y,boss.def.color,14,90,0.3);
    spawnToast('Una maldición debilita tus golpes');
  } else if(type==='numbTonic'){
    p.chillTimer = Math.max(p.chillTimer||0, 3.5);
    p.chillFactor = 1.5;
    addParticles(p.x,p.y,boss.def.color,14,90,0.3);
    spawnToast('Un tónico entumece tus reflejos');
  } else if(type==='rootSnare'){
    game.hazards.push({ x:targetX, y:targetY, r:42, type:'poison', telegraph:0.85, active:0.3, tick:0, dmg:boss.dmg*1.0 });
    spawnToast('Raíces se ocultan bajo el lodo');
  } else if(type==='quicksand'){
    game.hazards.push({ x:targetX, y:targetY, r:60, type:'poison', telegraph:0.6, active:1.4, tick:0, dmg:boss.dmg*0.35 });
    p.slowTimer = Math.max(p.slowTimer||0, 1.4);
    spawnToast('El suelo se vuelve arena movediza');
  } else if(type==='poisonBrew'){
    const n=6;
    for(let i=0;i<n;i++){
      const hx = rand(b.x+30,b.x+b.w-30), hy = rand(b.y+30,b.y+b.h-30);
      game.hazards.push({ x:hx, y:hy, r:26, type:'poison', telegraph:0.5+Math.random()*1.0, active:0.5, tick:0, dmg:boss.dmg*0.32 });
    }
    spawnToast('Frascos de veneno caen por toda la arena');
  } else if(type==='witchsEye'){
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*100, vy:Math.sin(ang)*100,
      dmg:boss.dmg*0.75, radius:12, owner:'enemy', color:boss.def.color, life:4.5, homing:true, shape:'wisp' });
    spawnToast('Un ojo maldito te vigila y te persigue');
  } else if(type==='cauldronBubble'){
    for(let k=0;k<3;k++){
      game.hazards.push({ x:boss.x, y:boss.y, r:15+k*11, type:'poison', telegraph:0.33*(k+1), active:0.3, tick:0, dmg:boss.dmg*0.4 });
    }
    addParticles(boss.x,boss.y,boss.def.color,16,130,0.3);
    spawnToast('Su caldero burbujea con fuerza creciente');
  } else if(type==='swampSurge'){
    const n=8;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      game.hazards.push({ x:targetX+Math.cos(ang)*28, y:targetY+Math.sin(ang)*28, r:18, type:'poison',
        telegraph:0.4, active:0.5, tick:0, dmg:boss.dmg*0.42, expanding:true, expandRate:62 });
    }
    spawnToast('El pantano se hincha y avanza hacia afuera');
  } else if(type==='willOWisp'){
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    const n=5;
    for(let i=0;i<n;i++){
      const ang = ang0+(i-(n-1)/2)*0.42;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*180, vy:Math.sin(ang)*180,
        dmg:boss.dmg*0.42, radius:8, owner:'enemy', color:boss.def.color, life:3.2, shape:'wisp' });
    }
  } else if(type==='vineLine'){
    const steps=7;
    for(let i=0;i<steps;i++){
      const frac=i/(steps-1);
      const hx = clamp(boss.x+(targetX-boss.x)*frac, b.x+24,b.x+b.w-24);
      const hy = clamp(boss.y+(targetY-boss.y)*frac, b.y+24,b.y+b.h-24);
      game.hazards.push({ x:hx, y:hy, r:22, type:'poison', telegraph:0.22+frac*0.8, active:0.4, tick:0, dmg:boss.dmg*0.36 });
    }
    spawnToast('Una enredadera repta hacia vos');
  } else if(type==='venomLash'){
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    const reach=250;
    const proj = (p.x-boss.x)*Math.cos(ang) + (p.y-boss.y)*Math.sin(ang);
    const perpDist = Math.hypot((p.x-boss.x)-Math.cos(ang)*proj, (p.y-boss.y)-Math.sin(ang)*proj);
    if(proj>0 && proj<reach && perpDist<38) hitPlayer(boss.dmg*0.85);
    addParticles(boss.x+Math.cos(ang)*reach, boss.y+Math.sin(ang)*reach, boss.def.color,10,110,0.22);
    shake(4);
  } else if(type==='shadowBrew'){
    boss.hp = Math.min(boss.maxHp, boss.hp + boss.maxHp*0.08);
    addParticles(boss.x,boss.y,boss.def.color,16,110,0.3);
    spawnToast('Bebe un brebaje que restaura sus fuerzas');
  } else if(type==='batSwarm'){
    const n=9;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*250, vy:Math.sin(ang)*250,
        dmg:boss.dmg*0.32, radius:5, owner:'enemy', color:boss.def.color, life:1.5, shape:'wisp' });
    }
  } else if(type==='mireField'){
    const n=7;
    for(let i=0;i<n;i++){
      const hx = rand(b.x+30,b.x+b.w-30), hy = rand(b.y+30,b.y+b.h-30);
      game.hazards.push({ x:hx, y:hy, r:24, type:'poison', telegraph:0.5+Math.random()*0.9, active:0.4, tick:0, dmg:boss.dmg*0.3 });
    }
    spawnToast('El lodo brota al azar por toda la arena');
  } else if(type==='curseBind'){
    p.slowTimer = Math.max(p.slowTimer||0, 3);
    p.slowFactor = 0.6;
    addParticles(p.x,p.y,boss.def.color,14,90,0.3);
    spawnToast('Una maldición se aferra a tus pasos');
  } else if(type==='witchsMark'){
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*105, vy:Math.sin(ang)*105,
      dmg:boss.dmg*0.72, radius:11, owner:'enemy', color:boss.def.color, life:4.2, homing:true, shape:'wisp' });
    spawnToast('Una marca de bruja te persigue');
  } else if(type==='spectralHex'){
    // teleports to where you were standing when the attack began, not your live position
    boss.x = clamp(targetX+rand(-40,40), b.x+boss.radius, b.x+b.w-boss.radius);
    boss.y = clamp(targetY+rand(-40,40), b.y+boss.radius, b.y+b.h-boss.radius);
    if(dist(boss.x,boss.y,p.x,p.y) < boss.radius+p.radius+20) hitPlayer(boss.dmg*0.8);
    spawnShockwave(boss.x,boss.y,boss.def.color,50,0.3);
    spawnToast('Se desvanece y aparece junto a vos');
  } else if(type==='gooBurst'){
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    const n=6;
    for(let i=0;i<n;i++){
      const ang = ang0+(i-(n-1)/2)*0.16;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*230, vy:Math.sin(ang)*230,
        dmg:boss.dmg*0.45, radius:7, owner:'enemy', color:boss.def.color, life:2.6, poison:true, shape:'wisp' });
    }
  } else if(type==='plagueCloud'){
    game.hazards.push({ x:targetX, y:targetY, r:110, type:'poison', telegraph:1.3, active:0.5, tick:0, dmg:boss.dmg*1.1 });
    spawnToast('Una nube de plaga se cierne sobre el lugar');
  } else if(type==='witchesRing'){
    const n=8;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      const hx = clamp(targetX+Math.cos(ang)*95, b.x+22,b.x+b.w-22);
      const hy = clamp(targetY+Math.sin(ang)*95, b.y+22,b.y+b.h-22);
      game.hazards.push({ x:hx, y:hy, r:22, type:'poison', telegraph:0.6, active:0.4, tick:0, dmg:boss.dmg*0.36 });
    }
    spawnToast('Un aquelarre invisible se cierra a tu alrededor');
  } else if(type==='flameWhip'){
    // an instant line-check lash toward you, resolving immediately rather than after a hazard delay —
    // a completely different tempo from every ground/burst attack in this zone
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    const reach = 260;
    const proj = (p.x-boss.x)*Math.cos(ang) + (p.y-boss.y)*Math.sin(ang);
    const perpDist = Math.hypot((p.x-boss.x)-Math.cos(ang)*proj, (p.y-boss.y)-Math.sin(ang)*proj);
    if(proj>0 && proj<reach && perpDist<40) hitPlayer(boss.dmg*0.9);
    const ex = boss.x+Math.cos(ang)*reach, ey = boss.y+Math.sin(ang)*reach;
    addParticles(boss.x,boss.y,boss.def.color,10,120,0.25);
    addParticles(ex,ey,boss.def.color,10,120,0.25);
    shake(5);
  } else if(type==='lavaSpurt'){
    const n=8;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*250, vy:Math.sin(ang)*250,
        dmg:boss.dmg*0.42, radius:7, owner:'enemy', color:boss.def.color, life:1.7, shape:'ember' });
    }
  } else if(type==='infernoRing'){
    const n=8;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      const hx = clamp(targetX+Math.cos(ang)*90, b.x+22,b.x+b.w-22);
      const hy = clamp(targetY+Math.sin(ang)*90, b.y+22,b.y+b.h-22);
      game.hazards.push({ x:hx, y:hy, r:26, type:'fire', telegraph:0.55, active:0.4, tick:0, dmg:boss.dmg*0.4 });
    }
    spawnToast('Un anillo de fuego se cierra a tu alrededor');
  } else if(type==='brimstoneRain'){
    const n=7;
    for(let i=0;i<n;i++){
      const hx = rand(b.x+30,b.x+b.w-30), hy = rand(b.y+30,b.y+b.h-30);
      game.hazards.push({ x:hx, y:hy, r:24, type:'fire', telegraph:0.5+Math.random()*1.0, active:0.4, tick:0, dmg:boss.dmg*0.32 });
    }
    spawnToast('Azufre ardiente cae por toda la arena');
  } else if(type==='demonRoar'){
    p.weakenTimer = Math.max(p.weakenTimer||0, 4);
    p.weakenFactor = 0.75;
    addParticles(p.x,p.y,boss.def.color,14,90,0.3);
    spawnToast('Un rugido demoníaco debilita tus golpes');
  } else if(type==='ashCloud'){
    p.chillTimer = Math.max(p.chillTimer||0, 3.5);
    p.chillFactor = 1.5;
    addParticles(p.x,p.y,boss.def.color,14,90,0.3);
    spawnToast('Una nube de ceniza entumece tus reflejos');
  } else if(type==='moltenTrap'){
    game.hazards.push({ x:targetX, y:targetY, r:44, type:'fire', telegraph:0.85, active:0.3, tick:0, dmg:boss.dmg*1.0 });
    spawnToast('Magma se oculta bajo la superficie');
  } else if(type==='cinderSwarm'){
    const n=10;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*260, vy:Math.sin(ang)*260,
        dmg:boss.dmg*0.32, radius:5, owner:'enemy', color:boss.def.color, life:1.5, shape:'ember' });
    }
  } else if(type==='flameSurge'){
    const n=8;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      game.hazards.push({ x:targetX+Math.cos(ang)*26, y:targetY+Math.sin(ang)*26, r:18, type:'fire',
        telegraph:0.4, active:0.5, tick:0, dmg:boss.dmg*0.42, expanding:true, expandRate:64 });
    }
    spawnToast('El fuego se hincha y avanza hacia afuera');
  } else if(type==='infernalBond'){
    boss.hp = Math.min(boss.maxHp, boss.hp + boss.maxHp*0.08);
    addParticles(boss.x,boss.y,boss.def.color,16,110,0.3);
    spawnToast('Un pacto infernal restaura sus fuerzas');
  } else if(type==='sulfurBreath'){
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    const n=3;
    for(let i=0;i<n;i++){
      const ang = ang0+(i-(n-1)/2)*0.24;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*140, vy:Math.sin(ang)*140,
        dmg:boss.dmg*0.7, radius:13, owner:'enemy', color:boss.def.color, life:2.6, shape:'ember' });
    }
    spawnToast('Un aliento de azufre se extiende lento');
  } else if(type==='pyreCollapse'){
    game.hazards.push({ x:targetX, y:targetY, r:120, type:'fire', telegraph:1.3, active:0.4, tick:0, dmg:boss.dmg*1.15 });
    spawnToast('Una pira colapsa sobre el lugar');
  } else if(type==='scorchedEarth'){
    const steps=8;
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    for(let i=0;i<steps;i++){
      const frac=i/(steps-1);
      const hx = clamp(boss.x+Math.cos(ang0)*frac*b.w*0.5, b.x+24,b.x+b.w-24);
      const hy = clamp(boss.y+Math.sin(ang0)*frac*b.h*0.5, b.y+24,b.y+b.h-24);
      game.hazards.push({ x:hx, y:hy, r:26, type:'fire', telegraph:0.25+frac*0.9, active:0.45, tick:0, dmg:boss.dmg*0.36 });
    }
    spawnToast('El suelo se quema en línea recta');
  } else if(type==='demonEye'){
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*102, vy:Math.sin(ang)*102,
      dmg:boss.dmg*0.75, radius:12, owner:'enemy', color:boss.def.color, life:4.5, homing:true, shape:'ember' });
    spawnToast('Un ojo demoníaco te vigila y te persigue');
  } else if(type==='infernalChains'){
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    [-0.3,0.3].forEach(off=>{
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang+off)*108, vy:Math.sin(ang+off)*108,
        dmg:boss.dmg*0.5, radius:9, owner:'enemy', color:boss.def.color, life:4.2, homing:true, shape:'ember' });
    });
    spawnToast('Dos cadenas ardientes te acechan');
  } else if(type==='brimstoneSpiral'){
    const n=7;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2.6;
      const rad=18+i*15;
      const hx = clamp(targetX+Math.cos(ang)*rad, b.x+22,b.x+b.w-22);
      const hy = clamp(targetY+Math.sin(ang)*rad, b.y+22,b.y+b.h-22);
      game.hazards.push({ x:hx, y:hy, r:20, type:'fire', telegraph:0.3+i*0.09, active:0.4, tick:0, dmg:boss.dmg*0.38 });
    }
    spawnToast('Fuego gira en espiral hacia afuera');
  } else if(type==='flameWreath'){
    for(let k=0;k<3;k++){
      game.hazards.push({ x:boss.x, y:boss.y, r:15+k*11, type:'fire', telegraph:0.33*(k+1), active:0.3, tick:0, dmg:boss.dmg*0.42 });
    }
    addParticles(boss.x,boss.y,boss.def.color,16,130,0.3);
    spawnToast('Una corona de fuego pulsa con fuerza creciente');
  } else if(type==='hellgate'){
    // teleports to where you were standing when the attack began, not your live position
    boss.x = clamp(targetX+rand(-40,40), b.x+boss.radius, b.x+b.w-boss.radius);
    boss.y = clamp(targetY+rand(-40,40), b.y+boss.radius, b.y+b.h-boss.radius);
    if(dist(boss.x,boss.y,p.x,p.y) < boss.radius+p.radius+20) hitPlayer(boss.dmg*0.8);
    spawnShockwave(boss.x,boss.y,boss.def.color,50,0.3);
    spawnToast('Un portal infernal lo trae junto a vos');
  } else if(type==='cinderVolley'){
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    const n=5;
    for(let i=0;i<n;i++){
      const ang = ang0+(i-(n-1)/2)*0.5;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*205, vy:Math.sin(ang)*205,
        dmg:boss.dmg*0.5, radius:7, owner:'enemy', color:boss.def.color, life:2.2, shape:'ember' });
    }
  } else if(type==='moltenWave'){
    const steps=7;
    for(let i=0;i<steps;i++){
      const frac=i/(steps-1);
      const hx = clamp(boss.x+(targetX-boss.x)*frac, b.x+24,b.x+b.w-24);
      const hy = clamp(boss.y+(targetY-boss.y)*frac, b.y+24,b.y+b.h-24);
      game.hazards.push({ x:hx, y:hy, r:24, type:'fire', telegraph:0.22+frac*0.85, active:0.4, tick:0, dmg:boss.dmg*0.38 });
    }
    spawnToast('Una ola de magma avanza hacia vos');
  } else if(type==='demonicHowl'){
    p.slowTimer = Math.max(p.slowTimer||0, 3);
    p.slowFactor = 0.6;
    addParticles(p.x,p.y,boss.def.color,14,90,0.3);
    spawnToast('Un aullido demoníaco entorpece tus pasos');
  } else if(type==='infernalCrown'){
    [0,1,2].forEach(ring=>{
      const n=7, speed=170+ring*60;
      for(let i=0;i<n;i++){
        const ang=(i/n)*Math.PI*2 + ring*0.25;
        spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*speed, vy:Math.sin(ang)*speed,
          dmg:boss.dmg*0.34, radius:6, owner:'enemy', color:boss.def.color, life:1.9, shape:'ember' });
      }
    });
    shake(4);
  } else if(type==='demonicBlast'){
    const r=155;
    if(dist(boss.x,boss.y,p.x,p.y)<r) hitPlayer(boss.dmg*1.0);
    addParticles(boss.x,boss.y,boss.def.color,22,200,0.4);
    spawnShockwave(boss.x,boss.y,boss.def.color,r,0.35);
    shake(7);
  } else if(type==='cinderBurst'){
    // a forward spread of embers, plus a couple of small fire pools dropped near the caster —
    // combines a projectile spread with a ground hazard in one move
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    const n=6;
    for(let i=0;i<n;i++){
      const ang = ang0 + (i-(n-1)/2)*0.16;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*230, vy:Math.sin(ang)*230,
        dmg:boss.dmg*0.5, radius:7, owner:'enemy', color:boss.def.color, life:1.6, shape:'ember' });
    }
    for(let k=0;k<2;k++){
      const hx = clamp(boss.x+rand(-90,90), b.x+24,b.x+b.w-24), hy = clamp(boss.y+rand(-90,90), b.y+24,b.y+b.h-24);
      game.hazards.push({ x:hx, y:hy, r:26, type:'fire', telegraph:0.5, active:1.0, tick:0, dmg:boss.dmg*0.35 });
    }
    spawnToast('Cenizas ardientes caen a su alrededor');
  } else if(type==='emberField'){
    // several points around you ignite one after another in a quick chain, instead of all at once
    const n=6;
    for(let i=0;i<n;i++){
      const ang = (i/n)*Math.PI*2 + rand(-0.2,0.2);
      const rad = rand(50,150);
      const hx = clamp(targetX+Math.cos(ang)*rad, b.x+24,b.x+b.w-24);
      const hy = clamp(targetY+Math.sin(ang)*rad, b.y+24,b.y+b.h-24);
      game.hazards.push({ x:hx, y:hy, r:30, type:'fire', telegraph:0.3+i*0.22, active:0.5, tick:0, dmg:boss.dmg*0.45 });
    }
    spawnToast('El fuego se enciende en cadena a tu alrededor');
  } else if(type==='moltenCore'){
    // three pulses expanding from the boss's own body in sequence, instead of one instant ring
    for(let k=0;k<3;k++){
      game.hazards.push({ x:boss.x, y:boss.y, r:16+k*10, type:'fire', telegraph:0.35*(k+1), active:0.35, tick:0, dmg:boss.dmg*0.5 });
    }
    addParticles(boss.x,boss.y,boss.def.color,18,150,0.35);
    spawnToast('Su núcleo pulsa con calor creciente');
  } else if(type==='cinderRain'){
    // many small, weak embers scattered randomly across the whole arena — a wide, sustained
    // nuisance rather than a punishing concentrated zone
    const n=8;
    for(let i=0;i<n;i++){
      const hx = rand(b.x+30,b.x+b.w-30), hy = rand(b.y+30,b.y+b.h-30);
      game.hazards.push({ x:hx, y:hy, r:22, type:'fire', telegraph:0.5+Math.random()*1.1, active:0.4, tick:0, dmg:boss.dmg*0.3 });
    }
    spawnToast('Ceniza ardiente llueve por toda la arena');
  } else if(type==='thornVolley'){
    // a tight forward spread of thorns — narrower and faster than boneVolley's full ring
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    const n=7;
    for(let i=0;i<n;i++){
      const ang = ang0 + (i-(n-1)/2)*0.15;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*250, vy:Math.sin(ang)*250,
        dmg:boss.dmg*0.5, radius:7, owner:'enemy', color:boss.def.color, life:1.8, shape:'shard' });
    }
    shake(4);
  } else if(type==='bloomTrap'){
    // one single large trap, not a cluster — a slower, heavier hit than swampGrasp's quick cluster
    game.hazards.push({ x:targetX, y:targetY, r:44, type:'light', telegraph:0.75, active:0.35, tick:0, dmg:boss.dmg*0.9 });
    spawnToast('Algo hermoso está por florecer bajo tus pies');
  } else if(type==='healingBloom'){
    // heals over the next few seconds instead of all at once — a lasting regen rather than a lump sum
    boss.regenTimer = 4;
    boss.regenPerSec = boss.maxHp*0.025;
    addParticles(boss.x,boss.y,boss.def.color,18,120,0.35);
    spawnToast('Florece con nueva energía');
  } else if(type==='lightTwins'){
    // two synced homing lights that fan out and slowly converge back on you, instead of one
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    [-0.35,0.35].forEach(off=>{
      spawnProjectile({ x:boss.x, y:boss.y, vx:Math.cos(ang+off)*100, vy:Math.sin(ang+off)*100,
        dmg:boss.dmg*0.55, radius:10, owner:'enemy', color:boss.def.color, life:4.5, homing:true, shape:'feather' });
    });
    spawnToast('Dos luces gemelas te acechan');
  } else if(type==='radiantPath'){
    // a winding, curved trail of light toward you, instead of a straight line or ring
    const steps=8;
    const ang = Math.atan2(targetY-boss.y, targetX-boss.x);
    const perp = ang+Math.PI/2;
    for(let i=0;i<steps;i++){
      const frac=i/(steps-1);
      const wob = Math.sin(frac*Math.PI*2.4)*46;
      const bx = boss.x+(targetX-boss.x)*frac + Math.cos(perp)*wob;
      const by = boss.y+(targetY-boss.y)*frac + Math.sin(perp)*wob;
      const hx = clamp(bx,b.x+24,b.x+b.w-24), hy=clamp(by,b.y+24,b.y+b.h-24);
      game.hazards.push({ x:hx, y:hy, r:24, type:'light', telegraph:0.3+frac*0.9, active:0.6, tick:0, dmg:boss.dmg*0.4 });
    }
    spawnToast('Un sendero serpenteante de luz se traza hacia vos');
  } else if(type==='petalStorm'){
    // full 360° ring of petals, denser and slower than thornVolley's tight forward spread
    const n=10;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*190, vy:Math.sin(ang)*190,
        dmg:boss.dmg*0.5, radius:8, owner:'enemy', color:boss.def.color, life:2.3, shape:'shard' });
    }
    addParticles(boss.x,boss.y,boss.def.color,16,150,0.35);
    shake(5);
  } else if(type==='vineWhip'){
    // a fast, narrow lash of thorned vines toward you — tighter and quicker than petalStorm's ring
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    const n=5;
    for(let i=0;i<n;i++){
      const ang = ang0 + (i-(n-1)/2)*0.09;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*310, vy:Math.sin(ang)*310,
        dmg:boss.dmg*0.55, radius:6, owner:'enemy', color:'#5ad98a', life:1.5, shape:'shard' });
    }
    shake(4);
  } else if(type==='prismShard'){
    // a tight, fast triple bolt that pierces further than most bursts — a precise strike, not a spread
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    for(let i=-1;i<=1;i++){
      const a = ang + i*0.05;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(a)*400, vy:Math.sin(a)*400,
        dmg:boss.dmg*0.7, radius:6, owner:'enemy', color:'#6a8dff', life:1.4, shape:'orb' });
    }
    addParticles(boss.x,boss.y,'#6a8dff',10,140,0.25);
  } else if(type==='nectarSwarm'){
    // many weak, slow orbs drifting outward in every direction — a lingering swarm rather than a
    // sharp burst, meant to crowd the arena instead of hit hard
    const n=13;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*105, vy:Math.sin(ang)*105,
        dmg:boss.dmg*0.3, radius:9, owner:'enemy', color:'#ffcb47', life:3.4, shape:'wisp' });
    }
    spawnToast('Un enjambre de néctar se dispersa por el aire');
  } else if(type==='gildedThorns'){
    // a wide golden ring, fewer and slower than petalStorm but each shard hits noticeably harder
    const n=8;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*230, vy:Math.sin(ang)*230,
        dmg:boss.dmg*0.65, radius:8, owner:'enemy', color:'#ffcb47', life:2.2, shape:'shard' });
    }
    addParticles(boss.x,boss.y,'#ffcb47',18,160,0.35);
    shake(6);
  } else if(type==='dewTrap'){
    // a loose cluster of small dew drops around your position, each individually weak but
    // covering a wider area than a single trap
    const n=3;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      game.hazards.push({ x:targetX+Math.cos(ang)*34, y:targetY+Math.sin(ang)*34, r:22,
        type:'light', telegraph:0.5, active:0.5, tick:0, dmg:boss.dmg*0.4 });
    }
    spawnToast('Gotas de rocío brillante se condensan en el aire');
  } else if(type==='crystalBloom'){
    // one heavy, slow-forming crystal — a single big hit rather than a scattered cluster
    game.hazards.push({ x:targetX, y:targetY, r:50, type:'light', telegraph:0.85, active:0.3, tick:0, dmg:boss.dmg*1.0 });
    addParticles(targetX,targetY,'#cfd6e8',14,120,0.3);
    spawnToast('Un cristal se forma bajo tus pies');
  } else if(type==='thornCage'){
    // a ring of spikes closes around your position, leaving the center as the only safe spot
    const n=6;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      game.hazards.push({ x:targetX+Math.cos(ang)*80, y:targetY+Math.sin(ang)*80, r:26,
        type:'spike', telegraph:0.55, active:0.8, tick:0, dmg:boss.dmg*0.5 });
    }
    spawnToast('Espinas se alzan formando una jaula a tu alrededor');
  } else if(type==='sunbeamLine'){
    // a beam of light sweeps across the arena from one edge to the other
    const vertical = Math.random()<0.5;
    const n=9;
    const reverse = Math.random()<0.5;
    for(let i=0;i<n;i++){
      const frac = i/(n-1);
      const delay = reverse ? (1-frac)*1.1 : frac*1.1;
      let hx,hy;
      if(vertical){ hx = b.x+30+frac*(b.w-60); hy = clamp(p.y+rand(-40,40), b.y+30,b.y+b.h-30); }
      else { hy = b.y+30+frac*(b.h-60); hx = clamp(p.x+rand(-40,40), b.x+30,b.x+b.w-30); }
      game.hazards.push({ x:hx, y:hy, r:34, type:'light', telegraph:0.35+delay, active:0.4, tick:0, dmg:boss.dmg*0.45 });
    }
    spawnToast('Un rayo de sol barre la arena');
  } else if(type==='bloomRing'){
    // two concentric rings of light close in around where you stood, one step behind gracefulVeil's three
    const cx = clamp(p.x, b.x+60, b.x+b.w-60), cy = clamp(p.y, b.y+60, b.y+b.h-60);
    [180,100].forEach((rad, idx)=>{
      const n=9;
      for(let i=0;i<n;i++){
        const ang=(i/n)*Math.PI*2;
        game.hazards.push({ x:cx+Math.cos(ang)*rad, y:cy+Math.sin(ang)*rad, r:24, type:'light',
          telegraph:0.5+idx*0.5, active:0.5, tick:0, dmg:boss.dmg*0.42 });
      }
    });
    spawnToast('Anillos de luz se cierran a tu alrededor');
  } else if(type==='sunfireCross'){
    // four arms of light extend from the boss's own position along the cardinal directions
    const arms=[[1,0],[-1,0],[0,1],[0,-1]];
    arms.forEach(([dx,dy])=>{
      for(let k=1;k<=3;k++){
        const hx = clamp(boss.x+dx*k*46, b.x+22, b.x+b.w-22);
        const hy = clamp(boss.y+dy*k*46, b.y+22, b.y+b.h-22);
        game.hazards.push({ x:hx, y:hy, r:24, type:'light', telegraph:0.45+k*0.12, active:0.4, tick:0, dmg:boss.dmg*0.45 });
      }
    });
    addParticles(boss.x,boss.y,'#ffcb47',16,140,0.3);
    spawnToast('Rayos de luz se extienden en cruz');
  } else if(type==='radianceField'){
    // several patches of light scattered near your position, like stormField's storm-clap equivalent
    for(let i=0;i<4;i++){
      const hx = clamp(targetX+rand(-140,140), b.x+24, b.x+b.w-24);
      const hy = clamp(targetY+rand(-140,140), b.y+24, b.y+b.h-24);
      game.hazards.push({ x:hx, y:hy, r:38, type:'light', telegraph:0.55, active:1.0, tick:0, dmg:boss.dmg*0.48 });
    }
    spawnToast('Parches de resplandor florecen a tu alrededor');
  } else if(type==='lightCascade'){
    // a wide staggered wall of light sweeps in from one side, like blizzardWall but in warm light
    const vertical = Math.random()<0.5;
    const n=10;
    const reverse = Math.random()<0.5;
    for(let i=0;i<n;i++){
      const frac = i/(n-1);
      const delay = reverse ? (1-frac)*1.3 : frac*1.3;
      let hx,hy;
      if(vertical){ hx = b.x+30+frac*(b.w-60); hy = clamp(p.y+rand(-40,40), b.y+30,b.y+b.h-30); }
      else { hy = b.y+30+frac*(b.h-60); hx = clamp(p.x+rand(-40,40), b.x+30,b.x+b.w-30); }
      game.hazards.push({ x:hx, y:hy, r:38, type:'light', telegraph:0.4+delay, active:0.5, tick:0, dmg:boss.dmg*0.5 });
    }
    spawnToast('Una cascada de luz avanza por la arena');
  } else if(type==='tangleRoots'){
    // roots erupt at scattered points around the arena while also slowing you directly — the
    // danger is everywhere at once, unlike sunbeamLine's single dodgeable path
    p.slowTimer = Math.max(p.slowTimer||0, 3);
    p.slowFactor = 0.65;
    for(let i=0;i<5;i++){
      const hx = rand(b.x+40,b.x+b.w-40), hy = rand(b.y+40,b.y+b.h-40);
      game.hazards.push({ x:hx, y:hy, r:26, type:'spike', telegraph:0.4+rand(0,1.2), active:0.55, tick:0, dmg:boss.dmg*0.4 });
    }
    addParticles(p.x,p.y,'#5ad98a',14,100,0.35);
    spawnToast('Raíces se enredan en tus piernas');
  } else if(type==='mirrorBloom'){
    // a self-centered pulse of light, smaller and faster than verdantSurge's slower bloom
    const r=130;
    if(dist(boss.x,boss.y,p.x,p.y)<r) hitPlayer(boss.dmg*0.8);
    addParticles(boss.x,boss.y,boss.def.color,20,190,0.4);
    spawnShockwave(boss.x,boss.y,boss.def.color,r,0.3);
    shake(6);
  } else if(type==='verdantSurge'){
    // a larger, slower self-centered eruption of vines — hits harder than mirrorBloom but is easier
    // to see coming and run from given its size
    const r=170;
    if(dist(boss.x,boss.y,p.x,p.y)<r) hitPlayer(boss.dmg*1.05);
    addParticles(boss.x,boss.y,'#5ad98a',28,240,0.5);
    spawnShockwave(boss.x,boss.y,'#5ad98a',r,0.4);
    shake(8);
  } else if(type==='glowWisp'){
    // a single slow homing light that patiently tracks you — longer life than sunfireLance,
    // built to be a persistent nuisance rather than a sudden punish
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*95, vy:Math.sin(ang)*95,
      dmg:boss.dmg*0.55, radius:10, owner:'enemy', color:boss.def.color, life:5, homing:true, shape:'wisp' });
    spawnToast('Una luz errante empieza a perseguirte');
  } else if(type==='sunfireLance'){
    // a fast, direct homing bolt with a short life — punishes hesitation more than glowWisp
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*220, vy:Math.sin(ang)*220,
      dmg:boss.dmg*0.85, radius:9, owner:'enemy', color:'#ffcb47', life:2.6, homing:true, shape:'orb' });
    addParticles(boss.x,boss.y,'#ffcb47',10,130,0.25);
  } else if(type==='lightPollen'){
    // weakens your damage output — the pollen dulls your strikes rather than slowing your body
    p.weakenTimer = Math.max(p.weakenTimer||0, 4);
    p.weakenFactor = 0.75;
    addParticles(p.x,p.y,'#ffd6f0',16,100,0.35);
    spawnToast('Polen cegador se posa sobre vos');
  } else if(type==='witheringPetals'){
    // slows your attack speed instead — a different flavor of debuff than lightPollen's damage cut
    p.chillTimer = Math.max(p.chillTimer||0, 3.5);
    p.chillFactor = 1.5;
    addParticles(p.x,p.y,'#a89a8c',14,90,0.3);
    spawnToast('Pétalos marchitos entorpecen tus movimientos');
  } else if(type==='petalVeil'){
    // a pure defensive buff: a shield of petals absorbs a portion of incoming damage briefly
    boss.shieldTimer = Math.max(boss.shieldTimer||0, 3.5);
    addParticles(boss.x,boss.y,boss.def.color,20,140,0.4);
    spawnToast('Un velo de pétalos la protege');
  } else if(type==='gardenGuardians'){
    // summons two wisps to fight alongside her — jardín's own summon move, distinct from cripta's
    for(let i=0;i<2;i++){
      const ang = Math.random()*Math.PI*2;
      spawnEnemyAt(boss.def.minion, boss.x+Math.cos(ang)*70, boss.y+Math.sin(ang)*70, true);
    }
    spawnToast('El jardín despierta a sus guardianes');
  } else if(type==='mirrorDecoy'){
    // a decoy fires from the point exactly opposite the boss through the arena's center, instead
    // of from the boss's own body — the danger comes from somewhere else in the room entirely
    const cx = b.x+b.w/2, cy = b.y+b.h/2;
    const mx = clamp(2*cx-boss.x, b.x+40, b.x+b.w-40), my = clamp(2*cy-boss.y, b.y+40, b.y+b.h-40);
    const ang = Math.atan2(p.y-my, p.x-mx);
    const n=5;
    for(let i=0;i<n;i++){
      const a = ang + (i-(n-1)/2)*0.18;
      spawnProjectile({ x:mx,y:my, vx:Math.cos(a)*220, vy:Math.sin(a)*220,
        dmg:boss.dmg*0.5, radius:7, owner:'enemy', color:boss.def.color, life:2, shape:'shard' });
    }
    addParticles(mx,my,boss.def.color,16,120,0.35);
    spawnToast('Un reflejo aparece del otro lado de la sala');
  } else if(type==='glassField'){
    // each shard cracks twice at the same spot, on a delay — a double-hit trap instead of a
    // single-resolution zone
    const n=5;
    for(let i=0;i<n;i++){
      const hx = rand(b.x+40,b.x+b.w-40), hy = rand(b.y+40,b.y+b.h-40);
      game.hazards.push({ x:hx, y:hy, r:26, type:'spike', telegraph:0.5, active:0.3, tick:0, dmg:boss.dmg*0.4 });
      game.hazards.push({ x:hx, y:hy, r:26, type:'spike', telegraph:1.1, active:0.3, tick:0, dmg:boss.dmg*0.4 });
    }
    spawnToast('El cristal se rompe dos veces en el mismo lugar');
  } else if(type==='illusionSwap'){
    // an instant position swap with you, rather than a pull or a dash — the boss simply trades
    // places with you
    const oldBossX=boss.x, oldBossY=boss.y;
    boss.x = clamp(p.x, b.x+boss.radius, b.x+b.w-boss.radius);
    boss.y = clamp(p.y, b.y+boss.radius, b.y+b.h-boss.radius);
    p.x = clamp(oldBossX, b.x+p.radius, b.x+b.w-p.radius);
    p.y = clamp(oldBossY, b.y+p.radius, b.y+b.h-p.radius);
    addParticles(boss.x,boss.y,boss.def.color,16,140,0.3);
    addParticles(p.x,p.y,boss.def.color,16,140,0.3);
    spawnShockwave(boss.x,boss.y,boss.def.color,60,0.3);
    spawnShockwave(p.x,p.y,boss.def.color,60,0.3);
    shake(6);
    spawnToast('Intercambia lugares con vos');
  } else if(type==='mirrorGaze'){
    // a pure control debuff: your own movement briefly turns against you — no damage, no hazard,
    // just your reflection working your limbs the wrong way
    p.invertTimer = Math.max(p.invertTimer||0, 2.5);
    addParticles(p.x,p.y,boss.def.color,14,90,0.3);
    spawnToast('Tu propio reflejo confunde tus movimientos');
  } else if(type==='fracturedBurst'){
    // a wide, sparse fan — fewer, further-spread shards than boneVolley's ring or thornVolley's
    // tight cone
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    const n=5;
    for(let i=0;i<n;i++){
      const ang = ang0 + (i-(n-1)/2)*0.5;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*200, vy:Math.sin(ang)*200,
        dmg:boss.dmg*0.5, radius:7, owner:'enemy', color:boss.def.color, life:2.2, shape:'shard' });
    }
  } else if(type==='shatterVolley'){
    // a full 360° ring of glass shards — wider and more even than fracturedBurst's sparse forward fan
    const n=9;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*200, vy:Math.sin(ang)*200,
        dmg:boss.dmg*0.5, radius:7, owner:'enemy', color:boss.def.color, life:2.2, shape:'shard' });
    }
    addParticles(boss.x,boss.y,boss.def.color,16,150,0.35);
    shake(5);
  } else if(type==='reflectedBarrage'){
    // fires simultaneously from the boss AND from her mirrored point across the arena's center —
    // two burst origins instead of mirrorDecoy's single decoy point
    const cx = b.x+b.w/2, cy = b.y+b.h/2;
    const mx = clamp(2*cx-boss.x, b.x+40, b.x+b.w-40), my = clamp(2*cy-boss.y, b.y+40, b.y+b.h-40);
    [{x:boss.x,y:boss.y},{x:mx,y:my}].forEach(o=>{
      const ang = Math.atan2(p.y-o.y, p.x-o.x);
      const n=4;
      for(let i=0;i<n;i++){
        const a = ang + (i-(n-1)/2)*0.2;
        spawnProjectile({ x:o.x,y:o.y, vx:Math.cos(a)*230, vy:Math.sin(a)*230,
          dmg:boss.dmg*0.45, radius:7, owner:'enemy', color:boss.def.color, life:2.2, shape:'shard' });
      }
    });
    addParticles(mx,my,boss.def.color,14,120,0.3);
    spawnToast('Su reflejo dispara desde el otro lado');
  } else if(type==='prismaticShards'){
    // a tight, fast forward cone of many thin shards — narrower and quicker than shatterVolley's ring
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    const n=6;
    for(let i=0;i<n;i++){
      const ang = ang0 + (i-(n-1)/2)*0.11;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*350, vy:Math.sin(ang)*350,
        dmg:boss.dmg*0.5, radius:5, owner:'enemy', color:'#e8e8f5', life:1.3, shape:'shard' });
    }
    shake(4);
  } else if(type==='mirageSwarm'){
    // many weak orbs spiral outward, like nectarSwarm but slightly rotated per shot to fake a
    // shimmering, drifting swarm of afterimages
    const n=14;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2 + i*0.05;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*115, vy:Math.sin(ang)*115,
        dmg:boss.dmg*0.3, radius:8, owner:'enemy', color:'#cfd6e8', life:3.0, shape:'wisp' });
    }
    spawnToast('Un enjambre de espejismos se dispersa');
  } else if(type==='silverStrike'){
    // two shots fired along the exact same line at different speeds, so the second arrives right
    // behind the first — a delayed echo of a single precise strike, not a spread
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*480, vy:Math.sin(ang)*480,
      dmg:boss.dmg*0.6, radius:6, owner:'enemy', color:'#e8e8f5', life:1.1, shape:'orb' });
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*300, vy:Math.sin(ang)*300,
      dmg:boss.dmg*0.5, radius:6, owner:'enemy', color:'#e8e8f5', life:1.4, shape:'orb' });
    addParticles(boss.x,boss.y,'#e8e8f5',10,120,0.25);
  } else if(type==='mirrorMaze'){
    // a 3x3 grid of glass panels around your position, all but one cell filled — a small, precise
    // maze rather than glassRain's arena-wide grid
    const cellSize=54;
    const safeCell = Math.floor(Math.random()*9);
    for(let row=0; row<3; row++){
      for(let col=0; col<3; col++){
        if(row*3+col===safeCell) continue;
        const hx = clamp(targetX+(col-1)*cellSize, b.x+24, b.x+b.w-24);
        const hy = clamp(targetY+(row-1)*cellSize, b.y+24, b.y+b.h-24);
        game.hazards.push({ x:hx, y:hy, r:24, type:'spike', telegraph:0.7, active:0.5, tick:0, dmg:boss.dmg*0.45 });
      }
    }
    spawnToast('Paneles de cristal se alzan a tu alrededor');
  } else if(type==='shatterZone'){
    // one single large trap that shatters under you, heavier than mirrorMaze's many small panels
    game.hazards.push({ x:targetX, y:targetY, r:48, type:'spike', telegraph:0.8, active:0.3, tick:0, dmg:boss.dmg*1.0 });
    addParticles(targetX,targetY,'#e8e8f5',16,130,0.3);
    spawnToast('El suelo de cristal está por quebrarse');
  } else if(type==='reflectivePool'){
    // a hazard appears both at your position and at its mirrored point across the arena's center,
    // so the reflection itself becomes a second threat
    const cx = b.x+b.w/2, cy = b.y+b.h/2;
    const mx = clamp(2*cx-targetX, b.x+30, b.x+b.w-30), my = clamp(2*cy-targetY, b.y+30, b.y+b.h-30);
    game.hazards.push({ x:targetX, y:targetY, r:36, type:'light', telegraph:0.6, active:0.5, tick:0, dmg:boss.dmg*0.55 });
    game.hazards.push({ x:mx, y:my, r:36, type:'light', telegraph:0.6, active:0.5, tick:0, dmg:boss.dmg*0.55 });
    spawnToast('Un estanque reflectante aparece en dos lugares a la vez');
  } else if(type==='glassSpikes'){
    // a ring of spikes closes around your position, similar in shape to thornCage but sharper
    // and faster to resolve
    const n=6;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      game.hazards.push({ x:targetX+Math.cos(ang)*76, y:targetY+Math.sin(ang)*76, r:24,
        type:'spike', telegraph:0.45, active:0.6, tick:0, dmg:boss.dmg*0.5 });
    }
    spawnToast('Esquirlas de cristal se alzan en anillo');
  } else if(type==='doubleVision'){
    // two overlapping clusters offset by a short random vector — everything looks doubled and
    // slightly misaligned, forcing you to account for both
    const offAng = Math.random()*Math.PI*2, offDist=60;
    const ox = Math.cos(offAng)*offDist, oy = Math.sin(offAng)*offDist;
    [[0,0],[ox,oy]].forEach(([dx,dy])=>{
      const n=3;
      for(let i=0;i<n;i++){
        const ang=(i/n)*Math.PI*2;
        game.hazards.push({ x:targetX+dx+Math.cos(ang)*30, y:targetY+dy+Math.sin(ang)*30, r:22,
          type:'spike', telegraph:0.55, active:0.4, tick:0, dmg:boss.dmg*0.4 });
      }
    });
    spawnToast('Tu visión se duplica de golpe');
  } else if(type==='distortionField'){
    // several scattered patches of warped space near your position, like radianceField's light
    // patches but rendered as jagged crystalline distortion
    for(let i=0;i<4;i++){
      const hx = clamp(targetX+rand(-150,150), b.x+24, b.x+b.w-24);
      const hy = clamp(targetY+rand(-150,150), b.y+24, b.y+b.h-24);
      game.hazards.push({ x:hx, y:hy, r:36, type:'spike', telegraph:0.55, active:0.9, tick:0, dmg:boss.dmg*0.45 });
    }
    spawnToast('El espacio se distorsiona a tu alrededor');
  } else if(type==='echoChamber'){
    // the same ring of danger pulses three times in place, like an echo repeating — you have to
    // stay clear of the same spot again and again instead of just once
    const cx = clamp(p.x, b.x+50, b.x+b.w-50), cy = clamp(p.y, b.y+50, b.y+b.h-50);
    for(let echo=0; echo<3; echo++){
      const n=7;
      for(let i=0;i<n;i++){
        const ang=(i/n)*Math.PI*2;
        game.hazards.push({ x:cx+Math.cos(ang)*100, y:cy+Math.sin(ang)*100, r:22, type:'light',
          telegraph:0.5+echo*0.55, active:0.35, tick:0, dmg:boss.dmg*0.4 });
      }
    }
    spawnToast('Un eco de peligro resuena tres veces');
  } else if(type==='hallOfMirrors'){
    // two walls sweep in from opposite edges of the arena at once, closing toward the middle —
    // unlike lightCascade's single-direction sweep, you're pinched from both sides
    const vertical = Math.random()<0.5;
    const n=7;
    for(let i=0;i<n;i++){
      const frac = i/(n-1);
      let hx1,hy1,hx2,hy2;
      if(vertical){
        hy1 = clamp(p.y+rand(-30,30), b.y+30,b.y+b.h-30); hy2=hy1;
        hx1 = b.x+30+frac*(b.w-60)*0.5;
        hx2 = b.x+b.w-30-frac*(b.w-60)*0.5;
      } else {
        hx1 = clamp(p.x+rand(-30,30), b.x+30,b.x+b.w-30); hx2=hx1;
        hy1 = b.y+30+frac*(b.h-60)*0.5;
        hy2 = b.y+b.h-30-frac*(b.h-60)*0.5;
      }
      game.hazards.push({ x:hx1, y:hy1, r:32, type:'spike', telegraph:0.4+frac*0.9, active:0.4, tick:0, dmg:boss.dmg*0.45 });
      game.hazards.push({ x:hx2, y:hy2, r:32, type:'spike', telegraph:0.4+frac*0.9, active:0.4, tick:0, dmg:boss.dmg*0.45 });
    }
    spawnToast('Dos muros de cristal se cierran desde los bordes');
  } else if(type==='mirrorShatter'){
    // a self-centered pulse that also flings a small ring of shards outward as it breaks —
    // combines a melee hit with a light burst, unlike reflectivePulse's pure pulse
    const r=120;
    if(dist(boss.x,boss.y,p.x,p.y)<r) hitPlayer(boss.dmg*0.75);
    const n=6;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*170, vy:Math.sin(ang)*170,
        dmg:boss.dmg*0.35, radius:6, owner:'enemy', color:boss.def.color, life:1.8, shape:'shard' });
    }
    addParticles(boss.x,boss.y,boss.def.color,20,180,0.4);
    spawnShockwave(boss.x,boss.y,boss.def.color,r,0.3);
    shake(6);
  } else if(type==='reflectivePulse'){
    // a larger, simpler self-centered wave of reflected light — no accompanying shards, just a
    // bigger single hit than mirrorShatter's combo
    const r=165;
    if(dist(boss.x,boss.y,p.x,p.y)<r) hitPlayer(boss.dmg*1.0);
    addParticles(boss.x,boss.y,'#e8e8f5',26,220,0.45);
    spawnShockwave(boss.x,boss.y,'#e8e8f5',r,0.4);
    shake(8);
  } else if(type==='phantomChaser'){
    // a single slow homing phantom with a long life — patient pursuit rather than a sudden strike
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*90, vy:Math.sin(ang)*90,
      dmg:boss.dmg*0.55, radius:10, owner:'enemy', color:'#cfd6e8', life:5, homing:true, shape:'wisp' });
    spawnToast('Un fantasma comienza a perseguirte');
  } else if(type==='reflectedLance'){
    // a fast, short-lived homing bolt — punishes hesitation, the opposite of phantomChaser's patience
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*230, vy:Math.sin(ang)*230,
      dmg:boss.dmg*0.85, radius:9, owner:'enemy', color:'#e8e8f5', life:2.4, homing:true, shape:'orb' });
    addParticles(boss.x,boss.y,'#e8e8f5',10,130,0.25);
  } else if(type==='hauntingReflection'){
    // a medium-speed homing shot that lingers a moderate amount of time — sits between
    // phantomChaser's patience and reflectedLance's urgency
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*150, vy:Math.sin(ang)*150,
      dmg:boss.dmg*0.65, radius:9, owner:'enemy', color:boss.def.color, life:3.6, homing:true, shape:'wisp' });
    spawnToast('Tu propio reflejo te persigue');
  } else if(type==='disorientingGaze'){
    // slows your attack speed — a different flavor of control than mirrorGaze's inverted movement
    p.chillTimer = Math.max(p.chillTimer||0, 3.5);
    p.chillFactor = 1.5;
    addParticles(p.x,p.y,boss.def.color,14,90,0.3);
    spawnToast('Su mirada te desorienta por completo');
  } else if(type==='shatteredFocus'){
    // weakens your damage output instead — a third distinct control effect for this zone
    p.weakenTimer = Math.max(p.weakenTimer||0, 4);
    p.weakenFactor = 0.75;
    addParticles(p.x,p.y,'#e8e8f5',16,100,0.35);
    spawnToast('Tu concentración se hace añicos');
  } else if(type==='silveredSkin'){
    // a pure self-buff: her surface hardens into silvered glass, absorbing a capped chunk of
    // damage before she starts losing HP again — same pattern as boneArmor, capped not additive
    boss.armorHp = Math.max(boss.armorHp||0, boss.maxHp*0.08);
    addParticles(boss.x,boss.y,'#e8e8f5',20,130,0.4);
    spawnToast('Su piel se cubre de plata pulida');
  } else if(type==='mirroredEcho'){
    // summons two spectral echoes of the zone's minion — this zone's own summon move, distinct
    // from cripta's and jardín's
    for(let i=0;i<2;i++){
      const ang = Math.random()*Math.PI*2;
      spawnEnemyAt(boss.def.minion, boss.x+Math.cos(ang)*70, boss.y+Math.sin(ang)*70, true);
    }
    spawnToast('Ecos espectrales emergen de los espejos');
  } else if(type==='boundStrike'){
    // fires from two points at once, offset to either side of the boss, as if two allies were
    // shooting in sync — a paired burst instead of a single-origin spread
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    const perp = ang+Math.PI/2;
    [70,-70].forEach(off=>{
      const sx = boss.x+Math.cos(perp)*off, sy = boss.y+Math.sin(perp)*off;
      const a = Math.atan2(p.y-sy, p.x-sx);
      spawnProjectile({ x:sx,y:sy, vx:Math.cos(a)*230, vy:Math.sin(a)*230,
        dmg:boss.dmg*0.55, radius:8, owner:'enemy', color:boss.def.color, life:2, shape:'orb' });
    });
    addParticles(boss.x,boss.y,boss.def.color,10,100,0.3);
    spawnToast('Dos proyectiles convergen desde ángulos distintos');
  } else if(type==='bondPulse'){
    // two simultaneous pulses at two separate points near the boss, instead of one ring or a
    // sequence of rings
    [-70,70].forEach(off=>{
      game.hazards.push({ x:boss.x+off, y:boss.y, r:55, type:'light', telegraph:0.55, active:0.4, tick:0, dmg:boss.dmg*0.5 });
    });
    spawnToast('Dos pulsos laten al mismo tiempo');
  } else if(type==='twinStrike'){
    // two instant line-checks at once from slightly different angles — a doubled version of
    // flameWhip's single instant lash
    const angBase = Math.atan2(p.y-boss.y, p.x-boss.x);
    [angBase-0.25, angBase+0.25].forEach(ang=>{
      const reach=230;
      const proj = (p.x-boss.x)*Math.cos(ang) + (p.y-boss.y)*Math.sin(ang);
      const perpDist = Math.hypot((p.x-boss.x)-Math.cos(ang)*proj, (p.y-boss.y)-Math.sin(ang)*proj);
      if(proj>0 && proj<reach && perpDist<36) hitPlayer(boss.dmg*0.6);
      const ex=boss.x+Math.cos(ang)*reach, ey=boss.y+Math.sin(ang)*reach;
      addParticles(ex,ey,boss.def.color,8,100,0.2);
    });
    shake(5);
    spawnToast('Un golpe doble te alcanza desde dos ángulos');
  } else if(type==='bondedShield'){
    // a solo defensive buff — shields itself without needing an actual twin present
    boss.shieldTimer = Math.max(boss.shieldTimer||0, 3.5);
    addParticles(boss.x,boss.y,boss.def.color,16,120,0.3);
    spawnToast('Se protege con un vínculo espiritual');
  } else if(type==='spiritLink'){
    // a tether of hazard points strung between two random locations, unrelated to the boss's or
    // your own position — a danger line drawn across the room rather than radiating from a point
    const p1 = { x: rand(b.x+60,b.x+b.w-60), y: rand(b.y+60,b.y+b.h-60) };
    const p2 = { x: rand(b.x+60,b.x+b.w-60), y: rand(b.y+60,b.y+b.h-60) };
    const steps=6;
    for(let i=0;i<steps;i++){
      const frac=i/(steps-1);
      const hx = p1.x+(p2.x-p1.x)*frac, hy = p1.y+(p2.y-p1.y)*frac;
      game.hazards.push({ x:hx, y:hy, r:22, type:'light', telegraph:0.5, active:0.5, tick:0, dmg:boss.dmg*0.35 });
    }
    spawnToast('Un vínculo de energía cruza la arena');
  } else if(type==='twinVolley'){
    // two full rings fired at once from two offset points — a doubled version of soulShards'
    // single-origin ring
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    const perp = ang+Math.PI/2;
    [70,-70].forEach(off=>{
      const sx = boss.x+Math.cos(perp)*off, sy = boss.y+Math.sin(perp)*off;
      const n=6;
      for(let i=0;i<n;i++){
        const a=(i/n)*Math.PI*2;
        spawnProjectile({ x:sx,y:sy, vx:Math.cos(a)*180, vy:Math.sin(a)*180,
          dmg:boss.dmg*0.4, radius:7, owner:'enemy', color:boss.def.color, life:2.1, shape:'shard' });
      }
    });
    addParticles(boss.x,boss.y,boss.def.color,14,120,0.3);
    shake(5);
  } else if(type==='soulShards'){
    // a single full ring from the boss's own position — the solo counterpart to twinVolley's
    // doubled version
    const n=9;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*190, vy:Math.sin(ang)*190,
        dmg:boss.dmg*0.5, radius:7, owner:'enemy', color:'#ffb0d9', life:2.2, shape:'shard' });
    }
    addParticles(boss.x,boss.y,'#ffb0d9',14,140,0.3);
  } else if(type==='pairedBolts'){
    // two rapid-fire shots from the same origin, a beat apart in speed rather than offset in
    // position — a doubled strike instead of a doubled origin
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*260, vy:Math.sin(ang)*260,
      dmg:boss.dmg*0.55, radius:7, owner:'enemy', color:boss.def.color, life:1.6, shape:'orb' });
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang+0.15)*260, vy:Math.sin(ang+0.15)*260,
      dmg:boss.dmg*0.55, radius:7, owner:'enemy', color:boss.def.color, life:1.6, shape:'orb' });
    addParticles(boss.x,boss.y,boss.def.color,8,100,0.2);
  } else if(type==='spiritBurst'){
    // many weak spirit orbs drifting outward in every direction, meant to crowd the arena rather
    // than hit hard — this zone's version of a lingering swarm
    const n=13;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*100, vy:Math.sin(ang)*100,
        dmg:boss.dmg*0.3, radius:9, owner:'enemy', color:'#ffb0d9', life:3.2, shape:'wisp' });
    }
    spawnToast('Espíritus se dispersan por el santuario');
  } else if(type==='boundArrows'){
    // a fast, narrow forward cone — tighter and quicker than soulShards' full ring
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    const n=5;
    for(let i=0;i<n;i++){
      const ang = ang0 + (i-(n-1)/2)*0.09;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*330, vy:Math.sin(ang)*330,
        dmg:boss.dmg*0.55, radius:6, owner:'enemy', color:boss.def.color, life:1.4, shape:'shard' });
    }
    shake(4);
  } else if(type==='soulTether'){
    // a tether strung between the boss and your frozen position at the moment of the attack —
    // anchored to both of you, unlike spiritLink's two random points
    const steps=6;
    for(let i=0;i<steps;i++){
      const frac=i/(steps-1);
      const hx = boss.x+(targetX-boss.x)*frac, hy = boss.y+(targetY-boss.y)*frac;
      game.hazards.push({ x:hx, y:hy, r:22, type:'light', telegraph:0.35+frac*0.5, active:0.5, tick:0, dmg:boss.dmg*0.4 });
    }
    spawnToast('Un lazo espiritual se tiende entre ustedes');
  } else if(type==='kinshipRing'){
    // a simple ring of hazards closing around your position
    const n=6;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      game.hazards.push({ x:targetX+Math.cos(ang)*78, y:targetY+Math.sin(ang)*78, r:24,
        type:'light', telegraph:0.5, active:0.6, tick:0, dmg:boss.dmg*0.48 });
    }
    spawnToast('Un anillo de vínculo se cierra a tu alrededor');
  } else if(type==='dualBloom'){
    // two soft light blooms at random points in the arena, unlike bondPulse's pair fixed just
    // off the boss's own position
    for(let i=0;i<2;i++){
      const hx = rand(b.x+70,b.x+b.w-70), hy = rand(b.y+70,b.y+b.h-70);
      game.hazards.push({ x:hx, y:hy, r:50, type:'light', telegraph:0.6, active:0.4, tick:0, dmg:boss.dmg*0.55 });
    }
    spawnToast('Dos florecimientos de luz brotan en el santuario');
  } else if(type==='sharedPain'){
    // a hazard appears both at your position and at the boss's own position at once — the pain
    // is shared between you, quite literally
    game.hazards.push({ x:targetX, y:targetY, r:38, type:'light', telegraph:0.55, active:0.5, tick:0, dmg:boss.dmg*0.5 });
    game.hazards.push({ x:boss.x, y:boss.y, r:38, type:'light', telegraph:0.55, active:0.5, tick:0, dmg:boss.dmg*0.5 });
    spawnToast('El dolor se comparte entre ambas');
  } else if(type==='weaveTrap'){
    // a zigzagging line of small hazards woven across the arena, alternating side to side
    const n=8;
    const startX = rand(b.x+60,b.x+b.w-60);
    for(let i=0;i<n;i++){
      const frac=i/(n-1);
      const hy = b.y+40+frac*(b.h-80);
      const hx = clamp(startX + Math.sin(frac*Math.PI*3)*90, b.x+30, b.x+b.w-30);
      game.hazards.push({ x:hx, y:hy, r:22, type:'light', telegraph:0.35+frac*0.9, active:0.4, tick:0, dmg:boss.dmg*0.4 });
    }
    spawnToast('Un patrón entrelazado se teje por la arena');
  } else if(type==='pactCircle'){
    // one large circle of hazards around the center of the arena, forcing you to choose between
    // the middle or the edges instead of chasing your own position
    const cx = b.x+b.w/2, cy = b.y+b.h/2;
    const n=12;
    for(let i=0;i<n;i++){
      const ang=(i/n)*Math.PI*2;
      const rad = Math.min(b.w,b.h)*0.32;
      game.hazards.push({ x:cx+Math.cos(ang)*rad, y:cy+Math.sin(ang)*rad, r:26, type:'light',
        telegraph:0.65, active:0.6, tick:0, dmg:boss.dmg*0.45 });
    }
    spawnToast('Un pacto circular se traza en el santuario');
  } else if(type==='tetherLine'){
    // a straight sweeping line from the boss toward a fixed point on the wall, sequential and
    // dodgeable along its length — unlike soulTether's anchor to your own position
    const wallAng = Math.random()*Math.PI*2;
    const wx = clamp(boss.x+Math.cos(wallAng)*400, b.x+20,b.x+b.w-20);
    const wy = clamp(boss.y+Math.sin(wallAng)*400, b.y+20,b.y+b.h-20);
    const steps=8;
    for(let i=0;i<steps;i++){
      const frac=i/(steps-1);
      const hx = boss.x+(wx-boss.x)*frac, hy = boss.y+(wy-boss.y)*frac;
      game.hazards.push({ x:hx, y:hy, r:26, type:'light', telegraph:0.3+frac*0.8, active:0.4, tick:0, dmg:boss.dmg*0.42 });
    }
    spawnToast('Una línea de energía se extiende hacia el muro');
  } else if(type==='soulPulse'){
    // a self-centered pulse of spiritual energy, smaller and faster than boundSurge's slower one
    const r=125;
    if(dist(boss.x,boss.y,p.x,p.y)<r) hitPlayer(boss.dmg*0.8);
    addParticles(boss.x,boss.y,boss.def.color,20,180,0.4);
    spawnShockwave(boss.x,boss.y,boss.def.color,r,0.3);
    shake(6);
  } else if(type==='boundSurge'){
    // a larger, slower self-centered surge — hits harder than soulPulse but gives more time to react
    const r=165;
    if(dist(boss.x,boss.y,p.x,p.y)<r) hitPlayer(boss.dmg*1.05);
    addParticles(boss.x,boss.y,'#ffb0d9',26,220,0.45);
    spawnShockwave(boss.x,boss.y,'#ffb0d9',r,0.4);
    shake(8);
  } else if(type==='spiritChaser'){
    // a single slow homing spirit with a long life — patient pursuit
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*90, vy:Math.sin(ang)*90,
      dmg:boss.dmg*0.55, radius:10, owner:'enemy', color:boss.def.color, life:5, homing:true, shape:'wisp' });
    spawnToast('Un espíritu comienza a perseguirte');
  } else if(type==='soulLance'){
    // a fast, short-lived homing bolt — punishes hesitation more than spiritChaser's patience
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*225, vy:Math.sin(ang)*225,
      dmg:boss.dmg*0.85, radius:9, owner:'enemy', color:'#ffb0d9', life:2.5, homing:true, shape:'orb' });
    addParticles(boss.x,boss.y,'#ffb0d9',10,130,0.25);
  } else if(type==='kinseeker'){
    // a medium-speed homing shot with a moderate life — sits between spiritChaser and soulLance
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*150, vy:Math.sin(ang)*150,
      dmg:boss.dmg*0.65, radius:9, owner:'enemy', color:boss.def.color, life:3.6, homing:true, shape:'wisp' });
    spawnToast('Un lazo espiritual te busca');
  } else if(type==='sharedWound'){
    // weakens your damage output — the shared bond dulls your own strikes
    p.weakenTimer = Math.max(p.weakenTimer||0, 4);
    p.weakenFactor = 0.75;
    addParticles(p.x,p.y,'#ffb0d9',16,100,0.35);
    spawnToast('Una herida compartida debilita tus golpes');
  } else if(type==='soulSap'){
    // slows your attack speed instead — a different flavor of debuff than sharedWound's damage cut
    p.chillTimer = Math.max(p.chillTimer||0, 3.5);
    p.chillFactor = 1.5;
    addParticles(p.x,p.y,'#a89a8c',14,90,0.3);
    spawnToast('Tu energía es drenada lentamente');
  } else if(type==='boundCurse'){
    // a pure control debuff: your movement briefly turns against you, as if bound to a will
    // that isn't your own
    p.invertTimer = Math.max(p.invertTimer||0, 2.5);
    addParticles(p.x,p.y,boss.def.color,14,90,0.3);
    spawnToast('Una maldición vincula tus movimientos');
  } else if(type==='sharedBlessing'){
    // heals over the next few seconds — this zone's own regen buff, distinct from bondedShield's
    // damage-reduction shield
    boss.regenTimer = 4;
    boss.regenPerSec = boss.maxHp*0.025;
    addParticles(boss.x,boss.y,boss.def.color,18,120,0.35);
    spawnToast('Una bendición compartida la restaura');
  } else if(type==='twinSpirits'){
    // summons two wisps to fight alongside her — this zone's own summon move
    for(let i=0;i<2;i++){
      const ang = Math.random()*Math.PI*2;
      spawnEnemyAt(boss.def.minion, boss.x+Math.cos(ang)*70, boss.y+Math.sin(ang)*70, true);
    }
    spawnToast('Espíritus gemelos acuden a su llamado');
  } else if(type==='iceLance'){
    // a single slow homing shard that also chills on contact — a persistent chaser instead of a
    // burst or a zone
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*95, vy:Math.sin(ang)*95,
      dmg:boss.dmg*0.7, radius:12, owner:'enemy', color:boss.def.color, life:5, homing:true, shape:'shard',
      slow:{factor:0.6,dur:1} });
    spawnToast('Una lanza de hielo te persigue lentamente');
  } else if(type==='crystalPrison'){
    // one heavy, slow-forming trap with a chilling aura as it crystallizes
    game.hazards.push({ x:targetX, y:targetY, r:50, type:'ice', telegraph:0.7, active:0.35, tick:0, dmg:boss.dmg*0.7 });
    p.slowTimer = Math.max(p.slowTimer||0, 1.6);
    spawnToast('El hielo intenta encerrarte');
  } else if(type==='avalanche'){
    // a few huge, slow, long-telegraphed blocks — the opposite tempo of frozenGround's many
    // small random eruptions
    const n=4;
    for(let i=0;i<n;i++){
      const hx = rand(b.x+50,b.x+b.w-50), hy = rand(b.y+50,b.y+b.h-50);
      game.hazards.push({ x:hx, y:hy, r:70, type:'ice', telegraph:1.3, active:0.5, tick:0, dmg:boss.dmg*0.75 });
    }
    spawnToast('Bloques de hielo caen desde arriba');
    shake(5);
  } else if(type==='frostBreath'){
    // few, large, slow-moving shards instead of many fast small ones
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    const n=3;
    for(let i=0;i<n;i++){
      const ang = ang0 + (i-(n-1)/2)*0.22;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*130, vy:Math.sin(ang)*130,
        dmg:boss.dmg*0.7, radius:13, owner:'enemy', color:boss.def.color, life:2.6, shape:'orb', slow:{factor:0.6,dur:1} });
    }
    spawnToast('Un aliento helado se extiende lento');
  } else if(type==='numbingChill'){
    // weakens your damage output for a while — a debuff on your offense, not your movement
    p.weakenTimer = Math.max(p.weakenTimer||0, 4);
    p.weakenFactor = 0.75;
    addParticles(p.x,p.y,boss.def.color,14,90,0.3);
    spawnToast('Un frío entumecedor debilita tus golpes');
  } else if(type==='thunderStrike'){
    // almost no warning at all before a single heavy strike — pure reaction test
    game.hazards.push({ x:targetX, y:targetY, r:34, type:'storm', telegraph:0.28, active:0.3, tick:0, dmg:boss.dmg*1.1 });
    spawnToast('Un rayo cae casi sin aviso');
  } else if(type==='stormVortex'){
    // hazard points trace outward along a spiral instead of a static ring or scattered cluster
    const n=8;
    for(let i=0;i<n;i++){
      const ang = (i/n)*Math.PI*3;
      const rad = 20+i*16;
      const hx = clamp(targetX+Math.cos(ang)*rad, b.x+24,b.x+b.w-24);
      const hy = clamp(targetY+Math.sin(ang)*rad, b.y+24,b.y+b.h-24);
      game.hazards.push({ x:hx, y:hy, r:22, type:'storm', telegraph:0.35+i*0.08, active:0.4, tick:0, dmg:boss.dmg*0.4 });
    }
    spawnToast('Un vórtice de rayos gira hacia afuera');
  } else if(type==='staticField'){
    // slows your attack speed instead of your movement or damage — a debuff on your tempo
    p.chillTimer = Math.max(p.chillTimer||0, 3.5);
    p.chillFactor = 1.5;
    addParticles(p.x,p.y,boss.def.color,14,90,0.3);
    spawnToast('La estática entumece tus reflejos');
  } else if(type==='skySiege'){
    // many strikes with one shared telegraph, landing all at once — no staggering, so you must
    // find the gap immediately rather than reacting to each one in turn
    const n=7;
    for(let i=0;i<n;i++){
      const hx = rand(b.x+30,b.x+b.w-30), hy = rand(b.y+30,b.y+b.h-30);
      game.hazards.push({ x:hx, y:hy, r:32, type:'storm', telegraph:1.0, active:0.4, tick:0, dmg:boss.dmg*0.45 });
    }
    spawnToast('El cielo entero se abre de una sola vez');
    shake(4);
  } else if(type==='boltRunner'){
    // a single fast homing bolt — quicker and more aggressive than iceLance's slow chaser
    const ang = Math.atan2(p.y-boss.y, p.x-boss.x);
    spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*260, vy:Math.sin(ang)*260,
      dmg:boss.dmg*0.6, radius:9, owner:'enemy', color:boss.def.color, life:2.6, homing:true, shape:'orb' });
    spawnToast('Un rayo veloz te persigue');
  } else if(type==='voidTendrils'){
    // a six-armed burst radiating from where you stood, instead of magmaCross's four-armed
    // pattern rooted on the boss itself
    const arms=6;
    for(let a=0;a<arms;a++){
      const ang=(a/arms)*Math.PI*2;
      for(let k=1;k<=2;k++){
        const hx = clamp(targetX+Math.cos(ang)*k*46, b.x+22,b.x+b.w-22);
        const hy = clamp(targetY+Math.sin(ang)*k*46, b.y+22,b.y+b.h-22);
        game.hazards.push({ x:hx, y:hy, r:24, type:'void', telegraph:0.6, active:0.4, tick:0, dmg:boss.dmg*0.4 });
      }
    }
    spawnToast('Tentáculos de vacío brotan bajo tus pies');
  } else if(type==='darkPulse'){
    // few, large, slow orbs — a heavier, sparser burst than the fast dense sprays elsewhere
    const n=4;
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    for(let i=0;i<n;i++){
      const ang = ang0 + (i-(n-1)/2)*0.3;
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*110, vy:Math.sin(ang)*110,
        dmg:boss.dmg*0.75, radius:14, owner:'enemy', color:boss.def.color, life:3.2, shape:'wisp' });
    }
    spawnToast('Orbes de oscuridad avanzan lentos');
  } else if(type==='starlightDrain'){
    // drains a piece of your max HP into the boss's own — a resource-drain debuff, not a hazard
    // or a projectile
    const drain = p.maxHp*0.07;
    p.maxHp = Math.max(20, p.maxHp-drain);
    p.hp = Math.min(p.hp, p.maxHp);
    boss.hp = Math.min(boss.maxHp, boss.hp+drain*0.6);
    addParticles(p.x,p.y,boss.def.color,16,120,0.35);
    spawnToast('Algo drena tu propia esencia vital');
  } else if(type==='umbraStep'){
    // teleports to where you stood when the attack began — dodgeable by moving during the wind-up,
    // instead of tracking your live position and guaranteeing a hit
    boss.x = clamp(targetX+rand(-40,40), b.x+boss.radius, b.x+b.w-boss.radius);
    boss.y = clamp(targetY+rand(-40,40), b.y+boss.radius, b.y+b.h-boss.radius);
    if(dist(boss.x,boss.y,p.x,p.y) < boss.radius+p.radius+20) hitPlayer(boss.dmg*0.85);
    addParticles(boss.x,boss.y,boss.def.color,18,150,0.3);
    spawnShockwave(boss.x,boss.y,boss.def.color,50,0.3);
    spawnToast('Aparece de golpe a tu lado');
  } else if(type==='collapsingStar'){
    // one enormous single-point explosion centered on where you stood — the biggest single hit
    // in the void zone's kit
    game.hazards.push({ x:targetX, y:targetY, r:110, type:'void', telegraph:1.3, active:0.4, tick:0, dmg:boss.dmg*1.2 });
    spawnToast('Una estrella colapsa donde estabas parado');
  } else if(type==='royalDecree'){
    // silences your Q and E abilities for a few seconds — the only ability-lock debuff in the game
    p.qLockTimer = Math.max(p.qLockTimer||0, 2.5);
    p.eLockTimer = Math.max(p.eLockTimer||0, 2.5);
    addParticles(p.x,p.y,boss.def.color,18,120,0.35);
    spawnToast('Un decreto silencia tus habilidades');
  } else if(type==='throneSlam'){
    // a heavier double-ringed version of a self slam, with two shockwaves instead of one
    const r=180;
    if(dist(boss.x,boss.y,p.x,p.y)<r) hitPlayer(boss.dmg*1.1);
    addParticles(boss.x,boss.y,boss.def.color,30,260,0.5);
    spawnShockwave(boss.x,boss.y,boss.def.color,r,0.4);
    spawnShockwave(boss.x,boss.y,boss.def.color,r*0.6,0.3);
    shake(10);
    spawnToast('El trono golpea con todo su peso');
  } else if(type==='crownfire'){
    // three full rings fired in sequence, each faster than the last
    [0,1,2].forEach(ring=>{
      const n=8, speed=180+ring*70;
      for(let i=0;i<n;i++){
        const ang=(i/n)*Math.PI*2 + ring*0.2;
        spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang)*speed, vy:Math.sin(ang)*speed,
          dmg:boss.dmg*0.4, radius:6, owner:'enemy', color:boss.def.color, life:2, shape:'ember' });
      }
    });
    shake(5);
    spawnToast('Anillos de fuego se expanden en cadena');
  } else if(type==='finalJudgment'){
    // the dead center of the arena becomes the danger zone — the mirror opposite of
    // abyssalCollapse, which makes the edges unsafe instead
    game.hazards.push({ x:b.x+b.w/2, y:b.y+b.h/2, r:170, type:'void', telegraph:1.4, active:0.5, tick:0, dmg:boss.dmg*1.1 });
    spawnToast('El centro de la sala se vuelve letal');
  } else if(type==='soulBarrage'){
    // three homing projectiles fired at once in a fan, each chasing independently
    const ang0 = Math.atan2(p.y-boss.y, p.x-boss.x);
    [-0.4,0,0.4].forEach(off=>{
      spawnProjectile({ x:boss.x,y:boss.y, vx:Math.cos(ang0+off)*130, vy:Math.sin(ang0+off)*130,
        dmg:boss.dmg*0.5, radius:9, owner:'enemy', color:boss.def.color, life:3.2, homing:true, shape:'wisp' });
    });
    spawnToast('Tres almas te persiguen desde ángulos distintos');
  } else if(type==='fireWave'){
    game.hazards.push({ x:boss.x, y:boss.y, r:24, type:'fire', telegraph:0, active:2.4, tick:0, dmg:boss.dmg*0.5, expanding:true, expandRate:145 });
    spawnToast('Una oleada de fuego se expande');
    shake(4);
  } else if(type==='twinSwap'){
    if(boss.twin && boss.twin.alive){
      const tx=boss.x, ty=boss.y;
      const twx=boss.twin.x, twy=boss.twin.y;
      spawnShockwave(tx,ty,'#ff9ad1',boss.radius*1.3,0.32);
      spawnShockwave(twx,twy,'#ff9ad1',boss.radius*1.1,0.32);
      addParticles(boss.x,boss.y,'#ff9ad1',16,180,0.35);
      addParticles(boss.twin.x,boss.twin.y,'#ff9ad1',16,180,0.35);
      // a brief streak connecting the two swapped points, tracing the swap itself
      for(let k=1;k<6;k++){
        const fr=k/6;
        game.particles.push({ x:tx+(twx-tx)*fr, y:ty+(twy-ty)*fr, vx:0, vy:0, life:0.22, maxLife:0.22, color:'#ff9ad1', r:2.4, type:'circle' });
      }
      boss.x = boss.twin.x; boss.y = boss.twin.y;
      boss.twin.x = tx; boss.twin.y = ty;
      if(dist(boss.x,boss.y,p.x,p.y)<boss.radius+p.radius+40) hitPlayer(boss.dmg*0.6);
      if(dist(boss.twin.x,boss.twin.y,p.x,p.y)<boss.radius+p.radius+40) hitPlayer(boss.dmg*0.6);
    } else {
      const ang = Math.atan2(p.y-boss.y,p.x-boss.x);
      boss.x = clamp(boss.x+Math.cos(ang)*80, b.x+boss.radius, b.x+b.w-boss.radius);
      boss.y = clamp(boss.y+Math.sin(ang)*80, b.y+boss.radius, b.y+b.h-boss.radius);
      if(dist(boss.x,boss.y,p.x,p.y)<boss.radius+p.radius+30) hitPlayer(boss.dmg*0.6);
    }
    shake(5);
  }
}

/* ---------- projectiles ---------- */
function spawnProjectile(pr){
  if(game._guardianAttack && pr.owner==='enemy'){
    // guardians' projectiles fly noticeably faster than the same attack from a regular floor
    // boss — less time between "I see it" and "it's here", which is what actually makes an
    // attack harder to dodge, rather than just hitting harder
    const speed = Math.hypot(pr.vx,pr.vy);
    if(speed>0){
      const boost = 1.28;
      pr = { ...pr, vx: pr.vx*boost, vy: pr.vy*boost };
    }
  }
  game.projectiles.push(pr);
  if(game._echoProjectiles && pr.owner==='enemy'){
    // boss attacks fire an extra echo alongside each projectile, roughly doubling their bullet
    // count without needing to hand-edit every single attack implementation
    const speed = Math.hypot(pr.vx,pr.vy)||1;
    const ang = Math.atan2(pr.vy,pr.vx) + (Math.random()<0.5?1:-1)*0.12;
    game.projectiles.push({ ...pr, vx:Math.cos(ang)*speed, vy:Math.sin(ang)*speed });
  }
}
function updateProjectiles(dt){
  const b = arenaBounds();
  const p = game.player;
  for(let i=game.projectiles.length-1;i>=0;i--){
    const pr = game.projectiles[i];
    if(pr.homing){
      const targAng = Math.atan2(p.y-pr.y, p.x-pr.x);
      const curAng = Math.atan2(pr.vy, pr.vx);
      let diff = targAng-curAng;
      while(diff>Math.PI) diff-=Math.PI*2;
      while(diff<-Math.PI) diff+=Math.PI*2;
      const turn = clamp(diff, -2.2*dt, 2.2*dt);
      const spd = Math.hypot(pr.vx,pr.vy);
      const newAng = curAng+turn;
      pr.vx = Math.cos(newAng)*spd; pr.vy = Math.sin(newAng)*spd;
    }
    pr.x += pr.vx*dt; pr.y += pr.vy*dt; pr.life -= dt;
    if(Math.random()<0.55){
      game.particles.push({ x:pr.x, y:pr.y, vx:-pr.vx*0.04, vy:-pr.vy*0.04, life:0.16, maxLife:0.16,
        color:pr.color, r:Math.max(1.5,pr.radius*0.4), type:'circle' });
    }
    let remove=false;
    if(pr.x<b.x||pr.x>b.x+b.w||pr.y<b.y||pr.y>b.y+b.h||pr.life<=0) remove=true;

    if(!remove && pr.owner==='player'){
      const targets = [...game.enemies, ...bossTargets()];
      for(const t of targets){
        if(dist(pr.x,pr.y,t.x,t.y) < pr.radius+t.radius){
          if(t.def && t.def.erratic && Math.random()<t.def.dodgeChance){
            addParticles(t.x,t.y,'#c9b8ff',5,90,0.18);
            continue; // phased through, no hit
          }
          const dmgObj = pr.dmg.value!==undefined ? pr.dmg : computeDamage(pr.dmg);
          dealDamageToTarget(t, dmgObj.value!==undefined?dmgObj:{value:dmgObj,crit:false}, 'proj');
          if(pr.explode){ explodeAt(pr.x,pr.y,pr.explodeRadius, computeDamage(pr.dmg.value?pr.dmg.value*0.6:20)); }
          remove=true; break;
        }
      }
    } else if(!remove && pr.owner==='enemy'){
      if(p.invuln<=0 && dist(pr.x,pr.y,p.x,p.y) < pr.radius+p.radius){
        hitPlayer(pr.dmg);
        if(pr.poison){ game.player.poisonTimer=3; game.hazards.push({x:p.x,y:p.y,r:1,dot:true,timer:3,tick:0}); }
        if(pr.slow){ p.slowTimer = Math.max(p.slowTimer||0, pr.slow.dur); p.slowFactor = pr.slow.factor; }
        remove=true;
      }
    }
    if(remove) game.projectiles.splice(i,1);
  }
}
function explodeAt(x,y,radius,dmgObj){
  addParticles(x,y,'#ff6a3d',18,200,0.4);
  shake(5);
  [...game.enemies, ...bossTargets()].forEach(t=>{
    if(dist(x,y,t.x,t.y)<radius+t.radius) dealDamageToTarget(t, dmgObj, 'explode');
  });
}

/* ---------- hazards (poison dot on player) ---------- */
function updateHazards(dt){
  for(let i=game.hazards.length-1;i>=0;i--){
    const h = game.hazards[i];
    // unified telegraph->active hazard system: used by every hazard type (fire, poison, spike,
    // ice, storm, void, light...). Detected by the presence of `active`, NOT by a type whitelist —
    // that whitelist was the bug: any new hazard type added later silently never dealt damage.
    if(h.active !== undefined){
      if(h.telegraph>0){
        h.telegraph-=dt;
      } else {
        if(h.expanding) h.r += (h.expandRate||100)*dt;
        h.active-=dt; h.tick-=dt;
        const p=game.player;
        if(h.tick<=0 && p.invuln<=0 && dist(h.x,h.y,p.x,p.y)<h.r){
          h.tick = h.type==='poison' ? 0.6 : 0.45;
          hitPlayer(h.dmg);
        }
        if(h.active<=0){ game.hazards.splice(i,1); continue; }
      }
      continue;
    }
    h.timer-=dt; h.tick-=dt;
    if(h.tick<=0 && h.dot){
      h.tick=0.5;
      const p=game.player;
      if(p.invuln<=0){ p.hp -= 2; addDamageText(p.x,p.y-30,2,'#8bff6b',false); }
    }
    if(h.timer<=0) game.hazards.splice(i,1);
  }
}

/* ---------- gold orbs ---------- */
function updateGoldOrbs(dt){
  const p = game.player;
  for(let i=game.goldOrbs.length-1;i>=0;i--){
    const g = game.goldOrbs[i];
    const d = dist(g.x,g.y,p.x,p.y);
    if(d<130){
      const ang = Math.atan2(p.y-g.y,p.x-g.x);
      g.x += Math.cos(ang)*420*dt;
      g.y += Math.sin(ang)*420*dt;
    } else {
      g.x += g.vx*dt*0.3; g.y += g.vy*dt*0.3;
      g.vx*=0.9; g.vy*=0.9;
    }
    if(d<22){
      game.gold += Math.round(g.value * p.goldMult * (game.pacts.hardMode ? 1.15 : 1) * comboFactor(p) * game.routeGoldMult);
      game.goldOrbs.splice(i,1);
    }
  }
}

function maybeDropRelic(t){
  if(!t.isElite || Math.random()>RELIC_DROP_CHANCE) return;
  const p = game.player;
  const available = RELICS.filter(r=>!p.relics[r.id]);
  if(!available.length) return;
  const relic = available[Math.floor(Math.random()*available.length)];
  game.relicPickups.push({ x:t.x, y:t.y, relic, pulse:Math.random()*10 });
}

function maybeDropUtilityChest(t){
  if(game.phase!=='combat' || Math.random()>UTILITY_CHEST_CHANCE) return;
  game.utilityChests.push({ x:t.x, y:t.y, pulse:Math.random()*10 });
}

function updateUtilityChests(dt){
  const p = game.player;
  for(let i=game.utilityChests.length-1;i>=0;i--){
    const uc = game.utilityChests[i];
    if(dist(uc.x,uc.y,p.x,p.y)<34){
      const potion = POTIONS[Math.floor(Math.random()*POTIONS.length)];
      p.potions[potion.id]++;
      spawnToast(`🧪 Cofre de utilidad: +1 ${potion.name} (tecla ${potion.key.replace('Digit','')})`);
      addParticles(uc.x,uc.y,potion.color,26,200,0.5);
      game.utilityChests.splice(i,1);
    }
  }
}

function drawUtilityChest(uc){
  const bob = Math.sin(performance.now()/360+uc.pulse)*4;
  ctx.save();
  ctx.translate(uc.x, uc.y+bob);
  const grad = ctx.createRadialGradient(0,0,2,0,0,24);
  grad.addColorStop(0,'rgba(139,255,107,0.5)');
  grad.addColorStop(1,'rgba(139,255,107,0)');
  ctx.fillStyle = grad;
  ctx.beginPath(); ctx.arc(0,0,24,0,Math.PI*2); ctx.fill();
  ctx.fillStyle='#2a3a1a'; ctx.strokeStyle='#8bff6b'; ctx.lineWidth=2;
  ctx.beginPath(); ctx.rect(-13,-9,26,18); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-13,-9); ctx.quadraticCurveTo(0,-22,13,-9); ctx.stroke();
  ctx.fillStyle='#8bff6b'; ctx.font='14px serif'; ctx.textAlign='center'; ctx.textBaseline='middle';
  ctx.fillText('🧪', 0, 1);
  ctx.restore();
}

function usePotion(id){
  const p = game.player;
  if(!p.potions[id] || p.potions[id]<=0) return;
  p.potions[id]--;
  const def = POTIONS.find(x=>x.id===id);
  if(id==='hp'){
    p.hp = Math.min(p.maxHp, p.hp + 25);
    addParticles(p.x,p.y,'#e8434f',20,160,0.4);
  } else if(id==='def'){
    p.potionEffects.def = 6;
    addParticles(p.x,p.y,'#8a8f9c',18,150,0.4);
  } else if(id==='dmg'){
    p.potionEffects.dmg = 6;
    addParticles(p.x,p.y,'#ff6a3d',18,150,0.4);
  } else if(id==='spd'){
    p.potionEffects.spd = 6;
    addParticles(p.x,p.y,'#6a8dff',18,150,0.4);
  }
  spawnToast(`${def.icon} ${def.name} usada`);
}

function updateRelicPickups(dt){
  const p = game.player;
  for(let i=game.relicPickups.length-1;i>=0;i--){
    const rp = game.relicPickups[i];
    if(dist(rp.x,rp.y,p.x,p.y)<34){
      rp.relic.apply(p);
      p.relics[rp.relic.id] = true;
      p.items.push({ id:rp.relic.id, name:rp.relic.name, icon:rp.relic.icon, desc:rp.relic.desc });
      spawnToast(`✨ Reliquia: ${rp.relic.name} — ${rp.relic.desc}`);
      addParticles(rp.x,rp.y,'#ffd54a',30,220,0.6);
      shake(6);
      game.relicPickups.splice(i,1);
    }
  }
}

function drawRelicPickup(rp){
  const bob = Math.sin(performance.now()/380+rp.pulse)*4;
  ctx.save();
  ctx.translate(rp.x, rp.y+bob);
  const grad = ctx.createRadialGradient(0,0,2,0,0,26);
  grad.addColorStop(0,'rgba(255,213,74,0.55)');
  grad.addColorStop(1,'rgba(255,213,74,0)');
  ctx.fillStyle = grad;
  ctx.beginPath(); ctx.arc(0,0,26,0,Math.PI*2); ctx.fill();
  ctx.strokeStyle='#ffd54a'; ctx.lineWidth=2;
  ctx.beginPath(); ctx.arc(0,0,13,0,Math.PI*2); ctx.stroke();
  ctx.fillStyle='#ffd54a';
  ctx.font='16px serif'; ctx.textAlign='center'; ctx.textBaseline='middle';
  ctx.fillText(rp.relic.icon, 0, 1);
  ctx.restore();
}

/* ---------- chests / altar ---------- */
function updateChests(dt){
  game.chests.forEach(c=>{
    if(c.opened || c.tier==='common') return;
    c.sparkTimer -= dt;
    if(c.sparkTimer<=0){
      c.sparkTimer = c.tier==='epic' ? rand(0.12,0.24) : rand(0.3,0.55);
      const t = CHEST_TIERS[c.tier];
      const ang = Math.random()*Math.PI*2;
      const r = c.radius*0.8;
      game.particles.push({ x:c.x+Math.cos(ang)*r, y:c.y+Math.sin(ang)*r-6, vx:rand(-6,6), vy:-rand(18,34),
        life:0.6, maxLife:0.6, color:t.color, r:rand(1.2,2.2), type:'circle' });
    }
  });
}
function updateAltarPrompt(){
  const p = game.player;
  const toast = $('prompt-toast');
  let msg='';
  if(game.phase==='shopping'){
    game.chests.forEach(c=>{
      if(!c.opened && dist(p.x,p.y,c.x,c.y)<60) msg = `Espacio: abrir cofre ${CHEST_TIERS[c.tier].label} (${c.cost} oro)`;
    });
    if(!msg && game.altar && dist(p.x,p.y,game.altar.x,game.altar.y)<70) msg='Espacio: invocar al jefe';
    if(!msg && game.sacrificeAltar && !game.sacrificeAltar.used && dist(p.x,p.y,game.sacrificeAltar.x,game.sacrificeAltar.y)<60) msg='Espacio: sacrificar 15% HP máx por oro';
    if(!msg && game.merchant && dist(p.x,p.y,game.merchant.x,game.merchant.y)<70) msg = game.merchant.chosen ? 'El mercader ya no tiene nada para vos' : 'Espacio: ver la mercancía del mercader';
  } else if(game.phase==='portal'){
    if(game.portal && dist(p.x,p.y,game.portal.x,game.portal.y)<70) msg='Espacio: entrar al portal';
  }
  if(msg){ toast.textContent=msg; toast.classList.add('show'); }
  else { toast.classList.remove('show'); }
}

/* ---------- particles ---------- */
function updateParticles(dt){
  for(let i=game.particles.length-1;i>=0;i--){
    const pt = game.particles[i];
    pt.life-=dt;
    if(pt.type==='circle'){ pt.x+=pt.vx*dt; pt.y+=pt.vy*dt; pt.vx*=0.92; pt.vy*=0.92; }
    else { pt.x+=pt.vx*dt; pt.y+=pt.vy*dt; pt.vy+=40*dt; }
    if(pt.life<=0) game.particles.splice(i,1);
  }
}

/* ---------- melee swing visuals ---------- */
function updateSwings(dt){
  for(let i=game.swings.length-1;i>=0;i--){
    const s = game.swings[i];
    s.life -= dt;
    if(s.life<=0) game.swings.splice(i,1);
  }
}

/* ---------- shockwave rings for heavy self-centered impacts ---------- */
function spawnShockwave(x,y,color,maxR,life){
  game.shockwaves.push({ x,y,color,maxR, r:maxR*0.15, life:life||0.4, maxLife:life||0.4 });
}
function updateShockwaves(dt){
  for(let i=game.shockwaves.length-1;i>=0;i--){
    const s = game.shockwaves[i];
    s.life -= dt;
    const prog = 1-clamp(s.life/s.maxLife,0,1);
    s.r = s.maxR*(0.15+prog*0.85);
    if(s.life<=0) game.shockwaves.splice(i,1);
  }
}
function drawShockwave(s){
  const fade = clamp(s.life/s.maxLife,0,1);
  ctx.save();
  ctx.globalAlpha = fade*0.8;
  ctx.strokeStyle = s.color;
  ctx.lineWidth = 5*fade+1.5;
  ctx.beginPath(); ctx.arc(s.x,s.y,s.r,0,Math.PI*2); ctx.stroke();
  ctx.globalAlpha = fade*0.35;
  ctx.lineWidth = 12*fade+2;
  ctx.beginPath(); ctx.arc(s.x,s.y,s.r*0.92,0,Math.PI*2); ctx.stroke();
  ctx.restore();
}

/* ---------- ghost afterimages for dashes and blinks ---------- */
function spawnAfterimage(x,y,radius,color,icon){
  game.afterimages.push({ x,y,radius,color,icon, life:0.26, maxLife:0.26 });
}
function updateAfterimages(dt){
  for(let i=game.afterimages.length-1;i>=0;i--){
    const a = game.afterimages[i];
    a.life -= dt;
    if(a.life<=0) game.afterimages.splice(i,1);
  }
}
function drawAfterimage(a){
  const fade = clamp(a.life/a.maxLife,0,1);
  ctx.save();
  ctx.globalAlpha = fade*0.4;
  ctx.fillStyle = a.color;
  ctx.beginPath(); ctx.arc(a.x,a.y,a.radius,0,Math.PI*2); ctx.fill();
  if(a.icon){
    ctx.globalAlpha = fade*0.5;
    ctx.fillStyle = '#ffffff';
    ctx.font='14px serif'; ctx.textAlign='center'; ctx.textBaseline='middle';
    ctx.fillText(a.icon, a.x, a.y+1);
  }
  ctx.restore();
}

/* ============================================================
   HUD SYNC
   ============================================================ */
function syncPotionRow(p){
  const row = $('potion-row');
  if(!row) return;
  row.innerHTML = POTIONS.map(pt=>{
    const n = p.potions[pt.id]||0;
    return `<div class="potion-slot${n>0?' has':''}"><span class="key">${pt.key.replace('Digit','')}</span><span class="ic">${pt.icon}</span>${n>0?`<span class="n">${n}</span>`:''}</div>`;
  }).join('');
}

// Every buff/debuff timer the player can be under, and how to describe it in the HUD panel.
const EFFECT_DEFS = [
  { get:p=>p.effects.warcry, label:'Grito de Guerra', desc:'+35% daño', kind:'buff' },
  { get:p=>p.effects.shadow, label:'Paso Sombrío', desc:'invisible, +15% vel., próx. golpe crítico', kind:'buff' },
  { get:p=>p.effects.wall, label:'Escudo Sagrado', desc:'+25% reducción de daño', kind:'buff' },
  { get:p=>p.potionEffects.def, label:'Poción de Defensa', desc:'+30% reducción de daño', kind:'buff' },
  { get:p=>p.potionEffects.dmg, label:'Poción de Daño', desc:'+25% daño', kind:'buff' },
  { get:p=>p.potionEffects.spd, label:'Poción de Velocidad', desc:'+30% velocidad', kind:'buff' },
  { get:p=>p.weakenTimer, label:'Debilitado', desc:'daño reducido', kind:'debuff' },
  { get:p=>p.chillTimer, label:'Enfriado', desc:'ataques más lentos', kind:'debuff' },
  { get:p=>p.slowTimer, label:'Ralentizado', desc:'movimiento reducido', kind:'debuff' },
  { get:p=>p.invertTimer, label:'Confundido', desc:'controles invertidos', kind:'debuff' },
  { get:p=>p.qLockTimer, label:'Q bloqueada', desc:'', kind:'debuff' },
  { get:p=>p.eLockTimer, label:'E bloqueada', desc:'', kind:'debuff' },
];
function syncEffectsPanel(p){
  const panel = $('effects-panel');
  if(!panel) return;
  const active = EFFECT_DEFS.map(e=>({ label:e.label, desc:e.desc, kind:e.kind, t:e.get(p) })).filter(e=>e.t>0.05);
  if(!active.length){ panel.innerHTML=''; return; }
  panel.innerHTML = active.map(e=>`
    <div class="effect-chip ${e.kind}">
      <span class="nm">${e.label}${e.desc?` <i>(${e.desc})</i>`:''}</span>
      <span class="t">${e.t.toFixed(1)}s</span>
    </div>
  `).join('');
}

function syncHud(){
  const p = game.player;
  $('hp-fill').style.width = clamp(p.hp/p.maxHp*100,0,100)+'%';
  $('hp-label').textContent = `${Math.max(0,Math.round(p.hp))}/${Math.round(p.maxHp)}` + (p.shield>0?`  ⛨${Math.round(p.shield)}`:'');
  $('gold-count').textContent = game.gold;
  $('hud-char-level').textContent = p.charLevel;
  syncPotionRow(p);
  syncEffectsPanel(p);
  const comboWrap = $('combo-wrap');
  if(p.combo>=5){ comboWrap.style.display='block'; $('combo-count').textContent = p.combo; }
  else { comboWrap.style.display='none'; }
  $('hud-hero-name').textContent = p.def.name;
  $('hud-hero-class').textContent = p.def.className;
  $('q-icon').textContent = p.def.q.icon;
  $('e-icon').textContent = p.def.e.icon;
  const qcd = $('q-cd'), ecd = $('e-cd');
  if(p.qTimer>0){ qcd.style.display='flex'; qcd.textContent = p.qTimer.toFixed(1); } else qcd.style.display='none';
  if(p.eTimer>0){ ecd.style.display='flex'; ecd.textContent = p.eTimer.toFixed(1); } else ecd.style.display='none';
  const rSlot = $('r-slot');
  if(progress.unlockedAbilities.length){
    rSlot.style.display='flex';
    let best=null;
    progress.unlockedAbilities.forEach(id=>{ const cd=p.ultCooldowns[id]||0; if(!best||cd<best.cd) best={id,cd}; });
    const ab = ULTIMATE_ABILITIES.find(a=>a.id===best.id);
    const rIcon = $('r-icon');
    rIcon.textContent = ab.icon;
    rIcon.style.color = ab.color;
    const rcd = $('r-cd');
    if(best.cd>0){ rcd.style.display='flex'; rcd.textContent = best.cd.toFixed(1); } else rcd.style.display='none';
  } else {
    rSlot.style.display='none';
  }
  updatePhaseNote();
  if(game.boss){
    $('boss-hp-fill').style.width = clamp(game.boss.hp/game.boss.maxHp*100,0,100)+'%';
  }
}

/* ============================================================
   RENDER
   ============================================================ */
function render(){
  ctx.save();
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle = '#0a0710';
  ctx.fillRect(0,0,canvas.width,canvas.height);

  if(!game){ ctx.restore(); return; }

  ctx.save();
  if(game.shake>0){
    ctx.translate(rand(-game.shake,game.shake), rand(-game.shake,game.shake));
  }
  ctx.translate(-game.camera.x, -game.camera.y);

  const b = arenaBounds();
  drawArena(b);

  // altar
  if(game.altar) drawAltar(game.altar);
  if(game.sacrificeAltar) drawSacrificeAltar(game.sacrificeAltar);
  if(game.merchant) drawMerchant(game.merchant);
  // portal
  if(game.portal) drawPortal(game.portal);
  // ground hazards (fire patches etc)
  game.hazards.forEach(h=>drawHazard(h));
  // chests
  game.chests.forEach(c=>drawChest(c));
  // gold orbs
  game.goldOrbs.forEach(g=>drawGold(g));
  game.relicPickups.forEach(rp=>drawRelicPickup(rp));
  game.utilityChests.forEach(uc=>drawUtilityChest(uc));
  // melee swing effects
  game.swings.forEach(s=>drawSwing(s));
  game.shockwaves.forEach(s=>drawShockwave(s));
  game.afterimages.forEach(a=>drawAfterimage(a));
  // enemies
  game.enemies.forEach(en=>drawEnemy(en));
  if(game.pet) drawPet(game.pet);
  // boss
  if(game.boss && game.boss.telegraph) drawBossTelegraphIndicator(game.boss);
  if(game.boss) drawBoss(game.boss);
  if(game.boss && game.boss.twin && game.boss.twin.alive) drawTwinCompanion(game.boss.twin, game.boss.def);
  // projectiles
  game.projectiles.forEach(pr=>drawProjectile(pr));
  // player
  drawPlayer(game.player);
  // particles
  game.particles.forEach(pt=>drawParticle(pt));

  ctx.restore();

  if(game.phase==='bossIntro') drawBossCountdown(game.bossCountdown);

  ctx.restore();
}

function drawBossCountdown(t){
  const n = Math.ceil(t);
  if(n<1) return;
  const frac = t-(n-1); // 1 -> 0 within this second
  const scale = 1 + (1-frac)*0.6;
  const alpha = clamp(frac*1.4,0,1);
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.translate(canvas.width/2, canvas.height/2 - 20);
  ctx.scale(scale,scale);
  ctx.font = "900 120px 'Cinzel Decorative', serif";
  ctx.textAlign='center'; ctx.textBaseline='middle';
  ctx.shadowColor='#ff6a3d'; ctx.shadowBlur=40;
  ctx.fillStyle='#ff6a3d';
  ctx.fillText(String(n), 0, 0);
  ctx.restore();
  ctx.save();
  ctx.globalAlpha = 0.85;
  ctx.textAlign='center';
  ctx.font = "600 14px 'JetBrains Mono', monospace";
  ctx.fillStyle='#ece2cf';
  ctx.letterSpacing = '4px';
  ctx.fillText('EL ALTAR DESPIERTA', canvas.width/2, canvas.height/2+70);
  ctx.restore();
}

function drawArena(b){
  ctx.fillStyle = '#120b1c';
  ctx.fillRect(b.x,b.y,b.w,b.h);
  ctx.strokeStyle = 'rgba(210,74,255,0.12)';
  ctx.lineWidth=1;
  const grid=40;
  for(let x=b.x; x<b.x+b.w; x+=grid){
    ctx.beginPath(); ctx.moveTo(x,b.y); ctx.lineTo(x,b.y+b.h); ctx.stroke();
  }
  for(let y=b.y; y<b.y+b.h; y+=grid){
    ctx.beginPath(); ctx.moveTo(b.x,y); ctx.lineTo(b.x+b.w,y); ctx.stroke();
  }
  ctx.strokeStyle = '#382a4a';
  ctx.lineWidth=3;
  ctx.strokeRect(b.x,b.y,b.w,b.h);
  // vignette
  const grad = ctx.createRadialGradient(b.x+b.w/2,b.y+b.h/2,Math.min(b.w,b.h)*0.2,b.x+b.w/2,b.y+b.h/2,Math.max(b.w,b.h)*0.7);
  grad.addColorStop(0,'rgba(0,0,0,0)');
  grad.addColorStop(1,'rgba(0,0,0,0.55)');
  ctx.fillStyle=grad;
  ctx.fillRect(b.x,b.y,b.w,b.h);
}

function drawPortal(portal){
  portal.pulse += 0.04;
  const t = performance.now()/500;
  const R = 34 + Math.sin(portal.pulse)*4;
  ctx.save();
  ctx.translate(portal.x, portal.y);
  const grad = ctx.createRadialGradient(0,0,2,0,0,R+26);
  grad.addColorStop(0,'rgba(106,141,255,0.55)');
  grad.addColorStop(0.6,'rgba(210,74,255,0.35)');
  grad.addColorStop(1,'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.beginPath(); ctx.arc(0,0,R+26,0,Math.PI*2); ctx.fill();
  for(let ring=0; ring<3; ring++){
    ctx.save();
    ctx.rotate(t*(ring%2?1:-1)*(0.6+ring*0.2));
    ctx.strokeStyle = ring===1?'#d24aff':'#6a8dff';
    ctx.lineWidth=2;
    ctx.setLineDash([6,8]);
    ctx.beginPath(); ctx.ellipse(0,0,R-ring*7,(R-ring*7)*0.9,0,0,Math.PI*2); ctx.stroke();
    ctx.restore();
  }
  ctx.setLineDash([]);
  ctx.fillStyle='#ece2cf';
  ctx.font='22px serif'; ctx.textAlign='center'; ctx.textBaseline='middle';
  ctx.fillText('◈', 0, 1);
  ctx.restore();
  if(Math.random()<0.5){
    const ang = Math.random()*Math.PI*2;
    game.particles.push({ x:portal.x+Math.cos(ang)*(R+20), y:portal.y+Math.sin(ang)*(R+20),
      vx:-Math.cos(ang)*60, vy:-Math.sin(ang)*60, life:0.5, maxLife:0.5, color:'#6a8dff', r:2, type:'circle' });
  }
}

const HAZARD_COLORS = {
  fire:   { ring:'rgba(255,90,61,0.7)',   fillA:'rgba(255,138,61,0.55)', fillB:'rgba(255,90,61,0.05)' },
  poison: { ring:'rgba(139,255,107,0.7)', fillA:'rgba(139,255,107,0.45)', fillB:'rgba(139,255,107,0.05)' },
  spike:  { ring:'rgba(217,205,179,0.8)', fillA:'rgba(217,205,179,0.55)', fillB:'rgba(217,205,179,0.05)' },
  ice:    { ring:'rgba(159,216,255,0.8)', fillA:'rgba(159,216,255,0.55)', fillB:'rgba(159,216,255,0.05)' },
  storm:  { ring:'rgba(255,224,90,0.8)',  fillA:'rgba(255,224,90,0.55)',  fillB:'rgba(255,224,90,0.05)' },
  void:   { ring:'rgba(138,90,217,0.8)',  fillA:'rgba(138,90,217,0.55)',  fillB:'rgba(138,90,217,0.05)' },
  light:  { ring:'rgba(255,179,236,0.8)', fillA:'rgba(255,179,236,0.55)', fillB:'rgba(255,179,236,0.05)' },
};
function drawHazard(h){
  const c = HAZARD_COLORS[h.type];
  if(!c) return;
  ctx.save();
  if(h.telegraph>0){
    // soft pulsing fill plus marching dashed ring, easier to read at a glance than an empty outline
    const pulse = 0.5+Math.sin(performance.now()/120)*0.15;
    ctx.globalAlpha = 0.16+pulse*0.14;
    ctx.fillStyle = c.ring;
    ctx.beginPath(); ctx.arc(h.x,h.y,h.r,0,Math.PI*2); ctx.fill();
    ctx.globalAlpha = 1;
    ctx.strokeStyle=c.ring;
    ctx.lineWidth=2;
    ctx.setLineDash([5,5]);
    ctx.lineDashOffset = -performance.now()/40;
    ctx.beginPath(); ctx.arc(h.x,h.y,h.r,0,Math.PI*2); ctx.stroke();
    ctx.setLineDash([]);
  } else if(h.type==='fire'){
    drawFireHazard(h,c);
  } else if(h.type==='poison'){
    drawPoisonHazard(h,c);
  } else {
    // spike, ice, storm, void: same jagged crystalline silhouette, differentiated by color
    drawSpikeHazard(h,c);
  }
  ctx.restore();
}

// crackling pool with licking flames around the rim and rising cinders
function drawFireHazard(h,c){
  const wobble = 1 + Math.sin(performance.now()/150 + h.x)*0.035;
  const r = h.r*wobble;
  const grad = ctx.createRadialGradient(h.x,h.y,2,h.x,h.y,r);
  grad.addColorStop(0,c.fillA);
  grad.addColorStop(1,c.fillB);
  ctx.fillStyle = grad;
  ctx.beginPath(); ctx.arc(h.x,h.y,r,0,Math.PI*2); ctx.fill();
  const n=6;
  for(let i=0;i<n;i++){
    const ang = (i/n)*Math.PI*2 + performance.now()/900;
    const flick = 0.6+Math.sin(performance.now()/90+i*1.7)*0.4;
    const fx = h.x+Math.cos(ang)*r*0.72, fy = h.y+Math.sin(ang)*r*0.72;
    ctx.save();
    ctx.translate(fx,fy);
    ctx.rotate(ang+Math.PI/2);
    ctx.globalAlpha = 0.5*flick;
    ctx.fillStyle = '#ffcb47';
    ctx.beginPath();
    ctx.moveTo(0,6);
    ctx.quadraticCurveTo(5,-4-flick*8, 0,-13-flick*9);
    ctx.quadraticCurveTo(-5,-4-flick*8, 0,6);
    ctx.fill();
    ctx.restore();
  }
  ctx.globalAlpha = 0.5;
  ctx.strokeStyle = c.ring;
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(h.x,h.y,r,0,Math.PI*2); ctx.stroke();
  if(Math.random()<0.3){
    const ang = Math.random()*Math.PI*2;
    game.particles.push({ x:h.x+Math.cos(ang)*r*0.6, y:h.y+Math.sin(ang)*r*0.6, vx:rand(-10,10), vy:-42-Math.random()*28,
      life:0.5, maxLife:0.5, color:'#ffcb47', r:1.6, type:'circle' });
  }
}

// bubbling toxic pool with rising bubbles
function drawPoisonHazard(h,c){
  const wobble = 1 + Math.sin(performance.now()/150 + h.x)*0.035;
  const r = h.r*wobble;
  const grad = ctx.createRadialGradient(h.x,h.y,2,h.x,h.y,r);
  grad.addColorStop(0,c.fillA);
  grad.addColorStop(1,c.fillB);
  ctx.fillStyle = grad;
  ctx.beginPath(); ctx.arc(h.x,h.y,r,0,Math.PI*2); ctx.fill();
  ctx.globalAlpha = 0.5;
  ctx.strokeStyle = c.ring;
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(h.x,h.y,r,0,Math.PI*2); ctx.stroke();
  const n=5;
  for(let i=0;i<n;i++){
    const seed = i*137.5;
    const bt = ((performance.now()/900)+i/n)%1;
    const bx = h.x+Math.sin(seed+h.x)*r*0.55;
    const by = h.y + r*0.5 - bt*r*0.95;
    ctx.globalAlpha = (1-bt)*0.6;
    ctx.fillStyle = '#c8ffb0';
    ctx.beginPath(); ctx.arc(bx,by, 2+Math.sin(seed)*1.4, 0, Math.PI*2); ctx.fill();
  }
}

// jagged spikes bursting up from the ground instead of a plain filled circle
function drawSpikeHazard(h,c){
  ctx.save();
  ctx.translate(h.x,h.y);
  const n=5;
  for(let i=0;i<n;i++){
    const ang = (i/n)*Math.PI*2 + h.x*0.013;
    const len = h.r*(0.85+((i%3)*0.1));
    ctx.save();
    ctx.rotate(ang);
    const grad = ctx.createLinearGradient(0,0,0,-len);
    grad.addColorStop(0,c.fillA);
    grad.addColorStop(1,'#ffffff');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(-h.r*0.15,0);
    ctx.lineTo(0,-len);
    ctx.lineTo(h.r*0.15,0);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
  ctx.restore();
  ctx.globalAlpha = 0.4;
  ctx.strokeStyle = c.ring;
  ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.arc(h.x,h.y,h.r*0.5,0,Math.PI*2); ctx.stroke();
}

function drawSwing(s){
  const t = clamp(s.life/s.maxLife,0,1);   // 1 -> 0 over the swing's life
  const prog = 1-t;                         // 0 -> 1 as the swing plays out
  const fade = t;
  ctx.save();
  ctx.translate(s.x,s.y);

  // trailing afterimages behind the main slash, giving it a sense of motion/swoosh
  for(let i=3;i>=1;i--){
    const trailAng = s.angle - i*0.1*(1-prog*0.3);
    ctx.save();
    ctx.rotate(trailAng);
    ctx.globalAlpha = fade*0.13*(4-i)/3;
    ctx.fillStyle = s.color;
    ctx.beginPath();
    ctx.moveTo(0,0);
    ctx.arc(0,0,s.range,-s.arc,s.arc);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  ctx.rotate(s.angle);

  // core wedge: brighter and sharper near the blade's outer edge instead of a flat fade
  const grad = ctx.createRadialGradient(0,0,s.range*0.35,0,0,s.range);
  grad.addColorStop(0,'rgba(255,255,255,0)');
  grad.addColorStop(0.6, s.color);
  grad.addColorStop(0.88, '#ffffff');
  grad.addColorStop(1,'rgba(255,255,255,0)');
  ctx.globalAlpha = fade*0.85;
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.moveTo(0,0);
  ctx.arc(0,0,s.range,-s.arc,s.arc);
  ctx.closePath();
  ctx.fill();

  // crisp white cutting-edge along the outer curve
  ctx.globalAlpha = fade;
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 2.5;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.arc(0,0,s.range*0.97,-s.arc,s.arc);
  ctx.stroke();

  // colored glow just inside the white edge, for extra punch
  ctx.globalAlpha = fade*0.7;
  ctx.strokeStyle = s.color;
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.arc(0,0,s.range*0.9,-s.arc,s.arc);
  ctx.stroke();

  // small spark flashes where the blade starts and ends its arc
  [-s.arc, s.arc].forEach(a=>{
    const tx = Math.cos(a)*s.range, ty = Math.sin(a)*s.range;
    ctx.globalAlpha = fade*0.9;
    ctx.fillStyle = '#ffffff';
    ctx.beginPath(); ctx.arc(tx,ty,3.2,0,Math.PI*2); ctx.fill();
  });

  ctx.restore();
}

function drawSacrificeAltar(a){
  ctx.save();
  ctx.globalAlpha = a.used?0.3:1;
  a.pulse += 0.03;
  const r = 22+Math.sin(a.pulse)*4;
  const grad = ctx.createRadialGradient(a.x,a.y,3,a.x,a.y,r+22);
  grad.addColorStop(0,'rgba(232,67,79,0.45)');
  grad.addColorStop(1,'rgba(232,67,79,0)');
  ctx.fillStyle=grad;
  ctx.beginPath(); ctx.arc(a.x,a.y,r+22,0,Math.PI*2); ctx.fill();
  ctx.strokeStyle='#e8434f'; ctx.lineWidth=2;
  ctx.beginPath(); ctx.arc(a.x,a.y,r,0,Math.PI*2); ctx.stroke();
  ctx.fillStyle='#e8434f'; ctx.font='18px serif'; ctx.textAlign='center'; ctx.textBaseline='middle';
  ctx.fillText('♦', a.x, a.y);
  ctx.restore();
}

function drawMerchant(m){
  ctx.save();
  ctx.globalAlpha = m.chosen?0.4:1;
  m.pulse += 0.025;
  const r = 24+Math.sin(m.pulse)*3;
  const grad = ctx.createRadialGradient(m.x,m.y,3,m.x,m.y,r+26);
  grad.addColorStop(0,'rgba(255,203,71,0.4)');
  grad.addColorStop(1,'rgba(255,203,71,0)');
  ctx.fillStyle=grad;
  ctx.beginPath(); ctx.arc(m.x,m.y,r+26,0,Math.PI*2); ctx.fill();
  ctx.strokeStyle='#ffcb47'; ctx.lineWidth=2;
  ctx.beginPath(); ctx.arc(m.x,m.y,r,0,Math.PI*2); ctx.stroke();
  ctx.fillStyle='#ffcb47'; ctx.font='20px serif'; ctx.textAlign='center'; ctx.textBaseline='middle';
  ctx.fillText('⚖', m.x, m.y);
  ctx.restore();
}

function drawAltar(a){
  a.pulse += 0.03;
  const glowR = 26+Math.sin(a.pulse)*5;
  ctx.save();
  ctx.globalAlpha = a.active?1:0.35;
  const grad = ctx.createRadialGradient(a.x,a.y,4,a.x,a.y,glowR+30);
  grad.addColorStop(0,'rgba(210,74,255,0.5)');
  grad.addColorStop(1,'rgba(210,74,255,0)');
  ctx.fillStyle=grad;
  ctx.beginPath(); ctx.arc(a.x,a.y,glowR+30,0,7); ctx.fill();
  ctx.strokeStyle='#d24aff';
  ctx.lineWidth=2;
  ctx.beginPath(); ctx.arc(a.x,a.y,glowR,0,Math.PI*2); ctx.stroke();
  ctx.setLineDash([4,6]);
  ctx.beginPath(); ctx.arc(a.x,a.y,glowR+10,a.pulse,a.pulse+Math.PI*1.5); ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle='#ece2cf';
  ctx.font='20px serif';
  ctx.textAlign='center'; ctx.textBaseline='middle';
  ctx.fillText('☥', a.x, a.y);
  ctx.restore();
}

function drawChest(c){
  const t = CHEST_TIERS[c.tier];
  if(c.opened){
    ctx.save(); ctx.globalAlpha=0.28;
    ctx.fillStyle=t.wood; ctx.strokeStyle=t.color; ctx.lineWidth=1.5;
    ctx.beginPath(); ctx.rect(c.x-14,c.y-6,28,14); ctx.fill(); ctx.stroke();
    ctx.restore();
    return;
  }
  const bob = Math.sin(performance.now()/420+c.bob)*3;
  const scale = c.radius/18;
  const pulse = 0.5+Math.sin(performance.now()/500+c.bob)*0.5;
  ctx.save();
  ctx.translate(c.x, c.y+bob);
  ctx.scale(scale, scale);

  // ambient glow halo (rare/epic)
  if(c.tier!=='common'){
    const haloR = 34 + pulse*(c.tier==='epic'?14:8);
    const grad = ctx.createRadialGradient(0,0,4,0,0,haloR);
    grad.addColorStop(0, t.glow);
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle=grad;
    ctx.beginPath(); ctx.arc(0,0,haloR,0,Math.PI*2); ctx.fill();
  }
  // epic: rotating rays behind chest
  if(c.tier==='epic'){
    ctx.save();
    ctx.rotate(performance.now()/2600);
    ctx.strokeStyle='rgba(210,74,255,0.25)';
    ctx.lineWidth=2;
    for(let i=0;i<6;i++){
      ctx.save(); ctx.rotate((i/6)*Math.PI*2);
      ctx.beginPath(); ctx.moveTo(0,-20); ctx.lineTo(0,-40); ctx.stroke();
      ctx.restore();
    }
    ctx.restore();
  }

  // base / lid
  ctx.fillStyle = t.wood;
  ctx.strokeStyle = t.color;
  ctx.lineWidth = 2.2;
  ctx.beginPath(); ctx.rect(-16,-10,32,20); ctx.fill(); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-16,-10); ctx.quadraticCurveTo(0,-27,16,-10); ctx.closePath(); ctx.fill(); ctx.stroke();

  // metal bands
  ctx.strokeStyle = c.tier==='epic' ? '#ffcb47' : (c.tier==='rare' ? '#c9d4ff' : '#8a7a5a');
  ctx.lineWidth = c.tier==='common' ? 1.4 : 2;
  ctx.beginPath(); ctx.moveTo(-4,-10); ctx.lineTo(-4,10); ctx.moveTo(4,-10); ctx.lineTo(4,10); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(-16,-10); ctx.quadraticCurveTo(0,-24,0,-10); ctx.stroke();

  // lock / gem
  if(c.tier==='common'){
    ctx.fillStyle='#8a7a5a';
    ctx.fillRect(-4,-4,8,7);
  } else {
    const gemPulse = 3+pulse*2;
    ctx.fillStyle = t.color;
    ctx.shadowColor = t.color; ctx.shadowBlur = 10+pulse*8;
    ctx.beginPath();
    ctx.moveTo(0,-8-gemPulse*0.3); ctx.lineTo(5,-8); ctx.lineTo(0,-3); ctx.lineTo(-5,-8); ctx.closePath();
    ctx.fill();
    ctx.shadowBlur=0;
  }
  ctx.restore();

  // label + cost (unscaled, above chest)
  ctx.save();
  ctx.translate(c.x, c.y+bob);
  ctx.textAlign='center';
  ctx.font = (c.tier==='epic'?'700 11px':'600 10px') + " 'JetBrains Mono', monospace";
  ctx.fillStyle = t.color;
  ctx.shadowColor = t.color; ctx.shadowBlur = c.tier==='common'?0:6;
  ctx.fillText(t.label.toUpperCase(), 0, -34*scale-6);
  ctx.shadowBlur=0;
  ctx.fillStyle = '#ffcb47';
  ctx.font = "10px 'JetBrains Mono', monospace";
  ctx.fillText(c.cost+'◆', 0, 30*scale);
  ctx.restore();
}

function drawGold(g){
  if(g.seed===undefined) g.seed = Math.random()*10;
  const spin = Math.sin(performance.now()/260 + g.seed);
  const scaleX = 0.35 + Math.abs(spin)*0.65;
  ctx.save();
  ctx.translate(g.x, g.y);
  ctx.scale(scaleX, 1);
  const grad = ctx.createRadialGradient(-2,-2,1, 0,0,7);
  grad.addColorStop(0,'#fff3c4');
  grad.addColorStop(0.55,'#ffcb47');
  grad.addColorStop(1,'#a8760f');
  ctx.fillStyle = grad;
  ctx.shadowColor='#ffcb47'; ctx.shadowBlur=7;
  ctx.beginPath(); ctx.arc(0,0,7,0,Math.PI*2); ctx.fill();
  ctx.shadowBlur=0;
  ctx.strokeStyle='#8a5a10'; ctx.lineWidth=1; ctx.stroke();
  if(scaleX>0.7){
    ctx.strokeStyle='rgba(138,90,16,0.6)'; ctx.lineWidth=0.8;
    ctx.beginPath(); ctx.arc(0,0,4,0,Math.PI*2); ctx.stroke();
  }
  ctx.restore();
}

function drawEnemy(en){
  // telegraphs drawn in world space, before the local translate below
  if(en.def.charger && en.chargeState==='windup'){
    const prog = 1 - clamp(en.chargeTimer/en.def.chargeWindup, 0, 1);
    const p = game.player;
    ctx.save();
    ctx.strokeStyle = en.def.color;
    ctx.globalAlpha = 0.35+prog*0.4;
    ctx.lineWidth = 3;
    ctx.setLineDash([4,8]);
    ctx.beginPath(); ctx.moveTo(en.x,en.y); ctx.lineTo(p.x,p.y); ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
  }
  if(en.def.chargeShot && en.aiming){
    const prog = 1 - clamp(en.aimTimer/en.def.chargeShotWindup, 0, 1);
    const p = game.player;
    ctx.save();
    ctx.strokeStyle = '#ffb3ec';
    ctx.globalAlpha = 0.25+prog*0.55;
    ctx.lineWidth = 2;
    ctx.setLineDash([2,6]);
    ctx.beginPath(); ctx.moveTo(en.x,en.y); ctx.lineTo(p.x,p.y); ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
  }
  ctx.save();
  ctx.translate(en.x,en.y);
  if(en.def.erratic) ctx.globalAlpha = 0.72;
  if(en.isElite){
    ctx.shadowColor='#ffd54a'; ctx.shadowBlur=16;
  }
  ctx.fillStyle = en.hitFlash>0 ? '#ffffff' : en.def.color;
  ctx.beginPath(); ctx.arc(0,0,en.radius,0,Math.PI*2); ctx.fill();
  ctx.shadowBlur=0;
  ctx.strokeStyle = en.isElite ? '#ffd54a' : 'rgba(0,0,0,0.4)';
  ctx.lineWidth = en.isElite ? 3 : 2;
  ctx.stroke();
  if(en.armorHp>0){
    ctx.strokeStyle='rgba(200,200,215,0.85)';
    ctx.lineWidth=2;
    ctx.setLineDash([4,3]);
    ctx.beginPath(); ctx.arc(0,0,en.radius+4,0,Math.PI*2); ctx.stroke();
    ctx.setLineDash([]);
  }
  if(en.def.healer){
    ctx.strokeStyle='rgba(90,217,138,0.55)';
    ctx.lineWidth=1.5;
    ctx.beginPath(); ctx.arc(0,0,en.radius+5,0,Math.PI*2); ctx.stroke();
  }
  // hp bar
  const w=en.radius*2;
  ctx.fillStyle='rgba(0,0,0,0.6)'; ctx.fillRect(-w/2,-en.radius-12,w,4);
  ctx.fillStyle = en.isElite ? '#ffd54a' : '#e8434f';
  ctx.fillRect(-w/2,-en.radius-12,w*clamp(en.hp/en.maxHp,0,1),4);
  ctx.restore();
}

function drawBossTelegraphIndicator(boss){
  const tg = boss.telegraph;
  if(!tg) return;
  const prog = 1 - clamp(tg.t/tg.dur, 0, 1); // 0 -> 1 as the wind-up completes
  const p = game.player;
  const color = boss.def.color;
  const b = arenaBounds();

  if(tg.type==='boneGrab'){
    // the wind now covers the whole room, so the readable thing isn't a cone anymore — it's the
    // one safe pocket. Draw the danger as a faint arena-wide haze pulling toward the boss, and
    // make the safe zone unmistakably bright and calm by comparison
    ctx.save();
    ctx.globalAlpha = 0.05+prog*0.10;
    ctx.fillStyle = color;
    ctx.fillRect(b.x,b.y,b.w,b.h);
    ctx.restore();
    // streaking wind particles drifting toward the boss, arena-wide
    if(Math.random()<0.6){
      const ang0 = Math.random()*Math.PI*2;
      const rr = 60+Math.random()*Math.max(b.w,b.h)*0.6;
      const sx = clamp(boss.x+Math.cos(ang0)*rr, b.x+4, b.x+b.w-4);
      const sy = clamp(boss.y+Math.sin(ang0)*rr, b.y+4, b.y+b.h-4);
      game.particles.push({ x:sx, y:sy, vx:(boss.x-sx)*0.9, vy:(boss.y-sy)*0.9,
        life:0.4, maxLife:0.4, color, r:1.6, type:'circle' });
    }
    if(tg.safeX!==undefined){
      ctx.save();
      const pulse = 0.7+Math.sin(performance.now()/160)*0.3;
      ctx.globalAlpha = 0.16+pulse*0.14;
      const grad = ctx.createRadialGradient(tg.safeX,tg.safeY,4,tg.safeX,tg.safeY,tg.safeR+18);
      grad.addColorStop(0,'rgba(139,255,107,0.55)');
      grad.addColorStop(1,'rgba(139,255,107,0)');
      ctx.fillStyle = grad;
      ctx.beginPath(); ctx.arc(tg.safeX,tg.safeY,tg.safeR+18,0,Math.PI*2); ctx.fill();
      ctx.globalAlpha = 0.55+pulse*0.35;
      ctx.strokeStyle = '#8bff6b'; ctx.lineWidth = 2.5;
      ctx.setLineDash([6,5]);
      ctx.beginPath(); ctx.arc(tg.safeX,tg.safeY,tg.safeR,0,Math.PI*2); ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle='#8bff6b'; ctx.font='13px monospace'; ctx.textAlign='center'; ctx.textBaseline='middle';
      ctx.globalAlpha = 0.9;
      ctx.fillText('OJO DE CALMA', tg.safeX, tg.safeY);
      ctx.restore();
    }
  } else if(tg.type==='megaLaser'){
    // preview fan while charging, then a hard bright sweeping beam once it goes hot — drawn for
    // both origins if the twin sister is still alive
    const elapsedL = tg.dur - tg.t;
    const drawOrigin = (originX, originY, startAngle)=>{
      ctx.save();
      ctx.translate(originX, originY);
      if(elapsedL <= tg.hotAt){
        // preview: a soft fan showing the full sweep range so you can plan where to end up
        ctx.globalAlpha = 0.12+0.1*Math.sin(performance.now()/120);
        ctx.fillStyle = '#ff3d3d';
        ctx.beginPath();
        ctx.moveTo(0,0);
        ctx.arc(0,0, tg.beamLen, startAngle, startAngle+tg.sweepDir*tg.sweepArc, tg.sweepDir<0);
        ctx.closePath();
        ctx.fill();
      } else {
        const sweepProg = clamp((elapsedL-tg.hotAt)/(tg.dur-tg.hotAt), 0, 1);
        const curAngle = startAngle + tg.sweepDir*tg.sweepArc*sweepProg;
        ctx.rotate(curAngle);
        ctx.globalAlpha = 0.85;
        ctx.strokeStyle = '#ff3d3d';
        ctx.lineWidth = 10;
        ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(tg.beamLen,0); ctx.stroke();
        ctx.globalAlpha = 1;
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(tg.beamLen,0); ctx.stroke();
      }
      ctx.restore();
    };
    drawOrigin(boss.x, boss.y, tg.startAngle);
    if(boss.twin && boss.twin.alive && tg.twinStartAngle!==undefined){
      drawOrigin(boss.twin.x, boss.twin.y, tg.twinStartAngle);
    }
  } else if(tg.type==='gravityWell'){
    // a swirling vortex anchored at a fixed point in space (not on the boss), spinning faster and
    // pulling tighter as it charges — visually distinct from the directional boneGrab cone
    const wx = tg.tx, wy = tg.ty;
    ctx.save();
    ctx.translate(wx,wy);
    ctx.rotate(performance.now()/(260-prog*140));
    for(let k=0;k<3;k++){
      const rr = 14+prog*34-k*8;
      ctx.globalAlpha = (0.22+prog*0.4)*(1-k*0.25);
      ctx.strokeStyle = color;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0,0, Math.max(4,rr), k*0.9, k*0.9+Math.PI*1.3);
      ctx.stroke();
    }
    ctx.restore();
    if(Math.random()<0.4+prog*0.3){
      const ang = Math.random()*Math.PI*2;
      const rr = 40+prog*30;
      game.particles.push({ x:wx+Math.cos(ang)*rr, y:wy+Math.sin(ang)*rr, vx:-Math.cos(ang)*50, vy:-Math.sin(ang)*50,
        life:0.3, maxLife:0.3, color, r:1.8, type:'circle' });
    }
  } else if(tg.type==='magmaCross'){
    const armLen = 58*3*prog;
    ctx.save();
    ctx.translate(boss.x,boss.y);
    ctx.globalAlpha = 0.18+prog*0.32;
    ctx.fillStyle = color;
    [[1,0],[-1,0],[0,1],[0,-1]].forEach(([dx,dy])=>{
      ctx.fillRect(dx>0?0:(dx<0?-armLen:-24), dy>0?0:(dy<0?-armLen:-24), dx!==0?armLen:48, dy!==0?armLen:48);
    });
    ctx.globalAlpha = 0.5+prog*0.4;
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.setLineDash([6,6]);
    [[1,0],[-1,0],[0,1],[0,-1]].forEach(([dx,dy])=>{
      ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(dx*armLen, dy*armLen); ctx.stroke();
    });
    ctx.setLineDash([]);
    ctx.restore();
  } else if(tg.type==='blazingFissure'){
    if(tg.fissureVertical===undefined){ tg.fissureVertical = Math.random()<0.5; tg.fissureGap = rand(0.22,0.78); }
    const vertical = tg.fissureVertical, gapFrac = tg.fissureGap;
    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = 6;
    ctx.globalAlpha = 0.2+prog*0.45;
    const segs = 24;
    ctx.beginPath();
    for(let i=0;i<segs;i++){
      const frac = i/(segs-1);
      if(Math.abs(frac-gapFrac) < 0.06) continue; // matches the eventual escape gap
      let x1,y1;
      if(vertical){ x1 = tg.tx; y1 = b.y+30+frac*(b.h-60); }
      else { y1 = tg.ty; x1 = b.x+30+frac*(b.w-60); }
      ctx.moveTo(x1-3,y1); ctx.lineTo(x1+3,y1);
    }
    ctx.stroke();
    ctx.restore();
  } else if(GROUND_SELF_ATTACKS.includes(tg.type)){
    const maxR = tg.type==='slam' ? 170 : 150;
    const r = maxR*prog;
    ctx.save();
    ctx.strokeStyle = color;
    ctx.globalAlpha = 0.6;
    ctx.lineWidth = 3;
    ctx.setLineDash([10,7]);
    ctx.beginPath(); ctx.arc(boss.x, boss.y, r, 0, Math.PI*2); ctx.stroke();
    ctx.setLineDash([]);
    ctx.globalAlpha = 0.14*prog;
    ctx.fillStyle = color;
    ctx.beginPath(); ctx.arc(boss.x, boss.y, r, 0, Math.PI*2); ctx.fill();
    // faint outer ring marking the final blast radius
    ctx.globalAlpha = 0.25;
    ctx.strokeStyle = color;
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(boss.x, boss.y, maxR, 0, Math.PI*2); ctx.stroke();
    ctx.restore();
  } else if(GROUND_TARGET_ATTACKS.includes(tg.type)){
    const spread = tg.type==='meteor' ? 95 : (tg.type==='boneCage' ? 118 : (tg.type==='poisonPool' ? 190 : (tg.type==='growingMagma' ? 130 : 170)));
    ctx.save();
    // falling shadow / impact mark
    ctx.globalAlpha = 0.35+prog*0.35;
    ctx.fillStyle = color;
    ctx.beginPath(); ctx.ellipse(tg.tx, tg.ty, 30+spread*0.22, 14+spread*0.1, 0, 0, Math.PI*2); ctx.fill();
    // expanding warning ring sweeping clockwise
    ctx.globalAlpha = 0.65;
    ctx.strokeStyle = color;
    ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.arc(tg.tx, tg.ty, spread*0.55, -Math.PI/2, -Math.PI/2 + Math.PI*2*prog); ctx.stroke();
    // outer boundary of the whole danger patch
    ctx.globalAlpha = 0.22;
    ctx.setLineDash([6,6]);
    ctx.beginPath(); ctx.arc(tg.tx, tg.ty, spread, 0, Math.PI*2); ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
    if(Math.random()<0.5){
      const ang = Math.random()*Math.PI*2;
      const rr = Math.random()*spread;
      game.particles.push({ x:tg.tx+Math.cos(ang)*rr, y:tg.ty+Math.sin(ang)*rr, vx:0, vy:-16, life:0.3, maxLife:0.3, color, r:1.6, type:'circle' });
    }
  } else if(DASH_ATTACKS.includes(tg.type) || DASH_ATTACKS_EXTRA_TELEGRAPH.includes(tg.type)){
    ctx.save();
    ctx.strokeStyle = color;
    ctx.globalAlpha = 0.4+Math.sin(performance.now()/55)*0.25;
    ctx.lineWidth = 3;
    ctx.setLineDash([4,10]);
    ctx.beginPath(); ctx.moveTo(boss.x,boss.y); ctx.lineTo(p.x,p.y); ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
  } else if(BURST_ATTACKS.includes(tg.type)){
    const r = 6+prog*30;
    ctx.save();
    const grad = ctx.createRadialGradient(boss.x,boss.y,1,boss.x,boss.y,r+16);
    grad.addColorStop(0, color);
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.globalAlpha = 0.45+prog*0.5;
    ctx.fillStyle = grad;
    ctx.beginPath(); ctx.arc(boss.x,boss.y,r+16,0,Math.PI*2); ctx.fill();
    ctx.restore();
  }
}

function drawTwinCompanion(t, def){
  ctx.save();
  ctx.translate(t.x,t.y);
  if(t.shieldTimer>0){
    ctx.globalAlpha = 0.5+Math.sin(performance.now()/90)*0.15;
    ctx.strokeStyle = '#ff9ad1';
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(0,0,t.radius+7,0,Math.PI*2); ctx.stroke();
    ctx.globalAlpha = 1;
  }
  ctx.fillStyle = t.hitFlash>0 ? '#ffffff' : def.color;
  ctx.shadowColor=def.color; ctx.shadowBlur=14;
  ctx.beginPath(); ctx.arc(0,0,t.radius,0,Math.PI*2); ctx.fill();
  ctx.shadowBlur=0;
  ctx.strokeStyle='#0a0710'; ctx.lineWidth=2.5; ctx.stroke();
  const w=t.radius*2;
  ctx.fillStyle='rgba(0,0,0,0.6)'; ctx.fillRect(-w/2,-t.radius-12,w,4);
  ctx.fillStyle='#ff9ad1'; ctx.fillRect(-w/2,-t.radius-12,w*clamp(t.hp/t.maxHp,0,1),4);
  ctx.restore();
}

function drawBoss(boss){
  ctx.save();
  ctx.translate(boss.x,boss.y);
  if(boss.spawnGrace>0){
    const t = clamp(1-(boss.spawnGrace/1.1),0,1); // 0 -> 1 as it materializes
    ctx.scale(0.3+t*0.7, 0.3+t*0.7);
    ctx.globalAlpha = 0.4+t*0.6;
    const haloR = boss.radius + 40*(1-t);
    const grad = ctx.createRadialGradient(0,0,4,0,0,haloR);
    grad.addColorStop(0, boss.def.color);
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grad;
    ctx.beginPath(); ctx.arc(0,0,haloR,0,Math.PI*2); ctx.fill();
  }
  if(boss.telegraph){
    const pulse = Math.sin(performance.now()/60)*4;
    ctx.strokeStyle = boss.def.color;
    ctx.lineWidth=2.5;
    ctx.globalAlpha=0.75;
    ctx.beginPath(); ctx.arc(0,0,boss.radius+18+pulse,0,Math.PI*2); ctx.stroke();
    ctx.globalAlpha=1;
    ctx.strokeStyle='rgba(255,255,255,0.55)';
    ctx.lineWidth=1.5;
    ctx.setLineDash([5,5]);
    ctx.beginPath(); ctx.arc(0,0,boss.radius+9-pulse*0.5, performance.now()/220, performance.now()/220+Math.PI*1.4); ctx.stroke();
    ctx.setLineDash([]);
  }
  if(boss.shieldTimer>0){
    ctx.globalAlpha = 0.5+Math.sin(performance.now()/90)*0.15;
    ctx.strokeStyle = '#ff9ad1';
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(0,0,boss.radius+7,0,Math.PI*2); ctx.stroke();
    ctx.globalAlpha = 1;
  }
  ctx.fillStyle = boss.hitFlash>0 ? '#ffffff' : boss.def.color;
  ctx.shadowColor=boss.def.color; ctx.shadowBlur=18;
  ctx.beginPath(); ctx.arc(0,0,boss.radius,0,Math.PI*2); ctx.fill();
  ctx.shadowBlur=0;
  ctx.strokeStyle='#0a0710'; ctx.lineWidth=3; ctx.stroke();
  ctx.restore();
}

function drawProjectile(pr){
  if(pr.shape==='shard') return drawProjShard(pr);
  if(pr.shape==='feather') return drawProjFeather(pr);
  if(pr.shape==='wisp') return drawProjWisp(pr);
  if(pr.shape==='orb') return drawProjOrb(pr);
  if(pr.shape==='ember') return drawProjEmber(pr);
  ctx.save();
  const speed = Math.hypot(pr.vx,pr.vy)||1;
  const dirX = pr.vx/speed, dirY = pr.vy/speed;
  const tailLen = Math.min(36, pr.radius*3.4);

  // comet-style trail streaking back along the direction of travel
  const tx = pr.x - dirX*tailLen, ty = pr.y - dirY*tailLen;
  const trailGrad = ctx.createLinearGradient(tx,ty,pr.x,pr.y);
  trailGrad.addColorStop(0,'rgba(0,0,0,0)');
  trailGrad.addColorStop(1,pr.color);
  ctx.strokeStyle = trailGrad;
  ctx.lineWidth = Math.max(2,pr.radius*1.3);
  ctx.lineCap = 'round';
  ctx.globalAlpha = 0.55;
  ctx.beginPath(); ctx.moveTo(tx,ty); ctx.lineTo(pr.x,pr.y); ctx.stroke();

  // outer glow body
  ctx.globalAlpha = 1;
  ctx.shadowColor = pr.color; ctx.shadowBlur = 14;
  ctx.fillStyle = pr.color;
  ctx.beginPath(); ctx.arc(pr.x,pr.y,pr.radius,0,Math.PI*2); ctx.fill();
  ctx.shadowBlur = 0;

  // bright white-hot core for punch
  ctx.globalAlpha = 0.85;
  ctx.fillStyle = '#ffffff';
  ctx.beginPath(); ctx.arc(pr.x,pr.y,pr.radius*0.42,0,Math.PI*2); ctx.fill();
  ctx.restore();
}

// angular spinning crystal/dagger shard — bone fragments, broken mirror glass, thrown blades
function drawProjShard(pr){
  const rot = performance.now()/130 + pr.x*0.01;
  const R = pr.radius*1.6;
  ctx.save();
  ctx.translate(pr.x,pr.y);
  ctx.rotate(rot);
  ctx.shadowColor = pr.color; ctx.shadowBlur = 9;
  ctx.fillStyle = pr.color;
  ctx.beginPath();
  ctx.moveTo(0,-R); ctx.lineTo(R*0.5,0); ctx.lineTo(0,R); ctx.lineTo(-R*0.5,0); ctx.closePath();
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.globalAlpha = 0.85;
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.moveTo(0,-R*0.4); ctx.lineTo(R*0.18,0); ctx.lineTo(0,R*0.4); ctx.lineTo(-R*0.18,0); ctx.closePath();
  ctx.fill();
  ctx.restore();
}

// soft drifting petal/feather — the garden boss's light-woven attacks
function drawProjFeather(pr){
  const ang = Math.atan2(pr.vy,pr.vx);
  const sway = Math.sin(performance.now()/90 + pr.x*0.05)*0.3;
  const len = pr.radius*2.8, wid = pr.radius*1.15;
  ctx.save();
  ctx.translate(pr.x,pr.y);
  ctx.rotate(ang+Math.PI/2+sway);
  const grad = ctx.createLinearGradient(0,-len*0.6,0,len*0.4);
  grad.addColorStop(0,'rgba(255,255,255,0.95)');
  grad.addColorStop(0.4,pr.color);
  grad.addColorStop(1,'rgba(255,255,255,0)');
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.moveTo(0,-len*0.6);
  ctx.quadraticCurveTo(wid,0, 0, len*0.4);
  ctx.quadraticCurveTo(-wid,0, 0,-len*0.6);
  ctx.fill();
  ctx.restore();
}

// flickering translucent wisp — ghostly phantoms and cursed marks
function drawProjWisp(pr){
  const flicker = 0.55+Math.sin(performance.now()/70+pr.x)*0.25;
  ctx.save();
  ctx.globalAlpha = flicker;
  ctx.shadowColor = pr.color; ctx.shadowBlur = 16;
  const R = pr.radius*1.7;
  const grad = ctx.createRadialGradient(pr.x,pr.y,0,pr.x,pr.y,R);
  grad.addColorStop(0,'#ffffff');
  grad.addColorStop(0.4,pr.color);
  grad.addColorStop(1,'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.beginPath(); ctx.arc(pr.x,pr.y,R,0,Math.PI*2); ctx.fill();
  ctx.restore();
}

// pulsing orb with a tilted rotating halo ring — twin-bond and prismatic magic
function drawProjOrb(pr){
  const pulse = 1+Math.sin(performance.now()/80+pr.x)*0.15;
  ctx.save();
  ctx.translate(pr.x,pr.y);
  ctx.rotate(performance.now()/300);
  ctx.strokeStyle = pr.color; ctx.lineWidth = 2; ctx.globalAlpha = 0.7;
  ctx.beginPath(); ctx.ellipse(0,0,pr.radius*1.9,pr.radius*0.7,0,0,Math.PI*2); ctx.stroke();
  ctx.globalAlpha = 1;
  ctx.shadowColor = pr.color; ctx.shadowBlur = 12;
  ctx.fillStyle = pr.color;
  ctx.beginPath(); ctx.arc(0,0,pr.radius*pulse,0,Math.PI*2); ctx.fill();
  ctx.shadowBlur = 0;
  ctx.globalAlpha = 0.85;
  ctx.fillStyle = '#ffffff';
  ctx.beginPath(); ctx.arc(0,0,pr.radius*0.4,0,Math.PI*2); ctx.fill();
  ctx.restore();
}

// molten fireball with rising cinders — abyssal fire magic
function drawProjEmber(pr){
  const speed = Math.hypot(pr.vx,pr.vy)||1;
  const dirX = pr.vx/speed, dirY = pr.vy/speed;
  const tailLen = pr.radius*3.6;
  ctx.save();
  const tx = pr.x - dirX*tailLen, ty = pr.y - dirY*tailLen;
  const trailGrad = ctx.createLinearGradient(tx,ty,pr.x,pr.y);
  trailGrad.addColorStop(0,'rgba(0,0,0,0)');
  trailGrad.addColorStop(0.5,'rgba(255,90,61,0.5)');
  trailGrad.addColorStop(1,'#ffcb47');
  ctx.strokeStyle = trailGrad;
  ctx.lineWidth = pr.radius*1.6;
  ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(tx,ty); ctx.lineTo(pr.x,pr.y); ctx.stroke();
  ctx.shadowColor = '#ff5a3d'; ctx.shadowBlur = 16;
  ctx.fillStyle = '#ff5a3d';
  ctx.beginPath(); ctx.arc(pr.x,pr.y,pr.radius,0,Math.PI*2); ctx.fill();
  ctx.shadowBlur = 0;
  ctx.fillStyle = '#ffcb47';
  ctx.beginPath(); ctx.arc(pr.x,pr.y,pr.radius*0.55,0,Math.PI*2); ctx.fill();
  if(Math.random()<0.5){
    game.particles.push({ x:pr.x, y:pr.y, vx:rand(-14,14), vy:-30-Math.random()*20, life:0.3, maxLife:0.3,
      color:'#ffcb47', r:1.6, type:'circle' });
  }
  ctx.restore();
}

function drawPlayer(p){
  ctx.save();
  ctx.translate(p.x,p.y);
  if(p.invuln>0 && Math.floor(performance.now()/60)%2===0){ ctx.globalAlpha=0.4; }
  if(p.effects.shadow>0){ ctx.globalAlpha=0.5; }
  // withering curse: a sickly pulsing aura with wisps drifting off, so the debuff actually reads on-screen
  if(p.witherTimer>0){
    const pulse = 0.5+Math.sin(performance.now()/180)*0.2;
    ctx.save();
    ctx.globalAlpha = 0.35+pulse*0.25;
    ctx.strokeStyle = '#a44fd9';
    ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.arc(0,0,p.radius+9,0,Math.PI*2); ctx.stroke();
    ctx.restore();
    if(Math.random()<0.25){
      const ang = Math.random()*Math.PI*2;
      game.particles.push({ x:p.x+Math.cos(ang)*p.radius, y:p.y+Math.sin(ang)*p.radius, vx:Math.cos(ang)*14, vy:-24-Math.random()*14,
        life:0.6, maxLife:0.6, color:'#a44fd9', r:1.8, type:'circle' });
    }
  }
  // facing indicator
  ctx.save();
  ctx.rotate(p.facing);
  ctx.fillStyle='rgba(255,255,255,0.15)';
  ctx.beginPath(); ctx.moveTo(p.radius,0); ctx.lineTo(p.radius+16,-8); ctx.lineTo(p.radius+16,8); ctx.closePath(); ctx.fill();
  ctx.restore();

  const glowColor = p.effects.warcry>0 ? '#ff6a3d' : p.def.accent;
  ctx.shadowColor=glowColor; ctx.shadowBlur = p.effects.warcry>0?24:14;
  ctx.fillStyle='#ece2cf';
  ctx.beginPath(); ctx.arc(0,0,p.radius,0,Math.PI*2); ctx.fill();
  ctx.shadowBlur=0;
  ctx.strokeStyle=p.def.accent; ctx.lineWidth=3; ctx.stroke();
  ctx.fillStyle=p.def.accent;
  ctx.font='16px serif'; ctx.textAlign='center'; ctx.textBaseline='middle';
  ctx.fillText(p.def.icon,0,1);
  if(p.shield>0){
    ctx.strokeStyle='#ffcb47'; ctx.lineWidth=2.5; ctx.globalAlpha=0.8;
    ctx.beginPath(); ctx.arc(0,0,p.radius+7,0,Math.PI*2); ctx.stroke();
  }
  ctx.restore();
}

function drawParticle(pt){
  ctx.save();
  const alpha = clamp(pt.life/pt.maxLife,0,1);
  ctx.globalAlpha = alpha;
  if(pt.type==='circle'){
    ctx.fillStyle=pt.color;
    ctx.beginPath(); ctx.arc(pt.x,pt.y,pt.r,0,Math.PI*2); ctx.fill();
  } else {
    ctx.fillStyle=pt.color;
    ctx.font=`700 ${pt.size}px ${getComputedStyle(document.documentElement).getPropertyValue('--font-mono')}`;
    ctx.textAlign='center';
    ctx.fillText(pt.text, pt.x, pt.y);
  }
  ctx.restore();
}

/* ============================================================
   INITIAL RENDER (idle background on menu)
   ============================================================ */
function idleRender(){
  ctx.fillStyle='#0a0710';
  ctx.fillRect(0,0,canvas.width,canvas.height);
  requestAnimationFrame(idleRender);
}
idleRender();

})();
